import tempfile, unittest, subprocess, sys, json
from pathlib import Path
from samarth.project import protect_file, PROFILES
from samarth.runtime import execute_payload, verify_payload

SOURCE = '''import math
value = "héllo"
data = b"abc"
class Demo:
    def __init__(self):
        self.x = value
    def run(self):
        return self.x
def calc(a):
    return a + 2
try:
    result = calc(3)
except Exception:
    result = -1
root_result = math.sqrt(9)
'''

class CoreTests(unittest.TestCase):
    def test_protect_execute(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d); src = p/"app.py"; out = p/"app.sme"
            src.write_text(SOURCE, encoding="utf-8")
            protect_file(src, out, "advanced")
            ns = {}
            execute_payload(out.read_bytes(), ns, str(src))
            self.assertEqual(ns["result"], 5)
            self.assertEqual(ns["Demo"]().run(), "héllo")
            self.assertIn(3.0, ns.values())

    def test_profiles(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d); src = p/"x.py"
            src.write_text("x='✓'\n", encoding="utf-8")
            for profile in PROFILES:
                out = p/(profile+".sme")
                protect_file(src, out, profile)
                ns = {}
                execute_payload(out.read_bytes(), ns, str(src))
                self.assertIn("✓", ns.values())

    def test_integrity(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d); src = p/"x.py"; out = p/"x.sme"
            src.write_text("x=1", encoding="utf-8")
            protect_file(src, out)
            b = bytearray(out.read_bytes()); b[-1] ^= 1
            with self.assertRaises(ValueError):
                verify_payload(bytes(b))

    def test_invalid_input(self):
        with self.assertRaises(Exception):
            verify_payload(b"not-samarth")

    def test_cli_version(self):
        r = subprocess.run([sys.executable, "-m", "samarth.cli", "--version"],
                           capture_output=True, text=True)
        self.assertEqual(r.returncode, 0)
        self.assertIn("0.5.1", r.stdout)


    def test_bundle_loader_selects_current_version(self):
        from samarth.loader import run_bundle
        with tempfile.TemporaryDirectory() as d:
            p = Path(d); src = p/"app.py"; out = p/"bundle"
            src.write_text("answer = 42\n", encoding="utf-8")
            from samarth.project import protect_file
            target = out / f"app_py{sys.version_info.major}{sys.version_info.minor}.sme"
            protect_file(src, target, "standard")
            result = run_bundle(out, "app")
            self.assertEqual(result["metadata"]["python"][:2], list(sys.version_info[:2]))



    def test_multiversion_resolution_current_only(self):
        from samarth.multiversion import resolve_interpreters
        resolved, missing = resolve_interpreters(bootstrap=False)
        self.assertTrue(isinstance(resolved, dict))
        self.assertTrue(all(v in ("3.11", "3.12", "3.13", "3.14") for v in resolved))
        self.assertTrue(set(resolved) | set(missing) == {"3.11", "3.12", "3.13", "3.14"})
