from __future__ import annotations
import ast, hashlib, json, shutil
from pathlib import Path
from .ast_engine import transform, ASTConfig
from .bytecode_engine import compile_source, pack_code

PROFILES = {
    "standard": dict(rename_identifiers=False, transform_strings=True, optimize=0),
    "advanced": dict(rename_identifiers=True, transform_strings=True, optimize=0),
    "maximum": dict(rename_identifiers=True, transform_strings=True, optimize=2),
    "native": dict(rename_identifiers=True, transform_strings=True, optimize=2),
    "hybrid": dict(rename_identifiers=True, transform_strings=True, optimize=2),
}

def detect_imports(source: str) -> list[str]:
    tree = ast.parse(source)
    return sorted({n.names[0].name.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.Import) for _ in [0]}
                  | {n.module.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) and n.module})

def protect_file(src: Path, out: Path, profile="advanced"):
    if profile.lower() not in PROFILES: raise ValueError(f"Unknown profile: {profile}")
    cfg = ASTConfig(**PROFILES[profile.lower()])
    source = src.read_text(encoding="utf-8")
    transformed, report = transform(source, cfg)
    code = compile_source(transformed, str(src), cfg.optimize)
    digest = hashlib.sha256(source.encode()).hexdigest()
    payload = pack_code(code, digest, {"profile": profile.lower(), "source_sha256": digest, "python": list(__import__("sys").version_info[:3])})
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(payload)
    return report, payload

def protect_project(src: Path, out: Path, profile="advanced"):
    if src.is_file():
        target = out / (src.stem + ".sme")
        report, payload = protect_file(src, target, profile)
        manifest = {"version":"0.4.0","profile":profile,"files":[target.name],
                    "sha256":hashlib.sha256(payload).hexdigest()}
    else:
        pyfiles = sorted(src.rglob("*.py"))
        if not pyfiles: raise ValueError("Project contains no Python files.")
        out.mkdir(parents=True, exist_ok=True)
        entries=[]
        for p in pyfiles:
            rel=p.relative_to(src).with_suffix(".sme")
            report,_=protect_file(p,out/rel,profile)
            entries.append(str(rel))
        manifest={"version":"0.4.0","profile":profile,"files":entries}
        manifest["project_root"]=src.name
    (out/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    return manifest
