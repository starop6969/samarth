from __future__ import annotations

import sys
from pathlib import Path

from .runtime import execute_payload


def select_payload(bundle: Path, stem: str | None = None) -> Path:
    version = f"{sys.version_info.major}{sys.version_info.minor}"
    if stem:
        candidate = bundle / f"{stem}_py{version}.sme"
        if candidate.exists():
            return candidate
    candidates = sorted(bundle.glob(f"*_py{version}.sme"))
    if len(candidates) == 1:
        return candidates[0]
    if not candidates:
        raise RuntimeError(
            f"No SAMARTH payload for Python {sys.version_info.major}.{sys.version_info.minor} "
            f"was found in {bundle}."
        )
    raise RuntimeError(f"Multiple Python {version} payloads found; use --name to select one.")


def run_bundle(bundle: Path, stem: str | None = None) -> dict:
    payload_path = select_payload(bundle, stem)
    ns = {"__name__": "__main__", "__file__": str(payload_path)}
    meta = execute_payload(payload_path.read_bytes(), ns, str(payload_path))
    return {"payload": str(payload_path), "metadata": meta}
