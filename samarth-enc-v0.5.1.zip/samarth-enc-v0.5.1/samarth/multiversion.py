from __future__ import annotations

import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from .ast_engine import ASTConfig, transform
from .project import PROFILES

TARGETS = ("3.11", "3.12", "3.13", "3.14")

# This worker intentionally keeps the same protection pipeline as v0.5.0:
# transformed source -> CPython compile -> marshal -> zlib -> SAMENC04 envelope.
# It only changes *which CPython interpreter* performs the compilation.
_WORKER = r'''
import hashlib, marshal, secrets, struct, sys, zlib
from pathlib import Path

MAGIC = b"SAMENC04"
source_path = Path(sys.argv[1])
out_path = Path(sys.argv[2])
profile = sys.argv[3]
source_hash = sys.argv[4]
source = source_path.read_text(encoding="utf-8")
code = compile(source, str(source_path), "exec", optimize=int(sys.argv[5]))
raw = marshal.dumps(code)
compressed = zlib.compress(raw, 9)
nonce = secrets.token_bytes(16)
meta = repr({"profile": profile, "source_sha256": source_hash,
             "python": list(sys.version_info[:3])}).encode("utf-8")
header = MAGIC + struct.pack(">H", sys.version_info.major) + struct.pack(">H", sys.version_info.minor)
blob = header + struct.pack(">I", len(meta)) + meta + nonce + compressed
digest = hashlib.sha256(blob).digest()
out_path.write_bytes(blob + digest)
'''


def _version_of(command: list[str]) -> str | None:
    try:
        r = subprocess.run(
            command + ["-c", "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"],
            capture_output=True, text=True, timeout=20,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if r.returncode != 0:
        return None
    return r.stdout.strip().splitlines()[-1] if r.stdout.strip() else None


def _find_python(version: str) -> list[str] | None:
    """Find a real CPython interpreter for *version*.

    Search order is deliberately conservative: explicit versioned commands,
    Windows py launcher, then common interpreter locations. No version is
    faked by metadata.
    """
    major, minor = version.split(".")
    candidates: list[list[str]] = []

    names = [f"python{version}", f"python{major}.{minor}", f"python{minor}"]
    for name in names:
        path = shutil.which(name)
        if path:
            candidates.append([path])

    if os.name == "nt":
        launcher = shutil.which("py")
        if launcher:
            candidates.append([launcher, f"-{version}"])

    # Common absolute locations, useful when PATH is incomplete.
    if os.name == "nt":
        roots = [Path(os.environ.get("LOCALAPPDATA", "")), Path(os.environ.get("PROGRAMFILES", ""))]
        for root in roots:
            if not root:
                continue
            candidates.extend([
                [str(root / "Programs" / "Python" / f"Python{major}{minor}" / "python.exe")],
                [str(root / f"Python{major}{minor}" / "python.exe")],
            ])
    else:
        for base in (Path("/usr/bin"), Path("/usr/local/bin"), Path.home() / ".local" / "bin"):
            for name in names[:2]:
                candidates.append([str(base / name)])

    seen: set[tuple[str, ...]] = set()
    for command in candidates:
        key = tuple(command)
        if key in seen:
            continue
        seen.add(key)
        if _version_of(command) == version:
            return command
    return None


def _find_uv() -> str | None:
    return shutil.which("uv")


def _uv_python(version: str) -> list[str] | None:
    """Return a uv-managed interpreter, installing it if uv is available.

    This is the automatic bootstrap path for machines that only have one
    system Python. uv must already be installed; SAMARTH does not silently
    install package managers.
    """
    uv = _find_uv()
    if not uv:
        return None
    try:
        subprocess.run([uv, "python", "install", version], check=True,
                       capture_output=True, text=True, timeout=600)
        r = subprocess.run([uv, "python", "find", version], check=True,
                           capture_output=True, text=True, timeout=30)
        path = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ""
        if path and _version_of([path]) == version:
            return [path]
    except (OSError, subprocess.SubprocessError):
        pass
    return None


def resolve_interpreters(interpreters: dict[str, str] | None = None,
                         bootstrap: bool = True) -> tuple[dict[str, list[str]], list[str]]:
    """Resolve all target interpreters without changing the encoding profile."""
    interpreters = interpreters or {}
    resolved: dict[str, list[str]] = {}
    missing: list[str] = []
    for version in TARGETS:
        explicit = interpreters.get(version)
        if explicit:
            command = shlex.split(explicit, posix=(os.name != "nt"))
            if _version_of(command) != version:
                raise RuntimeError(
                    f"Configured interpreter for Python {version} is invalid or reports "
                    f"a different version."
                )
            resolved[version] = command
            continue
        command = _find_python(version)
        if command is None and bootstrap:
            command = _uv_python(version)
        if command is None:
            missing.append(version)
        else:
            resolved[version] = command
    return resolved, missing


def protect_multi(src: Path, out: Path, profile: str = "advanced",
                  interpreters: dict[str, str] | None = None,
                  bootstrap: bool = True) -> dict:
    profile = profile.lower()
    if profile not in PROFILES:
        raise ValueError(f"Unknown profile: {profile}")
    if not src.is_file() or src.suffix.lower() != ".py":
        raise ValueError("Multi-version protection currently accepts one .py file.")

    cfg = ASTConfig(**PROFILES[profile])
    source = src.read_text(encoding="utf-8")
    # IMPORTANT: transformation happens once, with the exact selected profile.
    # Every target interpreter compiles that same transformed source.
    transformed, report = transform(source, cfg)
    source_hash = hashlib.sha256(source.encode("utf-8")).hexdigest()
    out.mkdir(parents=True, exist_ok=True)

    resolved, missing = resolve_interpreters(interpreters, bootstrap=bootstrap)
    if missing:
        uv_note = "; install uv for automatic runtime bootstrapping" if not _find_uv() else ""
        raise RuntimeError(
            "Missing CPython runtimes: " + ", ".join(missing) +
            ". Install those CPython versions or provide --python311/--python312/"
            "--python313/--python314." + uv_note
        )

    created = []
    with tempfile.TemporaryDirectory(prefix="samarth-multi-") as td:
        transformed_path = Path(td) / src.name
        transformed_path.write_text(transformed, encoding="utf-8")
        worker_path = Path(td) / "worker.py"
        worker_path.write_text(_WORKER, encoding="utf-8")
        for version in TARGETS:
            command = resolved[version]
            target = out / f"{src.stem}_py{version.replace('.', '')}.sme"
            subprocess.run(
                command + [str(worker_path), str(transformed_path), str(target), profile,
                           source_hash, str(cfg.optimize)],
                check=True,
            )
            created.append(target.name)

    manifest = {
        "format": "samarth-multiversion-v1",
        "samarth_version": "0.5.1",
        "profile": profile,
        "source": src.name,
        "source_sha256": source_hash,
        "python_versions": TARGETS,
        "files": created,
        "transform_report": report,
        "encoding_pipeline": "same-as-v0.5.0",
    }
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest
