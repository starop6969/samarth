from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from . import __version__
from .project import protect_project, PROFILES
from .backends import run_backend, BackendError, available
from .multiversion import protect_multi, TARGETS
from .loader import run_bundle

def main(argv=None):
    p=argparse.ArgumentParser(prog="samarth", description="SAMARTH ENC Python protection toolkit")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub=p.add_subparsers(dest="cmd")
    pr=sub.add_parser("protect", help="protect a Python file or project")
    pr.add_argument("input")
    pr.add_argument("-o","--output", default="samarth_dist")
    pr.add_argument("--profile", choices=sorted(PROFILES), default="advanced")
    pr.add_argument("--backend", choices=["internal","pyarmor","nuitka","hybrid"], default="internal")
    mv=sub.add_parser("protect-multi", help="create CPython 3.11-3.14 payloads")
    mv.add_argument("input")
    mv.add_argument("-o","--output", default="samarth_multi")
    mv.add_argument("--profile", choices=sorted(PROFILES), default="advanced")
    for ver in TARGETS:
        mv.add_argument(f"--python{ver.replace('.', '')}", help=f"CPython {ver} executable/command")
    mv.add_argument("--no-bootstrap", action="store_true", help="do not use uv to bootstrap missing CPython runtimes")
    rb=sub.add_parser("run-bundle", help="run the payload matching the current Python version")
    rb.add_argument("bundle")
    rb.add_argument("--name", help="source stem, e.g. app")
    ins=sub.add_parser("inspect", help="inspect Python source syntax/imports")
    ins.add_argument("input")
    ns=p.parse_args(argv)
    if ns.cmd=="inspect":
        path=Path(ns.input)
        try:
            import ast
            tree=ast.parse(path.read_text(encoding="utf-8"))
            imports=sorted({a.name.split(".")[0] for a in ast.walk(tree) if isinstance(a,ast.Import)} |
                           {a.module.split(".")[0] for a in ast.walk(tree) if isinstance(a,ast.ImportFrom) and a.module})
            print(json.dumps({"file":str(path),"syntax":"valid","imports":imports},indent=2))
            return 0
        except Exception as e:
            print(f"samarth: inspect failed: {e}", file=sys.stderr); return 2
    if ns.cmd=="protect":
        src=Path(ns.input); out=Path(ns.output)
        if not src.exists(): print(f"samarth: input not found: {src}",file=sys.stderr); return 2
        try:
            if ns.backend=="internal":
                m=protect_project(src,out,ns.profile)
                print(f"SAMARTH ENC {__version__}: protected {len(m['files'])} file(s) -> {out}")
            else:
                if ns.backend=="hybrid":
                    if not available("pyarmor") and not available("nuitka"):
                        raise BackendError("Hybrid requires PyArmor or Nuitka to be installed.")
                    chosen="pyarmor" if available("pyarmor") else "nuitka"
                else: chosen=ns.backend
                if src.is_dir(): raise BackendError(f"{chosen} backend currently accepts a single Python file via this CLI.")
                run_backend(chosen,src,out)
                print(f"Backend {chosen} completed -> {out}")
            return 0
        except Exception as e:
            print(f"samarth: protection failed: {e}",file=sys.stderr); return 1
    if ns.cmd=="protect-multi":
        src=Path(ns.input); out=Path(ns.output)
        if not src.exists(): print(f"samarth: input not found: {src}", file=sys.stderr); return 2
        interpreters={ver:getattr(ns, f"python{ver.replace('.', '')}") for ver in TARGETS}
        interpreters={k:v for k,v in interpreters.items() if v}
        try:
            m=protect_multi(src,out,ns.profile,interpreters,bootstrap=not ns.no_bootstrap)
            print(f"SAMARTH ENC {__version__}: created {len(m['files'])} version-specific payloads -> {out}")
            for f in m["files"]: print(f"  {f}")
            return 0
        except Exception as e:
            print(f"samarth: multi-version protection failed: {e}", file=sys.stderr); return 1
    if ns.cmd=="run-bundle":
        try:
            result=run_bundle(Path(ns.bundle), ns.name)
            print(f"SAMARTH loader: {result['payload']}")
            return 0
        except Exception as e:
            print(f"samarth: loader failed: {e}", file=sys.stderr); return 1
    p.print_help(); return 0

if __name__=="__main__": raise SystemExit(main())
