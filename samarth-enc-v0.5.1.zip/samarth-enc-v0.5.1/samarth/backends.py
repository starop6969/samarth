from __future__ import annotations
import importlib.util, shutil, subprocess, sys
from pathlib import Path

class BackendError(RuntimeError): pass

def available(name: str) -> bool:
    if name == "pyarmor": return importlib.util.find_spec("pyarmor") is not None or shutil.which("pyarmor") is not None
    if name == "nuitka": return importlib.util.find_spec("nuitka") is not None or shutil.which("nuitka") is not None
    if name in {"internal", "samarth"}: return True
    if name == "hybrid": return available("pyarmor") or available("nuitka")
    return False

def run_backend(name: str, source: Path, output: Path, args: list[str] | None = None):
    args = args or []
    if name == "internal":
        raise BackendError("Internal backend is invoked by the SAMARTH builder, not this adapter.")
    if name == "pyarmor":
        if not available(name): raise BackendError("PyArmor is not installed. Install it separately to use --backend pyarmor.")
        cmd = [shutil.which("pyarmor") or sys.executable, "-m", "pyarmor", "gen", "-O", str(output), *args, str(source)]
    elif name == "nuitka":
        if not available(name): raise BackendError("Nuitka is not installed. Install it separately to use --backend nuitka.")
        cmd = [sys.executable, "-m", "nuitka", "--output-dir=" + str(output), *args, str(source)]
    else:
        raise BackendError(f"Unknown backend: {name}")
    p = subprocess.run(cmd, text=True, capture_output=True)
    if p.returncode:
        raise BackendError((p.stderr or p.stdout).strip() or f"{name} failed")
    return p
