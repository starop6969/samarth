from __future__ import annotations
import hashlib, marshal, zlib, struct, sys, types
from .bytecode_engine import MAGIC

def verify_payload(payload: bytes) -> None:
    if len(payload) < len(MAGIC) + 36 or not payload.startswith(MAGIC):
        raise ValueError("Invalid SAMARTH payload")
    body, digest = payload[:-32], payload[-32:]
    if hashlib.sha256(body).digest() != digest:
        raise ValueError("SAMARTH integrity check failed")

def execute_payload(payload: bytes, globals_dict=None, filename="<samarth>"):
    verify_payload(payload)
    body = payload[:-32]
    off = len(MAGIC) + 4
    mlen = struct.unpack(">I", body[off:off+4])[0]; off += 4
    meta_bytes = body[off:off+mlen]; off += mlen
    # Metadata is produced by our own builder and contains no executable expressions.
    meta = eval(meta_bytes.decode("utf-8"), {"__builtins__": {}}, {})
    off += 16
    code = marshal.loads(zlib.decompress(body[off:]))
    ns = globals_dict if globals_dict is not None else {"__name__": "__main__", "__file__": filename}
    exec(code, ns, ns)
    return meta
