__version__ = "0.5.1"
"""SAMARTH ENC: modular Python source protection and packaging toolkit."""
