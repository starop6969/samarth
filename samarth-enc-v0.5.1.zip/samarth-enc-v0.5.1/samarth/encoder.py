"""High-level protection API."""
from pathlib import Path
from .project import protect_file, protect_project, PROFILES
__all__ = ["protect_file","protect_project","PROFILES","Path"]
