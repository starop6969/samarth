from __future__ import annotations
import marshal, zlib, base64, hashlib, struct, secrets, sys

MAGIC = b"SAMENC04"

def pack_code(code, source_hash: str, metadata: dict) -> bytes:
    raw = marshal.dumps(code)
    compressed = zlib.compress(raw, 9)
    nonce = secrets.token_bytes(16)
    header = MAGIC + struct.pack(">H", sys.version_info.major) + struct.pack(">H", sys.version_info.minor)
    meta = repr(metadata).encode("utf-8")
    blob = header + struct.pack(">I", len(meta)) + meta + nonce + compressed
    digest = hashlib.sha256(blob).digest()
    return blob + digest

def unpack_code(blob: bytes):
    if not blob.startswith(MAGIC) or len(blob) < 40:
        raise ValueError("Invalid SAMARTH payload header")
    body, digest = blob[:-32], blob[-32:]
    if hashlib.sha256(body).digest() != digest:
        raise ValueError("Payload integrity verification failed")
    off = len(MAGIC) + 4
    mlen = struct.unpack(">I", body[off:off+4])[0]; off += 4
    meta = eval(body[off:off+mlen].decode("utf-8"), {"__builtins__": {}}, {})
    off += mlen + 16
    code = marshal.loads(zlib.decompress(body[off:]))
    return code, meta

def compile_source(source: str, filename: str, optimize: int = 0):
    return compile(source, filename, "exec", optimize=optimize)
