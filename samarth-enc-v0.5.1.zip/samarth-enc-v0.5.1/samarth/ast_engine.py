from __future__ import annotations
import ast, builtins, keyword, hashlib, random, string
from dataclasses import dataclass, field

@dataclass
class ASTConfig:
    rename_identifiers: bool = True
    transform_strings: bool = True
    optimize: int = 0
    seed: int | None = None

@dataclass
class TransformReport:
    renamed: int = 0
    strings_transformed: int = 0
    skipped: list[str] = field(default_factory=list)

class _Transformer(ast.NodeTransformer):
    def __init__(self, cfg: ASTConfig, report: TransformReport):
        self.cfg, self.report = cfg, report
        self.rng = random.Random(cfg.seed)
        self.map: dict[str, str] = {}
        self.reserved = set(keyword.kwlist) | set(dir(builtins))
        self.reserved |= {"self", "cls", "__name__", "__file__", "__package__",
                          "__spec__", "__loader__", "__builtins__"}
        self.scope_stack: list[set[str]] = [set()]
        self.module_bindings: set[str] = set()
        self.in_class = 0

    def _new_name(self, old: str) -> str:
        if old in self.map:
            return self.map[old]
        while True:
            n = "_s_" + ''.join(self.rng.choice(string.ascii_letters) for _ in range(10))
            if n not in self.reserved and n not in self.map.values():
                self.map[old] = n
                self.report.renamed += 1
                return n

    def _eligible(self, name: str) -> bool:
        return (self.cfg.rename_identifiers and name.isidentifier()
                and not name.startswith("__") and name not in self.reserved)

    def visit_Module(self, node):
        for n in node.body:
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                if self._eligible(n.name):
                    self.module_bindings.add(n.name)
            elif isinstance(n, (ast.Assign, ast.AnnAssign)):
                targets = n.targets if isinstance(n, ast.Assign) else [n.target]
                for t in targets:
                    if isinstance(t, ast.Name) and self._eligible(t.id):
                        self.module_bindings.add(t.id)
        self.scope_stack.append(self.module_bindings)
        node = self.generic_visit(node)
        self.scope_stack.pop()
        return node

    def visit_ClassDef(self, node):
        # Preserve class names: class identity is commonly used by imports,
        # reflection, pickling, serializers, and external callers.
        self.in_class += 1
        node = self.generic_visit(node)
        self.in_class -= 1
        return node

    def visit_FunctionDef(self, node):
        if self.in_class == 0 and self._eligible(node.name):
            node.name = self._new_name(node.name)
        local = set()
        for a in [*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs]:
            if self._eligible(a.arg):
                local.add(a.arg)
                a.arg = self._new_name(a.arg)
        if node.args.vararg and self._eligible(node.args.vararg.arg):
            local.add(node.args.vararg.arg)
            node.args.vararg.arg = self._new_name(node.args.vararg.arg)
        if node.args.kwarg and self._eligible(node.args.kwarg.arg):
            local.add(node.args.kwarg.arg)
            node.args.kwarg.arg = self._new_name(node.args.kwarg.arg)
        self.scope_stack.append(local)
        node = self.generic_visit(node)
        self.scope_stack.pop()
        return node

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_Name(self, node):
        if self._eligible(node.id) and (
            node.id in self.module_bindings or any(node.id in s for s in self.scope_stack)
        ):
            node.id = self._new_name(node.id)
        return node

    def visit_Constant(self, node):
        if self.cfg.transform_strings and isinstance(node.value, str) and node.value:
            data = node.value.encode("utf-8")
            key = self.rng.randrange(1, 256)
            enc = bytes(b ^ key for b in data).hex()
            encoded_bytes = ast.Call(
                func=ast.Attribute(
                    value=ast.Name(id="bytes", ctx=ast.Load()),
                    attr="fromhex", ctx=ast.Load()
                ),
                args=[ast.Constant(enc)], keywords=[]
            )
            decoded_bytes = ast.Call(
                func=ast.Name(id="bytes", ctx=ast.Load()),
                args=[ast.GeneratorExp(
                    elt=ast.BinOp(
                        left=ast.Name(id="b", ctx=ast.Load()),
                        op=ast.BitXor(),
                        right=ast.Constant(key)
                    ),
                    generators=[ast.comprehension(
                        target=ast.Name(id="b", ctx=ast.Store()),
                        iter=encoded_bytes, ifs=[], is_async=0
                    )]
                )],
                keywords=[]
            )
            expr = ast.Call(
                func=ast.Attribute(value=decoded_bytes, attr="decode", ctx=ast.Load()),
                args=[ast.Constant("utf-8")], keywords=[]
            )
            self.report.strings_transformed += 1
            return ast.copy_location(expr, node)
        return node

def transform(source: str, cfg: ASTConfig | None = None) -> tuple[str, TransformReport]:
    cfg = cfg or ASTConfig()
    tree = ast.parse(source)
    report = TransformReport()
    tree = _Transformer(cfg, report).visit(tree)
    ast.fix_missing_locations(tree)
    return ast.unparse(tree), report
