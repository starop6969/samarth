# SAMARTH ENC 0.4.0

SAMARTH ENC is a modular Python source-protection toolkit. It is designed to
raise the cost of casual source inspection while remaining honest about the
limits of Python protection.

## Profiles

- STANDARD: constant transformation + compilation.
- ADVANCED: STANDARD + conservative identifier renaming.
- MAXIMUM: ADVANCED + Python optimize=2.
- NATIVE: currently uses the same safe internal transformation as MAXIMUM; a
  native compiler is not claimed unless an external backend is selected.
- HYBRID: internal transformation plus optional external backend selection.
  The CLI delegates to an installed PyArmor or Nuitka backend.

These profiles are deliberately documented rather than pretending to provide
different cryptographic strength.

## Internal format

Source is parsed with `ast`, transformed, compiled to Python code objects,
marshalled, compressed with zlib, wrapped with build metadata, and protected
by a SHA-256 integrity digest. The runtime validates the digest before loading.

This is not encryption and is not tamper-proof. Python bytecode/code objects
and the runtime needed to execute them can ultimately be inspected by a
determined analyst. Compatibility is conservative around reflection,
decorators, dynamic `exec/eval`, metaprogramming, and special identifiers.

## CLI

```text
samarth --version
samarth inspect app.py
samarth protect app.py
samarth protect app.py --profile maximum
samarth protect app.py --backend pyarmor
samarth protect app.py --backend nuitka
samarth protect app.py --backend hybrid
```

## Runtime

`.sme` files are payload containers, not directly executable Python scripts.
Applications can load them with `samarth.runtime.execute_payload()`.

## Testing

Run:

```text
python -m unittest discover -s tests -v
python -m build
```

External PyArmor/Nuitka integrations are only tested when those tools are
installed in the environment. No claim is made for environments not tested.

## Publishing

Build with `python -m build`, then upload with your preferred PyPI publisher
such as `twine upload dist/*`.

## Multi-version CPython payloads (0.5.0)

SAMARTH 0.5.0 can build four version-specific `.sme` payloads for CPython 3.11, 3.12, 3.13 and 3.14:

```bash
samarth protect-multi app.py -o dist_multi
```

The four target CPython interpreters must be installed and discoverable, or can be supplied explicitly:

```bash
samarth protect-multi app.py -o dist_multi \
  --python311 /path/to/python3.11 \
  --python312 /path/to/python3.12 \
  --python313 /path/to/python3.13 \
  --python314 /path/to/python3.14
```

Output:

```text
dist_multi/
  app_py311.sme
  app_py312.sme
  app_py313.sme
  app_py314.sme
  manifest.json
```

The matching payload can be selected automatically at runtime:

```bash
samarth run-bundle dist_multi --name app
```

This loader selects by the running CPython major/minor version and performs the existing SAMARTH integrity verification before execution. A `.sme` remains Python-version-specific; the four payloads are not interchangeable. Windows, Linux, Termux and Pydroid can use the matching payload when they provide a compatible CPython runtime and the application's dependencies.

**Build requirement:** SAMARTH does not fake a target version. Each payload is compiled by the actual target CPython interpreter. If a target interpreter is missing, the multi-version command fails clearly instead of producing a mislabeled payload.
