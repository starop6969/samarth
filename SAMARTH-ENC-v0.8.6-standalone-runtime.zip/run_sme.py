from pathlib import Path
import argparse
import sys
from samarth.runtime import execute_payload

def main():
    parser = argparse.ArgumentParser(description="Run a SAMARTH .sme payload")
    parser.add_argument("payload", help="Path to the .sme file")
    args = parser.parse_args()
    path = Path(args.payload).expanduser().resolve()
    if not path.is_file():
        parser.error(f"Payload not found: {path}")
    namespace = {"__name__": "__main__", "__file__": str(path), "__package__": None}
    execute_payload(path.read_bytes(), namespace, str(path))

if __name__ == "__main__":
    main()
