"""Environment and backend capability detection for SAMARTH ENC."""
from __future__ import annotations

import importlib.util
import os
import platform
import shutil
import sys
import sysconfig
from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class EnvironmentInfo:
    python: str
    implementation: str
    os: str
    machine: str
    soabi: str | None
    platform: str
    pydroid: bool
    termux: bool
    android: bool
    compiler: str | None
    linker: str | None
    python_headers: bool
    python_library: str | None
    cython: bool
    nuitka: bool
    pyarmor: bool

    def as_dict(self) -> dict:
        return asdict(self)


def _find_compiler() -> str | None:
    for name in ("cc", "gcc", "clang", "cl"):
        path = shutil.which(name)
        if path:
            return path
    return None


def _find_linker() -> str | None:
    for name in ("ld", "lld-link", "ld.lld", "link"):
        path = shutil.which(name)
        if path:
            return path
    return None


def _android_runtime() -> bool:
    """Detect Android Python runtimes without assuming every Android is Pydroid."""
    if sys.platform == "android" or callable(getattr(sys, "getandroidapilevel", None)):
        return True
    if os.environ.get("ANDROID_ROOT") or os.environ.get("ANDROID_DATA"):
        return True
    paths = " ".join([sys.prefix, sys.executable, *sys.path]).lower()
    return "/data/user/0/" in paths or "/data/data/" in paths


def _environment_name(env: EnvironmentInfo) -> str:
    if env.pydroid:
        return "pydroid"
    if env.termux:
        return "termux"
    if env.android:
        return "android"
    return env.os.lower()


def detect_environment() -> EnvironmentInfo:
    prefix = os.environ.get("PREFIX", "")
    runtime_paths = " ".join([sys.prefix, sys.executable, *sys.path]).lower()
    android = _android_runtime()
    pydroid = (
        bool(os.environ.get("PYDROID_ARGUMENT"))
        or "pydroid" in runtime_paths
        or "ru.iiec.pydroid3" in runtime_paths
        or "com.iiec.pydroid3" in runtime_paths
    )
    termux = (
        bool(os.environ.get("TERMUX_VERSION"))
        or "/com.termux/" in sys.executable
        or "/data/data/com.termux/" in sys.prefix
        or prefix.startswith("/data/data/com.termux/")
    )
    include = sysconfig.get_config_var("INCLUDEPY")
    headers = bool(include and os.path.isfile(os.path.join(include, "Python.h")))
    libdir = sysconfig.get_config_var("LIBDIR")
    ldlib = sysconfig.get_config_var("LDLIBRARY")
    library = os.path.join(libdir, ldlib) if libdir and ldlib else None
    if not (library and os.path.exists(library)):
        library = None
    return EnvironmentInfo(
        python=f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        implementation=platform.python_implementation(),
        os=platform.system(),
        machine=platform.machine(),
        soabi=sysconfig.get_config_var("SOABI"),
        platform=sysconfig.get_platform(),
        pydroid=pydroid,
        termux=termux,
        android=android,
        compiler=_find_compiler(),
        linker=_find_linker(),
        python_headers=headers,
        python_library=library,
        cython=importlib.util.find_spec("Cython") is not None,
        nuitka=importlib.util.find_spec("nuitka") is not None or shutil.which("nuitka") is not None,
        pyarmor=importlib.util.find_spec("pyarmor") is not None or shutil.which("pyarmor") is not None,
    )


def native_capability() -> tuple[bool, str, str | None]:
    """Return (supported, backend_kind, reason) from local build prerequisites.

    Android builds deliberately use a Cython extension loaded by the active
    Python interpreter. We do not claim that a desktop-style embedded executable
    can be produced or run on Pydroid/Termux.
    """
    env = detect_environment()
    if not env.android and env.nuitka and env.compiler:
        return True, "nuitka", None
    if env.cython and env.compiler and env.python_headers and importlib.util.find_spec("setuptools") is not None:
        return True, "cython-extension", None
    missing = []
    if not env.cython:
        missing.append("Cython")
    if not env.compiler:
        missing.append("C/C++ compiler")
    if not env.python_headers:
        missing.append("Python development headers (Python.h)")
    if importlib.util.find_spec("setuptools") is None:
        missing.append("setuptools")
    if env.android:
        missing.append("a compatible Android/Python ABI toolchain (must be verified on-device)")
    return False, "none", "missing or unverified: " + ", ".join(missing)


def hybrid_capability() -> tuple[bool, str, str | None]:
    env = detect_environment()
    if not env.android and env.nuitka:
        return True, "nuitka+internal", None
    if env.cython and env.compiler and env.python_headers and importlib.util.find_spec("setuptools") is not None:
        return True, "cython+internal", None
    ok, _, reason = native_capability()
    return ok, "none", reason
