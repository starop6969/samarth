from __future__ import annotations

"""Runtime literal packing used by SAMARTH 0.6.3.

This is obfuscation, not confidentiality.  The salt and decoding algorithm are
present in the executing program, so an attacker who controls execution can
recover the values.  Its purpose is to remove plaintext literals from the
static code object's constant table and make automated recovery more involved.
"""

import hashlib
import marshal

MAX_LITERAL_PAYLOAD = 16 * 1024 * 1024


def _keystream(salt: bytes, length: int) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < length:
        out.extend(hashlib.sha256(salt + counter.to_bytes(8, "big")).digest())
        counter += 1
    return bytes(out[:length])


def pack_value(value, salt: bytes) -> bytes:
    raw = marshal.dumps(value, 4)
    stream = _keystream(salt, len(raw))
    return bytes((a + b) & 0xFF for a, b in zip(raw, stream))


def unpack_value(payload: bytes, salt: bytes):
    stream = _keystream(salt, len(payload))
    raw = bytes((a - b) & 0xFF for a, b in zip(payload, stream))
    return marshal.loads(raw)


def pack_pool(values, salt: bytes) -> bytes:
    """Pack the complete literal pool once to avoid per-literal runtime work."""
    return pack_value(tuple(values), salt)


def unpack_pool(payload: bytes, salt: bytes):
    values = unpack_value(payload, salt)
    if not isinstance(values, tuple):
        raise ValueError("SAMARTH literal pool is invalid")
    return values
