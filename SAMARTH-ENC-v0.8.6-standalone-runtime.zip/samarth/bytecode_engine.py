from __future__ import annotations

"""SAMARTH v0.6.6 compiled-code payload container.

The internal payload stores a CPython CodeType representation, not Python
source. v0.6.6 keeps the v0.6.2 through v0.6.6 containers readable by the runtime while the
new format removes unnecessary source/build metadata and strips the absolute
source filename from compiled code objects. SHA-256 is integrity only.
"""

import hashlib
import json
import marshal
import secrets
import struct
import sys
import types
import zlib

MAGIC = b"SAMENC67"
LEGACY_MAGIC = b"SAMENC65"
LEGACY_MAGIC_V66 = b"SAMENC66"
LEGACY_MAGIC_V64 = b"SAMENC64"
LEGACY_MAGIC_V63 = b"SAMENC63"
LEGACY_MAGIC_V62 = b"SAMENC62"
FORMAT_VERSION = 9
MAX_PAYLOAD_SIZE = 64 * 1024 * 1024
MAX_METADATA_SIZE = 256 * 1024
MAX_CODE_BLOB_SIZE = 48 * 1024 * 1024
LEGACY_FORMAT_VERSION = 6
LEGACY_FORMAT_VERSION_V66 = 7
LEGACY_FORMAT_VERSION_V64 = 5
LEGACY_FORMAT_VERSION_V63 = 4
LEGACY_FORMAT_VERSION_V62 = 3
HEADER = struct.Struct(">8sBBHI")


def _canonical_meta(meta: dict) -> bytes:
    return json.dumps(meta, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def obfuscate_local_names(code):
    """Rename local/cell/free variable names without changing bytecode indices.

    CPython bytecode addresses locals by index, not by spelling, so changing
    co_varnames/co_cellvars/co_freevars preserves execution while removing
    another major source of identifier leakage. Argument positions remain
    unchanged; only their visible names change. Public module/class attributes
    and global names are intentionally preserved.
    """
    if not isinstance(code, types.CodeType):
        raise TypeError("expected code object")
    consts = tuple(obfuscate_local_names(c) if isinstance(c, types.CodeType) else c for c in code.co_consts)
    def repl(names, prefix, preserve=frozenset()):
        return tuple(name if name in preserve else f"{prefix}{i:03x}" for i, name in enumerate(names))
    arg_count = code.co_posonlyargcount + code.co_argcount + code.co_kwonlyargcount
    if code.co_flags & 0x04:              
        arg_count += 1
    if code.co_flags & 0x08:                  
        arg_count += 1
    preserved_args = frozenset(code.co_varnames[:arg_count])
    varnames = repl(code.co_varnames, "_l_", preserved_args) if code.co_varnames else code.co_varnames
                                                                             
                                                                              
                                     
    special_closure_names = frozenset({"__class__", "__classdict__"})
    cell_preserve = preserved_args | special_closure_names
    cellvars = repl(code.co_cellvars, "_c_", cell_preserve) if code.co_cellvars else code.co_cellvars
    freevars = repl(code.co_freevars, "_f_", special_closure_names) if code.co_freevars else code.co_freevars
    return code.replace(co_consts=consts, co_varnames=varnames, co_cellvars=cellvars, co_freevars=freevars)


def sanitize_code_metadata(code):
    """Remove build-path information while preserving executable semantics.

    Function names/qualnames, constants, locals, closures, exception tables
    and line information are deliberately retained because changing those can
    break reflection, tracebacks or normal Python behavior. Only the compiled
    filename is replaced recursively.
    """
    if not isinstance(code, types.CodeType):
        raise TypeError("expected code object")
    consts = tuple(sanitize_code_metadata(c) if isinstance(c, types.CodeType) else c for c in code.co_consts)
    return code.replace(co_filename="<samarth>", co_consts=consts)


def pack_code(code, metadata: dict) -> bytes:
    code = sanitize_code_metadata(code)
    code = obfuscate_local_names(code)
    meta = _canonical_meta(metadata)
    code_blob = marshal.dumps(code, 4)
    compressed = zlib.compress(code_blob, level=9)
    body = MAGIC + bytes([FORMAT_VERSION]) + struct.pack(">I", len(meta)) + meta + compressed
    return body + hashlib.sha256(body).digest()


def _safe_decompress(data: bytes, limit: int = MAX_CODE_BLOB_SIZE) -> bytes:
    if len(data) > MAX_PAYLOAD_SIZE:
        raise ValueError("SAMARTH compressed payload exceeds size limit")
    d = zlib.decompressobj()
    raw = d.decompress(data, limit + 1)
    if len(raw) > limit or not d.eof or d.unused_data:
        raise ValueError("SAMARTH compressed payload exceeds resource limits or is malformed")
    return raw

def _unpack(blob: bytes, magic: bytes, version_expected: int):
    if len(blob) > MAX_PAYLOAD_SIZE:
        raise ValueError("SAMARTH payload exceeds size limit")
    if len(blob) < 13 + 32 or not blob.startswith(magic):
        raise ValueError("Invalid SAMARTH compiled payload header")
    body, digest = blob[:-32], blob[-32:]
    if not secrets.compare_digest(hashlib.sha256(body).digest(), digest):
        raise ValueError("SAMARTH payload integrity verification failed")
    version = body[8]
    if version != version_expected:
        raise ValueError(f"Unsupported SAMARTH payload format version: {version}")
    meta_len = struct.unpack(">I", body[9:13])[0]
    meta_start = 13
    meta_end = meta_start + meta_len
    if meta_len > MAX_METADATA_SIZE or meta_end > len(body):
        raise ValueError("SAMARTH metadata exceeds size limit or is truncated")
    try:
        meta = json.loads(body[meta_start:meta_end].decode("utf-8"))
        code_raw = _safe_decompress(body[meta_end:])
        if len(code_raw) > MAX_CODE_BLOB_SIZE:
            raise ValueError("SAMARTH code blob exceeds size limit")
        code = marshal.loads(code_raw)
    except Exception as exc:
        raise ValueError("SAMARTH compiled payload decoding failed") from exc
    if not isinstance(code, types.CodeType):
        raise ValueError("SAMARTH payload did not contain a code object")
    return code, meta


LEGACY_MAGIC_V67 = b"SAMENC67"
LEGACY_FORMAT_VERSION_V67 = 8

def unpack_code(blob: bytes):
    if blob.startswith(MAGIC):
        if len(blob) < 9:
            raise ValueError("Invalid SAMARTH compiled payload header")
        version = blob[8]
        if version == FORMAT_VERSION:
            return _unpack(blob, MAGIC, FORMAT_VERSION)
        if version == LEGACY_FORMAT_VERSION_V67:
            return _unpack(blob, LEGACY_MAGIC_V67, LEGACY_FORMAT_VERSION_V67)
        raise ValueError(f"Unsupported SAMARTH payload format version: {version}")
    if blob.startswith(LEGACY_MAGIC_V66):
        return _unpack(blob, LEGACY_MAGIC_V66, LEGACY_FORMAT_VERSION_V66)
    if blob.startswith(LEGACY_MAGIC):
        return _unpack(blob, LEGACY_MAGIC, LEGACY_FORMAT_VERSION)
    if blob.startswith(LEGACY_MAGIC_V64):
        return _unpack(blob, LEGACY_MAGIC_V64, LEGACY_FORMAT_VERSION_V64)
    if blob.startswith(LEGACY_MAGIC_V63):
        return _unpack(blob, LEGACY_MAGIC_V63, LEGACY_FORMAT_VERSION_V63)
    if blob.startswith(LEGACY_MAGIC_V62):
        return _unpack(blob, LEGACY_MAGIC_V62, LEGACY_FORMAT_VERSION_V62)
    raise ValueError("Invalid SAMARTH compiled payload header")


def compile_source(source: str, filename: str = "<samarth>", optimize: int = 0):
    return compile(source, "<samarth>", "exec", optimize=optimize)


def payload_sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def unpack_source(blob: bytes):
    raise ValueError("SAMARTH compiled payload contains compiled code, not a source payload; use unpack_code().")


def pack_source(source: str, metadata: dict) -> bytes:
    code = compile_source(source, "<samarth>", int(metadata.get("optimize", 0)))
    return pack_code(code, metadata)


VM_MARKER = "__SAMARTH_VM_V2__"
MODULE_VM_MARKER = "__SAMARTH_MODULE_VM_V2__"

def pack_vm_code(vm_blob: bytes, metadata: dict) -> bytes:
    marker = (VM_MARKER, bytes(vm_blob))
    code = compile("__samarth_vm_marker = None", "<samarth>", "exec")
    consts = tuple(marker if x is None else x for x in code.co_consts)
    code = code.replace(co_consts=consts)
    meta = dict(metadata)
    meta.setdefault("execution_model", "function-vm-v2")
    meta = _canonical_meta(meta)
    code_blob = marshal.dumps(sanitize_code_metadata(code), 4)
    compressed = zlib.compress(code_blob, 9)
    body = MAGIC + bytes([FORMAT_VERSION]) + struct.pack(">I", len(meta)) + meta + compressed
    return body + hashlib.sha256(body).digest()


def pack_function_vm_code(code, vm_blob: bytes, metadata: dict) -> bytes:
    marker=(VM_MARKER,bytes(vm_blob))
    code=sanitize_code_metadata(code)
    consts=tuple(code.co_consts)
    if marker not in consts: consts=consts+(marker,)
    code=code.replace(co_consts=consts)
    return pack_code(code, metadata)

def extract_vm_blob(code) -> bytes | None:
    for c in code.co_consts:
        if isinstance(c, tuple) and len(c) == 2 and c[0] in {VM_MARKER, MODULE_VM_MARKER, "__SAMARTH_VM_V1__"} and isinstance(c[1], (bytes, bytearray)):
            return bytes(c[1])
    return None

def extract_vm_blob_kind(code) -> tuple[bytes | None, bool]:
    blob = extract_vm_blob(code)
    return (blob, False) if blob is not None else (None, False)
