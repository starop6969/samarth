__version__ = "0.8.6"

"""SAMARTH ENC: keyless offline Python source protection toolkit."""
