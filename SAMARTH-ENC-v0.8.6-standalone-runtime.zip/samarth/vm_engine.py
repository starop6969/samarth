
from __future__ import annotations
import ast, asyncio, builtins, importlib, inspect, marshal, types, zlib

MAX_CAPSULE_SIZE = 64 * 1024 * 1024
MAX_CAPSULE_RAW = 48 * 1024 * 1024
from dataclasses import dataclass

MAGIC = b"SAMVM65"
VERSION = 1
_MISSING = object()

class _Return(Exception):
    def __init__(self, value): self.value=value
class _Break(Exception): pass
class _Continue(Exception): pass
class _YieldSignal(Exception):
    def __init__(self, value): self.value=value

@dataclass
class _Env:
    data: dict
    parent: "_Env|None" = None
    global_names: set | None = None
    nonlocal_names: set | None = None
    def _root(self):
        env = self
        while env.parent is not None:
            env = env.parent
        return env
    def _nonlocal_owner(self, name):
        env = self.parent
        while env is not None and env.parent is not None:
            if name in env.data:
                return env
            env = env.parent
        return None
    def get(self, name):
        if self.global_names and name in self.global_names:
            owner = self._root()
            if name in owner.data:
                value = owner.data[name]
                if value is _MISSING:
                    raise NameError(name)
                return value
            if name in builtins.__dict__: return builtins.__dict__[name]
            raise NameError(name)
        if self.nonlocal_names and name in self.nonlocal_names:
            owner = self._nonlocal_owner(name)
            if owner is None:
                raise NameError(name)
            value = owner.data[name]
            if value is _MISSING:
                raise UnboundLocalError(f"free variable '{name}' referenced before assignment")
            return value
        if name in self.data:
            value = self.data[name]
            if value is _MISSING:
                raise UnboundLocalError(f"local variable '{name}' referenced before assignment")
            return value
        if self.parent is not None: return self.parent.get(name)
        if name in builtins.__dict__: return builtins.__dict__[name]
        raise NameError(name)
    def set_local(self,name,val): self.data[name]=val
    def find(self,name):
        if name in self.data: return self
        if self.parent is not None: return self.parent.find(name)
        return None
    def set(self,name,val):
        if self.global_names and name in self.global_names:
            self._root().data[name] = val
            return
        if self.nonlocal_names and name in self.nonlocal_names:
            owner = self._nonlocal_owner(name)
            if owner is None:
                raise NameError(f"no binding for nonlocal '{name}' found")
            owner.data[name] = val
            return
        e=self.find(name)
        (e if e else self).data[name]=val

class VMFunction:
    def __init__(self, runtime, fid, name, node, closure, defaults=(), kwdefaults=None, annotations=None, is_async=False, is_generator=False):
        self._rt=runtime; self._fid=fid; self.__name__=name; self.__qualname__=name
        self._node=node; self._closure=closure
        self.__defaults__=tuple(defaults); self.__kwdefaults__=kwdefaults or {}
        self.__annotations__=annotations or {}; self.__module__=closure.data.get("__name__", "__main__")
        try:
            params=[]
            positional=list(node.args.posonlyargs)+list(node.args.args)
            default_start=len(positional)-len(node.args.defaults)
            for i,a in enumerate(positional):
                default=node.args.defaults[i-default_start] if i >= default_start else inspect._empty
                kind=inspect.Parameter.POSITIONAL_ONLY if i < len(node.args.posonlyargs) else inspect.Parameter.POSITIONAL_OR_KEYWORD
                params.append(inspect.Parameter(a.arg,kind,default=default))
            for a in node.args.kwonlyargs:
                default=self.__kwdefaults__.get(a.arg,inspect._empty)
                params.append(inspect.Parameter(a.arg,inspect.Parameter.KEYWORD_ONLY,default=default))
            if node.args.vararg: params.append(inspect.Parameter(node.args.vararg.arg,inspect.Parameter.VAR_POSITIONAL))
            if node.args.kwarg: params.append(inspect.Parameter(node.args.kwarg.arg,inspect.Parameter.VAR_KEYWORD))
            self.__signature__=inspect.Signature(params)
        except Exception:
            pass
        self._is_async=is_async; self._is_generator=is_generator
        self.__doc__ = ast.get_docstring(node)
    def __get__(self,obj,owner=None):
        if obj is None: return self
        return _BoundVMFunction(self,obj)
    def __call__(self,*args,**kwargs):
        if self._is_async:
            return self._rt._call_async(self,args,kwargs)
        if self._is_generator:
            return self._rt._call_gen(self,args,kwargs)
        return self._rt._call(self,args,kwargs)
    def __repr__(self): return f"<samarth function {self.__qualname__}>"

class _BoundVMFunction:
    def __init__(self, fn,obj): self.fn=fn; self.obj=obj
    def __call__(self,*args,**kwargs): return self.fn(self.obj,*args,**kwargs)
    def __getattr__(self,k): return getattr(self.fn,k)
    @property
    def __name__(self): return self.fn.__name__

class VMRuntime:
    def __init__(self, ast_tree, globals_dict):
        self.tree=ast_tree
        self.globals=globals_dict
        self.functions={}
        self.functions_list=[n for n in ast.walk(ast_tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
        self._register_tree(ast_tree)
    def _register_tree(self,node):
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            self.functions[id(node)]=node
        for child in ast.iter_child_nodes(node): self._register_tree(child)
    def _bind_args(self, node, args, kwargs, defaults=_MISSING, kwdefaults=_MISSING, eval_env=None):
        posonly=list(node.args.posonlyargs); pos=list(node.args.args); kwonly=list(node.args.kwonlyargs)
        positional=posonly+pos
        names=[a.arg for a in positional]
        if len(args) > len(names) and node.args.vararg is None:
            raise TypeError(f"{node.name}() takes {len(names)} positional arguments but {len(args)} were given")
        data={}
        for n,v in zip(names,args): data[n]=v
        remaining_kwargs=dict(kwargs)
        for a in posonly:
            if a.arg in remaining_kwargs:
                raise TypeError(f"{node.name}() got some positional-only arguments passed as keyword arguments: {a.arg}")
        if defaults is _MISSING:
            defaults=tuple(self._eval(x, eval_env or self._module_env) for x in node.args.defaults)
        first_default=len(names)-len(defaults)
        positional_only_names = {a.arg for a in posonly}
        for idx,n in enumerate(names):
                                                                            
                                                                             
            if n in remaining_kwargs and n not in positional_only_names:
                if n in data:
                    raise TypeError(f"{node.name}() got multiple values for argument {n!r}")
                data[n] = remaining_kwargs.pop(n)
            elif n not in data and idx >= first_default:
                data[n]=defaults[idx-first_default]
            elif n not in data:
                raise TypeError(f"{node.name}() missing required positional argument: {n!r}")
        if kwdefaults is _MISSING:
            kwdefaults={}
            for a,v in zip(kwonly,node.args.kw_defaults):
                if v is not None: kwdefaults[a.arg]=self._eval(v, eval_env or self._module_env)
        for a in kwonly:
            if a.arg in remaining_kwargs:
                if a.arg in data:
                    raise TypeError(f"{node.name}() got multiple values for argument {a.arg!r}")
                data[a.arg]=remaining_kwargs.pop(a.arg)
            elif a.arg in kwdefaults:
                data[a.arg]=kwdefaults[a.arg]
            else:
                raise TypeError(f"{node.name}() missing required keyword-only argument: {a.arg}")
        if node.args.vararg:
            data[node.args.vararg.arg]=tuple(args[len(names):])
        if node.args.kwarg:
            data[node.args.kwarg.arg]=remaining_kwargs
            remaining_kwargs={}
        if remaining_kwargs:
            bad=next(iter(remaining_kwargs)); raise TypeError(f"{node.name}() got an unexpected keyword argument {bad!r}")
        return data
    @property
    def _module_env(self):
        return _Env(self.globals)
    def _local_bindings(self, node):
        """Collect function-local names without crossing nested scopes."""
        names = set()
        class Collector(ast.NodeVisitor):
            def visit_Name(self, n):
                if isinstance(n.ctx, (ast.Store, ast.Del)):
                    names.add(n.id)
            def visit_Import(self, n):
                for alias in n.names:
                    names.add(alias.asname or alias.name.split(".")[0])
            def visit_ImportFrom(self, n):
                for alias in n.names:
                    if alias.name != "*": names.add(alias.asname or alias.name)
            def visit_FunctionDef(self, n):
                names.add(n.name)
            def visit_AsyncFunctionDef(self, n):
                names.add(n.name)
            def visit_ClassDef(self, n):
                names.add(n.name)
            def visit_Lambda(self, n):
                return
            def visit_ListComp(self, n):
                return
            visit_SetComp = visit_ListComp
            visit_DictComp = visit_ListComp
            visit_GeneratorExp = visit_ListComp
        collector = Collector()
        for statement in node.body:
            collector.visit(statement)
        return names

    def _scope_directives(self, node):
        global_names = set()
        nonlocal_names = set()
        class Collector(ast.NodeVisitor):
            def visit_Global(self, item):
                global_names.update(item.names)
            def visit_Nonlocal(self, item):
                nonlocal_names.update(item.names)
            def visit_FunctionDef(self, item):
                if item is not node:
                    return
                for child in item.body:
                    self.visit(child)
            visit_AsyncFunctionDef = visit_FunctionDef
            def visit_Lambda(self, item):
                return
            def visit_ClassDef(self, item):
                return
        collector = Collector()
        for statement in node.body:
            collector.visit(statement)
        return global_names, nonlocal_names

    def _function_env(self, node, args, kwargs, closure, defaults=_MISSING, kwdefaults=_MISSING):
        data = self._bind_args(node, args, dict(kwargs), defaults, kwdefaults, closure)
        for name in self._local_bindings(node):
            data.setdefault(name, _MISSING)
        global_names, nonlocal_names = self._scope_directives(node)
        if global_names & nonlocal_names:
            raise SyntaxError("name declared both global and nonlocal")
        return _Env(data, closure, global_names, nonlocal_names)

    def _call(self, fn,args,kwargs):
        node=fn._node if isinstance(fn,VMFunction) else fn
        if isinstance(fn,VMFunction):
            env=self._function_env(node,args,kwargs,fn._closure,fn.__defaults__,fn.__kwdefaults__)
        else:
            closure=self._module_env
            env=self._function_env(node,args,kwargs,closure)
        try:
            self._exec_block(node.body,env)
        except _Return as r: return r.value
        return None
    async def _call_async(self,fn,args,kwargs):
        node=fn._node
        env=self._function_env(node,args,kwargs,fn._closure,fn.__defaults__,fn.__kwdefaults__)
        try: await self._exec_block_async(node.body,env)
        except _Return as r: return r.value
        return None
    def _call_gen(self,fn,args,kwargs):
        node=fn._node; env=self._function_env(node,args,kwargs,fn._closure,fn.__defaults__,fn.__kwdefaults__)
        yield from self._exec_gen_block(node.body,env)
    def _make_fn(self,node,env):
        defaults=tuple(self._eval(x,env) for x in node.args.defaults)
        kwdefaults={}
        for a,v in zip(node.args.kwonlyargs,node.args.kw_defaults):
            if v is not None: kwdefaults[a.arg]=self._eval(v,env)
        fn=VMFunction(self,id(node),node.name,node,env,defaults,kwdefaults,
                      is_async=isinstance(node,ast.AsyncFunctionDef),is_generator=any(isinstance(x,ast.Yield) for x in ast.walk(node)))
                                                                                      
        return fn
    def _eval(self,node,env):
        if isinstance(node,ast.Constant): return node.value
        if isinstance(node,ast.Name): return env.get(node.id)
        if isinstance(node,ast.List):
            out=[]
            for x in node.elts:
                if isinstance(x,ast.Starred): out.extend(self._eval(x.value,env))
                else: out.append(self._eval(x,env))
            return out
        if isinstance(node,ast.Tuple):
            out=[]
            for x in node.elts:
                if isinstance(x,ast.Starred): out.extend(self._eval(x.value,env))
                else: out.append(self._eval(x,env))
            return tuple(out)
        if isinstance(node,ast.Set): return {self._eval(x,env) for x in node.elts}
        if isinstance(node,ast.Dict):
            out={}
            for k,v in zip(node.keys,node.values):
                if k is None:
                    out.update(self._eval(v,env))
                else:
                    out[self._eval(k,env)] = self._eval(v,env)
            return out
        if isinstance(node,ast.Attribute): return getattr(self._eval(node.value,env),node.attr)
        if isinstance(node,ast.Subscript):
            v=self._eval(node.value,env); sl=self._eval_slice(node.slice,env); return v[sl]
        if isinstance(node,ast.BinOp): return self._binop(node.op,self._eval(node.left,env),self._eval(node.right,env))
        if isinstance(node,ast.UnaryOp): return self._unop(node.op,self._eval(node.operand,env))
        if isinstance(node,ast.BoolOp):
            if isinstance(node.op,ast.And):
                r=None
                for x in node.values:
                    r=self._eval(x,env)
                    if not r: return r
                return r
            r=None
            for x in node.values:
                r=self._eval(x,env)
                if r: return r
            return r
        if isinstance(node,ast.Compare):
            left=self._eval(node.left,env)
            for op,rightn in zip(node.ops,node.comparators):
                right=self._eval(rightn,env)
                if not self._compare(op,left,right): return False
                left=right
            return True
        if isinstance(node,ast.IfExp): return self._eval(node.body if self._eval(node.test,env) else node.orelse,env)
        if isinstance(node,ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == "super" and not node.args and not node.keywords:
                obj = env.data.get("self", _MISSING)
                if obj is not _MISSING:
                    return super(obj.__class__, obj)
                cls = env.data.get("cls", _MISSING)
                if cls is not _MISSING:
                    return super(cls, cls)
                raise RuntimeError("zero-argument super() requires self or cls")
            fn=self._eval(node.func,env); args=[]
            for a in node.args:
                if isinstance(a,ast.Starred): args.extend(self._eval(a.value,env))
                else: args.append(self._eval(a,env))
            kwargs={k.arg:self._eval(k.value,env) for k in node.keywords if k.arg is not None}
            if any(k.arg is None for k in node.keywords):
                for k in node.keywords:
                    if k.arg is None: kwargs.update(self._eval(k.value,env))
            return fn(*args,**kwargs)
        if isinstance(node,ast.Lambda):
            return self._lambda(node,env)
        if isinstance(node,ast.ListComp): return self._comp(node,env,list)
        if isinstance(node,ast.SetComp): return self._comp(node,env,set)
        if isinstance(node,ast.DictComp): return self._dictcomp(node,env)
        if isinstance(node,ast.GeneratorExp): return (x for x in self._comp_iter(node,env))
        if isinstance(node,ast.JoinedStr):
            parts=[]
            for v in node.values:
                if isinstance(v,ast.Constant):
                    parts.append(str(v.value))
                elif isinstance(v,ast.FormattedValue):
                    value = self._eval(v.value,env)
                    if v.conversion == ord('s'):
                        value = str(value)
                    elif v.conversion == ord('r'):
                        value = repr(value)
                    elif v.conversion == ord('a'):
                        value = ascii(value)
                    elif v.conversion != -1:
                        raise ValueError(f"unsupported f-string conversion: {v.conversion}")
                    spec = self._format_spec(v.format_spec,env)
                    parts.append(format(value, spec))
                else:
                    parts.append(str(self._eval(v,env)))
            return ''.join(parts)
        if isinstance(node,ast.FormattedValue):
            value = self._eval(node.value,env)
            if node.conversion == ord('s'): return str(value)
            if node.conversion == ord('r'): return repr(value)
            if node.conversion == ord('a'): return ascii(value)
            if node.conversion not in (-1,):
                raise ValueError(f"unsupported f-string conversion: {node.conversion}")
            return value
        if isinstance(node,ast.Await):
            raise RuntimeError("await is only valid in async evaluator")
        if isinstance(node,ast.Yield):
            raise _YieldSignal(self._eval(node.value,env) if node.value else None)
        raise NotImplementedError(f"unsupported expression: {type(node).__name__}")
    async def _eval_async(self,node,env):
        if isinstance(node,ast.Await): return await self._eval(node.value,env)
        if isinstance(node,ast.Call):
            fn=self._eval(node.func,env); args=[await self._eval_async(a,env) if isinstance(a,ast.Await) else self._eval(a,env) for a in node.args]
            kwargs={k.arg:self._eval(k.value,env) for k in node.keywords if k.arg is not None}
            return await fn(*args,**kwargs) if inspect.iscoroutinefunction(fn) else fn(*args,**kwargs)
        if isinstance(node,ast.BinOp): return self._binop(node.op,await self._eval_async(node.left,env) if isinstance(node.left,ast.Await) else self._eval(node.left,env), self._eval(node.right,env))
        if isinstance(node,ast.IfExp): return await self._eval_async(node.body if self._eval(node.test,env) else node.orelse,env)
        return self._eval(node,env)
    def _eval_slice(self,node,env):
        if isinstance(node,ast.Slice): return slice(self._eval(node.lower,env) if node.lower else None,self._eval(node.upper,env) if node.upper else None,self._eval(node.step,env) if node.step else None)
        if isinstance(node,ast.Tuple):
            out=[]
            for x in node.elts:
                if isinstance(x,ast.Starred): out.extend(self._eval(x.value,env))
                else: out.append(self._eval(x,env))
            return tuple(out)
        return self._eval(node,env)
    def _lambda(self,node,env):
        fake=ast.FunctionDef(name="<lambda>",args=node.args,body=[ast.Return(node.body)],decorator_list=[])
        return VMFunction(self,id(node),"<lambda>",fake,env,is_generator=False)
    def _comp_iter(self,node,env):
        def rec(i,e):
            if i==len(node.generators):
                yield self._eval(node.elt,e); return
            g=node.generators[i]
            for value in self._eval(g.iter,e):
                child=_Env({},e); self._assign(g.target,value,child)
                if all(self._eval(c,child) for c in g.ifs): yield from rec(i+1,child)
        yield from rec(0,env)
    def _comp(self,node,env,ctor):
        return ctor(self._comp_iter(node,env))
    def _dictcomp(self,node,env):
        return {self._eval(node.key,e):self._eval(node.value,e) for e in self._comp_envs(node,env)}
    def _comp_envs(self,node,env):
        def rec(i,e):
            if i==len(node.generators): yield e; return
            g=node.generators[i]
            for value in self._eval(g.iter,e):
                child=_Env({},e); self._assign(g.target,value,child)
                if all(self._eval(c,child) for c in g.ifs): yield from rec(i+1,child)
        yield from rec(0,env)
    def _format_spec(self,node,env): return '' if node is None else str(self._eval(node,env))
    def _assign(self,target,value,env):
        if isinstance(target,ast.Name): env.set(target.id,value)
        elif isinstance(target,ast.Tuple): 
            for t,v in zip(target.elts,value): self._assign(t,v,env)
        elif isinstance(target,ast.Attribute): setattr(self._eval(target.value,env),target.attr,value)
        elif isinstance(target,ast.Subscript): self._eval(target.value,env)[self._eval_slice(target.slice,env)]=value
        else: raise NotImplementedError(type(target).__name__)
    def _exec_block(self,body,env):
        for st in body: self._exec(st,env)
    async def _exec_block_async(self,body,env):
        for st in body: await self._exec_async(st,env)
    def _exec_gen_block(self,body,env):
        for st in body:
            yield from self._exec_gen(st,env)
    def _exec(self,st,env):
        if isinstance(st,ast.Expr): self._eval(st.value,env); return
        if isinstance(st,ast.Assign):
            v=self._eval(st.value,env)
            for t in st.targets:self._assign(t,v,env)
            return
        if isinstance(st,ast.AnnAssign):
            if st.value is None: return
            v=self._eval(st.value,env); self._assign(st.target,v,env); return
        if isinstance(st,ast.Assert):
            if not self._eval(st.test,env):
                msg=self._eval(st.msg,env) if st.msg is not None else None
                raise AssertionError(msg)
            return
        if isinstance(st,ast.Delete):
            for target in st.targets:
                if isinstance(target,ast.Name):
                    owner=env.find(target.id)
                    if owner is None: raise NameError(target.id)
                    del owner.data[target.id]
                elif isinstance(target,ast.Attribute): delattr(self._eval(target.value,env),target.attr)
                elif isinstance(target,ast.Subscript): del self._eval(target.value,env)[self._eval_slice(target.slice,env)]
                else: raise NotImplementedError(type(target).__name__)
            return
        if isinstance(st,(ast.Global,ast.Nonlocal)):
            return
        if isinstance(st,ast.AugAssign):
            cur=self._eval(st.target,env); v=self._binop(st.op,cur,self._eval(st.value,env)); self._assign(st.target,v,env); return
        if isinstance(st,ast.Return): raise _Return(self._eval(st.value,env) if st.value else None)
        if isinstance(st,ast.If):
            self._exec_block(st.body if self._eval(st.test,env) else st.orelse,env); return
        if isinstance(st,ast.For):
            for v in self._eval(st.iter,env):
                self._assign(st.target,v,env)
                try:self._exec_block(st.body,env)
                except _Continue:continue
                except _Break:break
            else:self._exec_block(st.orelse,env)
            return
        if isinstance(st,ast.While):
            while self._eval(st.test,env):
                try:self._exec_block(st.body,env)
                except _Continue:continue
                except _Break:break
            else:self._exec_block(st.orelse,env)
            return
        if isinstance(st,ast.Break): raise _Break()
        if isinstance(st,ast.Continue): raise _Continue()
        if isinstance(st,(ast.FunctionDef,ast.AsyncFunctionDef)):
            fn=self._make_fn(st,env)
            for dec in reversed(st.decorator_list): fn=self._eval(dec,env)(fn)
            env.set(st.name,fn); return
        if isinstance(st,ast.ClassDef):
            bases=[self._eval(b,env) for b in st.bases]
            ns={}
                                                                        
            class_doc = ast.get_docstring(st, clean=False)
            if class_doc is not None:
                ns["__doc__"] = class_doc
            classenv=_Env(ns,env)
            for item in st.body:
                if isinstance(item,(ast.FunctionDef,ast.AsyncFunctionDef)):
                    fn=self._make_fn(item,classenv)
                    for dec in reversed(item.decorator_list): fn=self._eval(dec,classenv)(fn)
                    ns[item.name]=fn
                elif isinstance(item,ast.Assign):
                    v=self._eval(item.value,classenv)
                    for t in item.targets:
                        if isinstance(t, ast.Name): ns[t.id]=v
                        else: self._assign(t,v,classenv)
                elif isinstance(item,ast.AnnAssign):
                    self._assign(item.target,self._eval(item.value,classenv) if item.value else None,classenv)
                elif isinstance(item,ast.Expr): self._eval(item.value,classenv)
            cls=type(st.name,tuple(bases),ns)
            for dec in reversed(st.decorator_list): cls=self._eval(dec,env)(cls)
            env.set(st.name,cls); return
        if isinstance(st,ast.Import):
            for a in st.names:
                mod=importlib.import_module(a.name)
                env.set(a.asname or a.name.split('.')[0],mod)
            return
        if isinstance(st,ast.ImportFrom):
            mod=__import__(st.module,env.data,env.data, [a.name for a in st.names],0 if st.level==0 else st.level)
            for a in st.names:
                if a.name=='*': continue
                try:
                    value=getattr(mod,a.name)
                except AttributeError:
                                                                             
                                                                               
                    module_name=(st.module + '.' + a.name) if st.module else a.name
                    value=importlib.import_module(module_name)
                env.set(a.asname or a.name,value)
            return
        if isinstance(st,ast.Try):
            try:self._exec_block(st.body,env)
            except Exception as exc:
                handled=False
                for h in st.handlers:
                    if h.type is None or isinstance(exc,self._eval(h.type,env)):
                        if h.name: env.set(h.name,exc)
                        self._exec_block(h.body,env); handled=True; break
                if not handled: raise
            else:self._exec_block(st.orelse,env)
            finally:self._exec_block(st.finalbody,env)
            return
        if isinstance(st,ast.Raise):
            if st.exc is None: raise
            raise self._eval(st.exc,env)
        if isinstance(st,ast.With):
            exits=[]; pending=None
            try:
                for i in st.items:
                    m=self._eval(i.context_expr,env); exit_fn=m.__exit__
                    val=m.__enter__(); exits.append(exit_fn)
                    if i.optional_vars:self._assign(i.optional_vars,val,env)
                self._exec_block(st.body,env)
            except BaseException as exc:
                pending=exc
                suppressed=False
                for exit_fn in reversed(exits):
                    if exit_fn(type(exc), exc, exc.__traceback__): suppressed=True; pending=None; break
                if pending is not None: raise
                if suppressed: return
            else:
                for exit_fn in reversed(exits): exit_fn(None,None,None)
            return
        if isinstance(st,ast.Pass): return
        raise NotImplementedError(f"unsupported statement: {type(st).__name__}")
    async def _exec_async(self,st,env):
        if isinstance(st,ast.Return): raise _Return(await self._eval_async(st.value,env) if st.value else None)
        if isinstance(st,ast.Expr): await self._eval_async(st.value,env); return
        if isinstance(st,ast.Assign):
            v=await self._eval_async(st.value,env); [self._assign(t,v,env) for t in st.targets]; return
        if isinstance(st,ast.Await): await self._eval_async(st,env); return
        if isinstance(st,(ast.FunctionDef,ast.AsyncFunctionDef)): return self._exec(st,env)
        return self._exec(st,env)
    def _exec_gen(self,st,env):
        if isinstance(st,ast.Expr) and isinstance(st.value,ast.Yield):
            yield self._eval(st.value.value,env) if st.value.value else None; return
        if isinstance(st,ast.Yield):
            yield self._eval(st.value,env) if st.value else None; return
        if isinstance(st,ast.Return): return
        if isinstance(st,ast.For):
            for v in self._eval(st.iter,env):
                self._assign(st.target,v,env); yield from self._exec_gen_block(st.body,env)
            return
        self._exec(st,env)
    def _binop(self,op,a,b):
        if isinstance(op,ast.Add): return a+b
        if isinstance(op,ast.Sub): return a-b
        if isinstance(op,ast.Mult): return a*b
        if isinstance(op,ast.Div): return a/b
        if isinstance(op,ast.FloorDiv): return a//b
        if isinstance(op,ast.Mod): return a%b
        if isinstance(op,ast.Pow): return a**b
        if isinstance(op,ast.MatMult): return a@b
        if isinstance(op,ast.BitOr): return a|b
        if isinstance(op,ast.BitAnd): return a&b
        if isinstance(op,ast.BitXor): return a^b
        if isinstance(op,ast.LShift): return a<<b
        if isinstance(op,ast.RShift): return a>>b
        raise NotImplementedError(type(op).__name__)
    def _unop(self,op,a):
        if isinstance(op,ast.USub): return -a
        if isinstance(op,ast.UAdd): return +a
        if isinstance(op,ast.Not): return not a
        if isinstance(op,ast.Invert): return ~a
        return a
    def _compare(self,op,a,b):
        if isinstance(op,ast.Eq): return a==b
        if isinstance(op,ast.NotEq): return a!=b
        if isinstance(op,ast.Lt): return a<b
        if isinstance(op,ast.LtE): return a<=b
        if isinstance(op,ast.Gt): return a>b
        if isinstance(op,ast.GtE): return a>=b
        if isinstance(op,ast.In): return a in b
        if isinstance(op,ast.NotIn): return a not in b
        if isinstance(op,ast.Is): return a is b
        if isinstance(op,ast.IsNot): return a is not b
        raise NotImplementedError(type(op).__name__)
    def run(self):
        env=self._module_env
        self._exec_block(self.tree.body,env)
        return self.globals

def pack_function_capsule(selected_nodes):
    """Serialize only selected function bodies, not the whole source tree."""
    records=[]
    for fid,node in selected_nodes:
        records.append((int(fid), isinstance(node,ast.AsyncFunctionDef),
                        any(isinstance(x,ast.Yield) for x in ast.walk(node)),
                        encode_node(node.args),
                        [encode_node(x) for x in node.body]))
    return zlib.compress(marshal.dumps(tuple(records),4),9)

def unpack_function_capsule(blob):
    records=_safe_capsule_load(blob)
    out={}
    for rec in records:
        if len(rec) == 4:                  
            fid,is_async,is_generator,body = rec
            args = None
        else:
            fid,is_async,is_generator,args,body = rec
            args = decode_node(args)
        out[int(fid)] = (bool(is_async), bool(is_generator), args, [decode_node(x) for x in body])
    return out

def encode_node(node):
    def enc(v):
        if isinstance(v,ast.AST):
            return (v.__class__.__name__, tuple((name,enc(getattr(v,name))) for name in v._fields))
        if isinstance(v,list): return ("@",tuple(enc(x) for x in v))
        if isinstance(v,tuple): return ("#",tuple(enc(x) for x in v))
        if isinstance(v,bytes): return ("B",v)
        return v
    return enc(node)

def decode_node(data):
    return decode_ast(data)


def _vm_safe_function(node):
    if isinstance(node, ast.AsyncFunctionDef):
        return False
    if any(isinstance(x, (ast.Yield, ast.YieldFrom, ast.Await, ast.Lambda, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
           for x in ast.walk(node) if x is not node):
        return False
    if any(isinstance(x, ast.Call) and isinstance(x.func, ast.Name) and x.func.id == "super" and not x.args and not x.keywords
           for x in ast.walk(node)):
        return False
    if any(isinstance(x, (ast.With, ast.AsyncWith, ast.Match)) for x in ast.walk(node)):
        return False
    if any(isinstance(x, ast.ExceptHandler) and x.name for x in ast.walk(node)):
        return False
    if getattr(node, "returns", None) is not None or any(a.annotation is not None for a in list(node.args.posonlyargs)+list(node.args.args)+list(node.args.kwonlyargs)):
        return False
    return True

def virtualize_functions(tree, fraction: float = 0.35):
    """Replace the most complex eligible function bodies with VM dispatch stubs.

    The original tree is retained in the VM capsule. The executable CodeType
    contains only the public callable shell and a generic dispatcher call.
    """
    funcs=[n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
    index={id(n):i for i,n in enumerate(funcs)}
    parent={}
    for parent_node in ast.walk(tree):
        for child in ast.iter_child_nodes(parent_node):
            parent[id(child)] = parent_node
    eligible=[]
    for n in funcs:
        p=parent.get(id(n))
                                                                                
                                                                               
                                                                           
                                                                                
        if isinstance(p,(ast.Module,ast.ClassDef)) and _vm_safe_function(n):
            eligible.append(n)
    count=max(1, int(len(eligible)*fraction + 0.999999)) if eligible else 0
    chosen=sorted(eligible,key=lambda n: len(list(ast.walk(n))), reverse=True)[:count]
    chosen_ids={id(n):index[id(n)] for n in chosen}
    class Rewriter(ast.NodeTransformer):
        def _replace(self,node):
            fid=chosen_ids.get(id(node))
            if fid is None: return self.generic_visit(node)
            if any(isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) for x in ast.walk(node) if x is not node):
                return self.generic_visit(node)
                                                                              
                                                                           
                                                                               
                                                                              
            node.args = ast.arguments(
                posonlyargs=[], args=[], vararg=ast.arg(arg="_samarth_args"),
                kwonlyargs=[], kw_defaults=[], kwarg=ast.arg(arg="_samarth_kwargs"), defaults=[]
            )
            call=ast.Call(func=ast.Name(id="_samarth_vm_dispatch",ctx=ast.Load()),
                          args=[ast.Constant(fid),ast.Name(id="_samarth_args",ctx=ast.Load()),ast.Name(id="_samarth_kwargs",ctx=ast.Load())],keywords=[])
            node.body=[ast.Return(value=call)]
            return node
        visit_FunctionDef=_replace
        visit_AsyncFunctionDef=_replace
    out=Rewriter().visit(tree)
    ast.fix_missing_locations(out)
    return out, len(chosen), len(funcs), [index[id(n)] for n in chosen]

def encode_ast(tree):
    def enc(v):
        if isinstance(v,ast.AST):
            return (v.__class__.__name__, tuple((name,enc(getattr(v,name))) for name in v._fields))
        if isinstance(v,list): return ("@",tuple(enc(x) for x in v))
        if isinstance(v,tuple): return ("#",tuple(enc(x) for x in v))
        if isinstance(v,bytes): return ("B",v)
        return v
    return enc(tree)

def decode_ast(data):
    def dec(v):
        if isinstance(v,tuple) and len(v)==2 and isinstance(v[0],str):
            tag=v[0]
            if tag=="@": return [dec(x) for x in v[1]]
            if tag=="#": return tuple(dec(x) for x in v[1])
            if tag=="B": return v[1]
            if tag in getattr(ast,tag).__mro__ if False else False: pass
            cls=getattr(ast,tag,None)
            if cls is not None and isinstance(v[1],tuple):
                kwargs={name:dec(val) for name,val in v[1]}
                try:
                    return cls(**kwargs)
                except TypeError:
                    obj=cls.__new__(cls)
                    for name,val in kwargs.items(): setattr(obj,name,val)
                    return obj
        return v
    return dec(data)

def install_function_vm(tree, globals_dict):
    rt=VMRuntime(tree, globals_dict)
    def dispatch(fid, args, kwargs):
        return rt._dispatch(fid, args, kwargs)
    async def dispatch_async(fid, args, kwargs):
        return await rt._dispatch_async(fid, args, kwargs)
    def dispatch_gen(fid, args, kwargs):
        yield from rt._dispatch_gen(fid, args, kwargs)
    return dispatch, dispatch_async, dispatch_gen

class FunctionCapsuleRuntime(VMRuntime):
    def __init__(self, capsule, globals_dict):
        self.capsule=capsule
        self.globals=globals_dict
    @property
    def _module_env(self): return _Env(self.globals)
    def _env(self, fid, args, kwargs):
        rec=self.capsule[fid]
        is_async,is_generator,arg_node,body=rec
        if arg_node is None:
            raise ValueError("Legacy VM capsule cannot be used by the v2 generic signature dispatcher")
        fn_cls=ast.AsyncFunctionDef if is_async else ast.FunctionDef
        node=fn_cls(name="_capsule", args=arg_node, body=[], decorator_list=[])
        bound=self._bind_args(node,args,dict(kwargs))
        return _Env(bound, self._module_env), body
    def dispatch(self,fid,args,kwargs):
        env,body=self._env(fid,args,kwargs)
        try:
            VMRuntime._exec_block(self,body,env)
        except _Return as r: return r.value
        return None
    async def dispatch_async(self,fid,args,kwargs):
        env,body=self._env(fid,args,kwargs)
        try:
            await VMRuntime._exec_block_async(self,body,env)
        except _Return as r: return r.value
        return None
    def dispatch_gen(self,fid,args,kwargs):
        env,body=self._env(fid,args,kwargs)
        yield from VMRuntime._exec_gen_block(self,body,env)

def install_function_capsule(capsule, globals_dict):
    rt=FunctionCapsuleRuntime(capsule, globals_dict)
    return rt.dispatch, rt.dispatch_async, rt.dispatch_gen

def _vm_dispatch(self, fid, args, kwargs):
    node=self.functions_list[fid]
    env=_Env(self._bind_args(node,args,dict(kwargs),eval_env=self._module_env), self._module_env)
    try: self._exec_block(node.body,env)
    except _Return as r: return r.value
    return None

async def _vm_dispatch_async(self, fid, args, kwargs):
    node=self.functions_list[fid]
    env=_Env(self._bind_args(node,args,dict(kwargs),eval_env=self._module_env), self._module_env)
    try: await self._exec_block_async(node.body,env)
    except _Return as r: return r.value
    return None

def _vm_dispatch_gen(self, fid, args, kwargs):
    node=self.functions_list[fid]
    env=_Env(self._bind_args(node,args,dict(kwargs),eval_env=self._module_env), self._module_env)
    yield from self._exec_gen_block(node.body,env)

VMRuntime._dispatch=_vm_dispatch
VMRuntime._dispatch_async=_vm_dispatch_async
VMRuntime._dispatch_gen=_vm_dispatch_gen

def pack_vm(tree):
    raw=marshal.dumps(encode_ast(tree),4)
    return zlib.compress(raw,9)

def unpack_vm(blob):
    return decode_ast(_safe_capsule_load(blob))

                                                                                 
                                                                         
                                                                               
                                                                             
                                                             

_NODE_TYPES_67 = [
    n for n in (
        "Module","FunctionDef","AsyncFunctionDef","ClassDef","Return","Delete","Assign","AugAssign",
        "AnnAssign","For","AsyncFor","While","If","With","AsyncWith","Raise","Try","Assert","Import",
        "ImportFrom","Global","Nonlocal","Expr","Pass","Break","Continue","BoolOp","NamedExpr","BinOp",
        "UnaryOp","Lambda","IfExp","Dict","Set","ListComp","SetComp","DictComp","GeneratorExp","Await",
        "Yield","YieldFrom","Compare","Call","FormattedValue","JoinedStr","Constant","Attribute","Subscript",
        "Starred","Name","List","Tuple","Slice","comprehension","ExceptHandler","arguments","arg","keyword",
        "alias","withitem","match_case","Match","MatchValue","MatchSingleton","MatchSequence","MatchMapping",
        "MatchClass","MatchStar","MatchAs","MatchOr","Load","Store","Del","And","Or","Add","Sub",
        "Mult","Div","FloorDiv","Mod","Pow","LShift","RShift","BitOr","BitXor","BitAnd","MatMult",
        "UAdd","USub","Invert","Not","Eq","NotEq","Lt","LtE","Gt","GtE","Is","IsNot","In","NotIn",
    )
]
_NODE_TO_ID_67 = {n:i for i,n in enumerate(_NODE_TYPES_67)}
_ID_TO_NODE_67 = {i:getattr(ast,n) for n,i in _NODE_TO_ID_67.items() if hasattr(ast,n)}


def _sym_encode_67(text: str, salt: int) -> tuple[int, ...]:
    raw = text.encode("utf-8")
                                                                          
                                                                             
    return tuple((b + ((salt + i * 17) & 255)) & 255 for i,b in enumerate(raw))


def _sym_decode_67(data, salt: int) -> str:
    raw = bytes((b - ((salt + i * 17) & 255)) & 255 for i,b in enumerate(data))
    return raw.decode("utf-8")


def _collect_symbols_67(node, out):
    if isinstance(node, ast.AST):
        if isinstance(node, ast.Name): out.add(node.id)
        elif isinstance(node, ast.arg): out.add(node.arg)
        elif isinstance(node, ast.alias):
            out.add(node.name)
            if node.asname: out.add(node.asname)
        elif isinstance(node, ast.keyword) and node.arg: out.add(node.arg)
        elif isinstance(node, ast.Attribute): out.add(node.attr)
        for _,v in ast.iter_fields(node): _collect_symbols_67(v,out)
    elif isinstance(node,(list,tuple)):
        for x in node: _collect_symbols_67(x,out)


def _enc67(v, symbols, salt):
    if isinstance(v, ast.AST):
        tid = _NODE_TO_ID_67.get(type(v).__name__)
        if tid is None:
            raise ValueError(f"Unsupported AST node for v0.6.7 capsule: {type(v).__name__}")
        vals=[]
        for name in v._fields:
            x=getattr(v,name)
            if isinstance(v, (ast.Name, ast.arg, ast.alias, ast.keyword, ast.Attribute)) and name in {"id","arg","name","asname","attr"} and isinstance(x,str):
                vals.append((1, symbols.index(x)))
            elif isinstance(v, ast.Constant) and name == "value":
                vals.append((2,x))
            else:
                vals.append((0,_enc67(x,symbols,salt)))
        return (10, tid, tuple(vals))
    if isinstance(v,list): return (3, tuple(_enc67(x,symbols,salt) for x in v))
    if isinstance(v,tuple): return (4, tuple(_enc67(x,symbols,salt) for x in v))
    if isinstance(v,bytes): return (5,v)
    return (6,v)


def _dec67(v, symbols, salt):
    if not isinstance(v,tuple) or not v: return v
    tag=v[0]
    if tag==10:
        tid, fields=v[1], v[2]
        cls=_ID_TO_NODE_67.get(int(tid))
        if cls is None: raise ValueError(f"Unknown SAMARTH AST node id {tid}")
        kwargs={}
        for name, item in zip(getattr(cls,"_fields",()), fields):
            if item[0]==1: kwargs[name]=symbols[int(item[1])]
            elif item[0]==2: kwargs[name]=item[1]
            else: kwargs[name]=_dec67(item[1],symbols,salt)
        try: return cls(**kwargs)
        except TypeError:
            obj=cls.__new__(cls)
            for name,val in kwargs.items(): setattr(obj,name,val)
            return obj
    if tag==3: return [_dec67(x,symbols,salt) for x in v[1]]
    if tag==4: return tuple(_dec67(x,symbols,salt) for x in v[1])
    if tag==5: return bytes(v[1])
    if tag==6: return v[1]
    if tag in {1,2,0} and isinstance(v,tuple) and len(v)>=2:
        if tag==1: return symbols[int(v[1])]
        if tag==2: return v[1]


def _safe_capsule_load(blob: bytes):
    if not isinstance(blob, (bytes, bytearray)) or len(blob) > MAX_CAPSULE_SIZE:
        raise ValueError("SAMARTH VM capsule exceeds size limit")
    d=zlib.decompressobj()
    raw=d.decompress(bytes(blob), MAX_CAPSULE_RAW+1)
    if len(raw)>MAX_CAPSULE_RAW or not d.eof or d.unused_data:
        raise ValueError("SAMARTH VM capsule is malformed or exceeds resource limits")
    return marshal.loads(raw)

def pack_function_capsule_v2(selected_nodes, *, profile="advanced"):
    salt = __import__('secrets').randbelow(256)
    records=[]
    for fid,node in selected_nodes:
        symbols=set(); _collect_symbols_67(node,symbols)
        symbols_sorted=sorted(symbols)
        encoded_args=_enc67(node.args,symbols_sorted,salt)
        encoded_body=[_enc67(x,symbols_sorted,salt) for x in node.body]
        records.append((int(fid), 1 if isinstance(node,ast.AsyncFunctionDef) else 0,
                        1 if any(isinstance(x,ast.Yield) for x in ast.walk(node)) else 0,
                        tuple(_sym_encode_67(s,salt) for s in symbols_sorted), encoded_args, tuple(encoded_body)))
    envelope=(b"SAMVM67",2,int(salt),profile,tuple(records))
    return zlib.compress(marshal.dumps(envelope,4),9)


def unpack_function_capsule_v2(blob):
    env=_safe_capsule_load(blob)
    if not (isinstance(env,tuple) and len(env)==5 and env[0]==b"SAMVM67" and env[1]==2):
        raise ValueError("Invalid SAMARTH v0.6.7 function capsule")
    _,_,salt,profile,records=env
    out={}
    for rec in records:
        fid,is_async,is_generator,encoded_symbols,encoded_args,encoded_body=rec
        symbols=[_sym_decode_67(x,salt) for x in encoded_symbols]
        args=_dec67(encoded_args,symbols,salt)
        body=[_dec67(x,symbols,salt) for x in encoded_body]
        out[int(fid)]=(bool(is_async),bool(is_generator),args,body)
    return out


def _vm_safe_function_v2(node):
                                                                              
                                                                        
                                                           
    if isinstance(node, ast.AsyncFunctionDef): return False
    if any(isinstance(x,(ast.Yield,ast.YieldFrom,ast.Await,ast.Lambda,ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))
           for x in ast.walk(node) if x is not node): return False
    if any(isinstance(x,(ast.With,ast.AsyncWith,ast.Match)) for x in ast.walk(node)): return False
    if any(isinstance(x,ast.ExceptHandler) and x.name for x in ast.walk(node)): return False
    if getattr(node,"returns",None) is not None: return False
    if node.args.defaults or any(x is not None for x in node.args.kw_defaults): return False
    if any(a.annotation is not None for a in list(node.args.posonlyargs)+list(node.args.args)+list(node.args.kwonlyargs)): return False
    if any(isinstance(x,(ast.Global,ast.Nonlocal)) for x in ast.walk(node)): return False
                                                                         
                                                                    
    for x in ast.walk(node):
        if isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id=="super" and not x.args and not x.keywords:
            first=(list(node.args.posonlyargs)+list(node.args.args)+list(node.args.kwonlyargs))
            if not first or first[0].arg not in {"self","cls"}: return False
    return True


def virtualize_functions_v2(tree, profile="advanced"):
    funcs=[n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
    index={id(n):i for i,n in enumerate(funcs)}
    parent={}
    for parent_node in ast.walk(tree):
        for child in ast.iter_child_nodes(parent_node): parent[id(child)]=parent_node
    eligible=[]
    for n in funcs:
        p=parent.get(id(n))
        if isinstance(p,(ast.Module,ast.ClassDef)) and _vm_safe_function_v2(n): eligible.append(n)
                                                                            
                                                                             
    fraction=0.60 if profile=="advanced" else 1.0
    count=max(1,int(len(eligible)*fraction+0.999999)) if eligible else 0
    chosen=sorted(eligible,key=lambda n:(-len(list(ast.walk(n))), n.name))[:count]
    chosen_ids={id(n):index[id(n)] for n in chosen}
    class Rewriter(ast.NodeTransformer):
        def _replace(self,node):
            fid=chosen_ids.get(id(node))
            if fid is None: return self.generic_visit(node)
            node.args=ast.arguments(posonlyargs=[],args=[],vararg=ast.arg(arg="_samarth_args"),kwonlyargs=[],kw_defaults=[],kwarg=ast.arg(arg="_samarth_kwargs"),defaults=[])
            call=ast.Call(func=ast.Name(id="_samarth_vm_dispatch",ctx=ast.Load()),args=[ast.Constant(fid),ast.Name(id="_samarth_args",ctx=ast.Load()),ast.Name(id="_samarth_kwargs",ctx=ast.Load())],keywords=[])
            node.body=[ast.Return(value=call)]
            return node
        visit_FunctionDef=_replace
        visit_AsyncFunctionDef=_replace
    out=Rewriter().visit(tree); ast.fix_missing_locations(out)
    return out,len(chosen),len(funcs),[index[id(n)] for n in chosen]

MODULE_VM_MARKER_67 = "__SAMARTH_MODULE_VM_V2__"

def pack_module_capsule_v2(tree):
    salt=__import__('secrets').randbelow(256)
    symbols=set(); _collect_symbols_67(tree,symbols); symbols_sorted=sorted(symbols)
    encoded=_enc67(tree,symbols_sorted,salt)
    env=(b"SAMMOD67",2,salt,tuple(_sym_encode_67(s,salt) for s in symbols_sorted),encoded)
    return zlib.compress(marshal.dumps(env,4),9)

def unpack_module_capsule_v2(blob):
    env=_safe_capsule_load(blob)
    if not (isinstance(env,tuple) and len(env)==5 and env[0]==b"SAMMOD67" and env[1]==2):
        raise ValueError("Invalid SAMARTH v0.6.7 module capsule")
    _,_,salt,encoded_symbols,encoded=env
    symbols=[_sym_decode_67(x,salt) for x in encoded_symbols]
    return _dec67(encoded,symbols,salt)
