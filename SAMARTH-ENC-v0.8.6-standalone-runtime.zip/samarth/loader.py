from __future__ import annotations

import importlib.abc
import importlib.util
import json
import sys
from pathlib import Path

from .runtime import execute_payload, verify_manifest


class _SMELoader(importlib.abc.Loader):
    def __init__(self, path: Path): self.path = path
    def create_module(self, spec): return None
    def exec_module(self, module):
        meta = execute_payload(self.path.read_bytes(), module.__dict__, str(self.path))
        module.__dict__.setdefault("__samarth_metadata__", meta)


class _SmeFinder(importlib.abc.MetaPathFinder):
    def __init__(self, root: Path): self.root = root
    def find_spec(self, fullname, path=None, target=None):
        rel = Path(*fullname.split("."))
        file = self.root / (str(rel) + ".sme")
        init = self.root / rel / "__init__.sme"
        if file.is_file():
            return importlib.util.spec_from_file_location(fullname, file, loader=_SMELoader(file))
        if init.is_file():
            return importlib.util.spec_from_file_location(fullname, init, loader=_SMELoader(init), submodule_search_locations=[str(init.parent)])
        return None


def select_payload(bundle: Path, stem: str | None = None) -> Path:
    version = f"{sys.version_info.major}{sys.version_info.minor}"
    if stem:
        candidate = bundle / f"{stem}_py{version}.sme"
        if candidate.exists(): return candidate
    candidates = sorted(bundle.glob(f"*_py{version}.sme"))
    if len(candidates) == 1: return candidates[0]
    if not candidates:
        raise RuntimeError(f"No SAMARTH payload for Python {sys.version_info.major}.{sys.version_info.minor} was found in {bundle}.")
    raise RuntimeError(f"Multiple Python {version} payloads found; use --name to select one.")


def run_bundle(bundle: Path, stem: str | None = None) -> dict:
    manifest_path = bundle / "manifest.json"
    manifest = {}
    if manifest_path.is_file():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        verify_manifest(bundle, manifest)
    if manifest.get("format") == "samarth-bundle-v2":
        if stem:
            candidate = bundle / f"{stem}.sme"
            if not candidate.is_file():
                raise RuntimeError(f"No payload named {stem}.sme was found in {bundle}.")
            payload_path = candidate
        else:
            top = sorted(bundle.glob("*.sme"))
            if len(top) != 1:
                raise RuntimeError("Project bundle contains multiple entry payloads; use --name with the source stem.")
            payload_path = top[0]
    else:
        payload_path = select_payload(bundle, stem)
    sys.meta_path.insert(0, _SmeFinder(bundle))
    ns = {"__name__": "__main__", "__file__": str(payload_path), "__package__": None}
    meta = execute_payload(payload_path.read_bytes(), ns, str(payload_path))
    return {"payload": str(payload_path), "metadata": meta}


def run_single(payload: Path) -> dict:
    ns = {"__name__": "__main__", "__file__": str(payload), "__package__": None}
    meta = execute_payload(payload.read_bytes(), ns, str(payload))
    return {"payload": str(payload), "metadata": meta}
