SAMARTH ENC v0.8.6 - Standalone Runtime Bundle

Contents:
- Runtime modules required to execute SAMARTH payloads.
- run_sme.py: minimal single-file launcher.
- No encoder, project builder, CLI protection commands, or source transformation modules are included.

Usage (Python must already be installed):
    python run_sme.py path/to/main.sme

This bundle removes Python comment tokens from included .py files.
It does NOT remove decoding/decompression/VM execution logic: those components are required to run the .sme format.
The runtime is inspectable and is not a secret or cryptographic boundary.

For Zstandard-compressed payloads, install the `zstandard` package in the target environment.
For BZ2-compressed payloads, the Python standard library is sufficient.
