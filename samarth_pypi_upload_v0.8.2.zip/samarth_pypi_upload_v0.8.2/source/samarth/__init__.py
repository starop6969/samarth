__version__ = "0.8.2"

"""SAMARTH ENC: keyless offline Python source protection toolkit."""
