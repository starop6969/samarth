"""Portable SAMARTH containers for Pydroid/Termux and CPython 3.11-3.14.

v2 adds a bounded, custom reversible byte-scrambling layer, shuffled fragments,
compression and Base85 transport.  It is deliberately described as
obfuscation/encoding, NOT cryptographic encryption: all decoding material is
inside the artifact and the runtime must reconstruct source to execute it.
The v1 reader remains for backward compatibility.
"""
from __future__ import annotations

import base64
import bz2
import hashlib
import json
import secrets
import struct
from pathlib import Path

MAGIC = b"SAMHER02"
LEGACY_MAGIC = b"SAMHER01"
VERSION = 2
LEGACY_VERSION = 1
HEADER = struct.Struct(">8sBI")
MAX_PAYLOAD_SIZE = 64 * 1024 * 1024
MAX_SOURCE_SIZE = 48 * 1024 * 1024
MAX_METADATA_SIZE = 256 * 1024
MAX_FRAGMENTS = 16
V2_FRAGMENT_COUNT = 7
V2_ROUNDS = 4


def _canonical_meta(meta: dict) -> bytes:
    return json.dumps(meta, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _split_fragments(data: bytes, count: int) -> list[bytes]:
    
    
    weights = (7, 13, 19, 23, 29, 37)[:count - 1]
    total = sum(weights) + 41
    cuts = []
    running = 0
    for weight in weights:
        running += weight
        cuts.append((len(data) * running) // total)
    points = [0, *cuts, len(data)]
    return [data[points[i]:points[i + 1]] for i in range(count)]


def _round_parameters(salt: bytes, round_no: int) -> tuple[int, int]:
    seed = hashlib.sha256(b"SAMARTH-PORTABLE-TABLE-v2" + salt + bytes((round_no,))).digest()
    
    return (seed[0] | 1), seed[1]


def _scramble(data: bytes, salt: bytes, rounds: int = V2_ROUNDS) -> bytes:
    out = data
    for round_no in range(rounds):
        stream = hashlib.shake_256(
            b"SAMARTH-PORTABLE-STREAM-v2" + salt + bytes((round_no,))
        ).digest(len(out))
        mixed = bytes(a ^ b for a, b in zip(out, stream))
        multiplier, offset = _round_parameters(salt, round_no)
        table = bytes(((multiplier * value + offset) & 0xFF) for value in range(256))
        out = mixed.translate(table)
    return out


def _unscramble(data: bytes, salt: bytes, rounds: int = V2_ROUNDS) -> bytes:
    out = data
    for round_no in reversed(range(rounds)):
        multiplier, offset = _round_parameters(salt, round_no)
        inverse = pow(multiplier, -1, 256)
        inverse_table = bytes(((inverse * (value - offset)) & 0xFF) for value in range(256))
        unmixed = out.translate(inverse_table)
        stream = hashlib.shake_256(
            b"SAMARTH-PORTABLE-STREAM-v2" + salt + bytes((round_no,))
        ).digest(len(out))
        out = bytes(a ^ b for a, b in zip(unmixed, stream))
    return out


def _pack_v1(source: str, metadata: dict | None = None) -> bytes:
    raw = source.encode("utf-8")
    compressed = bz2.compress(raw, compresslevel=9)
    encoded = base64.b85encode(compressed)
    fragments = _split_fragments(encoded, 5)
    meta = dict(metadata or {})
    meta.update({
        "format": "samarth-hermit-v1",
        "codec": "bzip2+base85-fragments",
        "source_encoding": "utf-8",
        "fragment_count": len(fragments),
        "portable_python_source": True,
    })
    meta_raw = _canonical_meta(meta)
    if len(meta_raw) > MAX_METADATA_SIZE:
        raise ValueError("SAMARTH metadata exceeds size limit")
    body = bytearray(HEADER.pack(LEGACY_MAGIC, LEGACY_VERSION, len(meta_raw)))
    body.extend(meta_raw)
    body.append(len(fragments))
    for fragment in fragments:
        body.extend(struct.pack(">I", len(fragment)))
        body.extend(fragment)
    if len(body) + 32 > MAX_PAYLOAD_SIZE:
        raise ValueError("SAMARTH payload exceeds size limit")
    return bytes(body) + hashlib.sha256(body).digest()


def pack_source(source: str, metadata: dict | None = None) -> bytes:
    """Build a v2 portable payload using only the Python standard library."""
    if not isinstance(source, str):
        raise TypeError("source must be text")
    raw = source.encode("utf-8")
    if len(raw) > MAX_SOURCE_SIZE:
        raise ValueError("SAMARTH source exceeds size limit")

    compressed = bz2.compress(raw, compresslevel=9)
    salt = secrets.token_bytes(32)
    scrambled = _scramble(compressed, salt, V2_ROUNDS)
    encoded = base64.b85encode(scrambled)
    fragments = _split_fragments(encoded, V2_FRAGMENT_COUNT)
    order = list(range(len(fragments)))
    secrets.SystemRandom().shuffle(order)

    meta = dict(metadata or {})
    meta.update({
        "format": "samarth-hermit-v2",
        "codec": "bz2+custom-byte-mixer-v2+base85+shuffled-fragments",
        "source_encoding": "utf-8",
        "fragment_count": len(fragments),
        "fragment_order": order,
        "mix_rounds": V2_ROUNDS,
        "mix_salt": salt.hex(),
        "portable_python_source": True,
        "protection_note": "reversible_obfuscation_not_encryption",
    })
    meta_raw = _canonical_meta(meta)
    if len(meta_raw) > MAX_METADATA_SIZE:
        raise ValueError("SAMARTH metadata exceeds size limit")

    body = bytearray(HEADER.pack(MAGIC, VERSION, len(meta_raw)))
    body.extend(meta_raw)
    body.append(len(fragments))
    for index in order:
        fragment = fragments[index]
        body.append(index)
        body.extend(struct.pack(">I", len(fragment)))
        body.extend(fragment)
    if len(body) + 32 > MAX_PAYLOAD_SIZE:
        raise ValueError("SAMARTH payload exceeds size limit")
    return bytes(body) + hashlib.sha256(body).digest()


def _verify_digest(blob: bytes) -> bytes:
    if len(blob) > MAX_PAYLOAD_SIZE:
        raise ValueError("SAMARTH payload exceeds size limit")
    if len(blob) < HEADER.size + 1 + 32:
        raise ValueError("Truncated SAMARTH portable payload")
    body, digest = blob[:-32], blob[-32:]
    if not secrets.compare_digest(hashlib.sha256(body).digest(), digest):
        raise ValueError("SAMARTH integrity check failed")
    return body


def _read_meta(body: bytes, expected_magic: bytes, expected_version: int):
    magic, version, meta_len = HEADER.unpack_from(body, 0)
    if magic != expected_magic or version != expected_version:
        raise ValueError("Unsupported SAMARTH portable payload")
    pos = HEADER.size
    if meta_len > MAX_METADATA_SIZE or pos + meta_len + 1 > len(body):
        raise ValueError("Invalid SAMARTH metadata length")
    try:
        meta = json.loads(body[pos:pos + meta_len].decode("utf-8"))
    except Exception as exc:
        raise ValueError("Invalid SAMARTH metadata") from exc
    if not isinstance(meta, dict):
        raise ValueError("Invalid SAMARTH metadata")
    return meta, pos + meta_len


def _decompress(compressed: bytes) -> str:
    decoder = bz2.BZ2Decompressor()
    raw = decoder.decompress(compressed, max_length=MAX_SOURCE_SIZE + 1)
    if len(raw) > MAX_SOURCE_SIZE or not decoder.eof or decoder.unused_data:
        raise ValueError("SAMARTH source exceeds resource limits or is malformed")
    return raw.decode("utf-8")


def unpack_source(payload: bytes) -> tuple[str, dict]:
    if not isinstance(payload, (bytes, bytearray)):
        raise TypeError("payload must be bytes")
    blob = bytes(payload)
    body = _verify_digest(blob)
    if body.startswith(LEGACY_MAGIC):
        meta, pos = _read_meta(body, LEGACY_MAGIC, LEGACY_VERSION)
        if meta.get("format") != "samarth-hermit-v1":
            raise ValueError("Unsupported SAMARTH portable metadata")
        count = body[pos]
        pos += 1
        if count != 5 or count > MAX_FRAGMENTS:
            raise ValueError("Invalid SAMARTH fragment count")
        parts = []
        for _ in range(count):
            if pos + 4 > len(body):
                raise ValueError("Truncated SAMARTH fragment header")
            size = struct.unpack_from(">I", body, pos)[0]
            pos += 4
            if size > len(body) - pos:
                raise ValueError("Truncated SAMARTH fragment")
            parts.append(body[pos:pos + size])
            pos += size
        if pos != len(body):
            raise ValueError("Unexpected trailing data in SAMARTH payload")
        try:
            return _decompress(base64.b85decode(b"".join(parts))), meta
        except Exception as exc:
            if isinstance(exc, ValueError) and str(exc).startswith("SAMARTH source"):
                raise
            raise ValueError("SAMARTH portable payload decoding failed") from exc

    meta, pos = _read_meta(body, MAGIC, VERSION)
    if meta.get("format") != "samarth-hermit-v2":
        raise ValueError("Unsupported SAMARTH portable metadata")
    count = body[pos]
    pos += 1
    if count != V2_FRAGMENT_COUNT or count > MAX_FRAGMENTS:
        raise ValueError("Invalid SAMARTH fragment count")
    order = meta.get("fragment_order")
    if not isinstance(order, list) or sorted(order) != list(range(count)):
        raise ValueError("Invalid SAMARTH fragment order")
    parts: dict[int, bytes] = {}
    for _ in range(count):
        if pos + 5 > len(body):
            raise ValueError("Truncated SAMARTH fragment header")
        index = body[pos]
        size = struct.unpack_from(">I", body, pos + 1)[0]
        pos += 5
        if index >= count or index in parts or size > len(body) - pos:
            raise ValueError("Invalid SAMARTH fragment")
        parts[index] = body[pos:pos + size]
        pos += size
    if pos != len(body) or set(parts) != set(range(count)):
        raise ValueError("Unexpected or missing SAMARTH fragments")
    try:
        rounds = meta.get("mix_rounds")
        salt_hex = meta.get("mix_salt")
        if rounds != V2_ROUNDS or not isinstance(salt_hex, str) or len(salt_hex) != 64:
            raise ValueError("Invalid SAMARTH mixer parameters")
        salt = bytes.fromhex(salt_hex)
        encoded = b"".join(parts[i] for i in range(count))
        scrambled = base64.b85decode(encoded)
        compressed = _unscramble(scrambled, salt, rounds)
        return _decompress(compressed), meta
    except Exception as exc:
        if isinstance(exc, ValueError) and str(exc).startswith("SAMARTH"):
            raise
        raise ValueError("SAMARTH portable payload decoding failed") from exc
