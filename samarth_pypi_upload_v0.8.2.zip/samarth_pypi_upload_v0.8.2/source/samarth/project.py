from __future__ import annotations

import ast
import base64
import hashlib
import json
import sys
from pathlib import Path

from .ast_engine import ASTConfig, TransformReport, transform, split_native_literals, _FlattenSimple
from .vm_engine import pack_function_capsule_v2, virtualize_functions_v2, pack_module_capsule_v2
from .backends import BackendError
from .bytecode_engine import pack_code, pack_function_vm_code, payload_sha256
from .hermit_container import pack_source as pack_hermit_source
from .hardened_codec import pack_hardened_source

PROFILES = {
    "standard": dict(rename_identifiers=False, transform_strings=False, optimize=0, rename_import_bindings=False),
    "advanced": dict(rename_identifiers=True, transform_strings=True, optimize=0, rename_import_bindings=True),
    "maximum": dict(rename_identifiers=True, transform_strings=True, optimize=0, rename_import_bindings=True),
    "native": dict(rename_identifiers=True, transform_strings=True, optimize=0, rename_import_bindings=True),
    "hybrid": dict(rename_identifiers=True, transform_strings=True, optimize=0, rename_import_bindings=True),
    "portable": dict(rename_identifiers=False, transform_strings=False, optimize=0, rename_import_bindings=False),
    "portable-hardened": dict(rename_identifiers=True, transform_strings=True, optimize=0, rename_import_bindings=True),
}


def detect_imports(source: str) -> list[str]:
    tree = ast.parse(source)
    return sorted({n.names[0].name.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.Import)} |
                  {n.module.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) and n.module})


def _logical_name(src: Path) -> str:
    return src.name


def protect_file(src: Path, out: Path, profile="advanced", *, source_root: Path | None = None, hardened_options: dict | None = None):
    profile = profile.lower()
    if profile not in PROFILES:
        raise ValueError(f"Unknown profile: {profile}")
    if profile in {"native", "hybrid"}:
        raise BackendError(f"Profile {profile.upper()} requires a genuine external backend; use the CLI backend selection.")

    cfg = ASTConfig(**PROFILES[profile])
    source = src.read_text(encoding="utf-8")
    logical = src.relative_to(source_root).as_posix() if source_root else _logical_name(src)

    if profile == "portable":
        
        
        
        
        
        report = TransformReport()
        portable_body = source
        execution_model = "portable-source-v2"
        try:
            transformed, report = transform(
                source,
                ASTConfig(rename_identifiers=True, transform_strings=True,
                          optimize=0, rename_import_bindings=True),
            )
            module_tree = _portable_vm_tree(transformed)
            vm_blob = pack_module_capsule_v2(module_tree)
            portable_body = base64.b85encode(vm_blob).decode("ascii")
            execution_model = "portable-module-vm-v2"
        except (ValueError, TypeError, NotImplementedError):
            pass
        metadata = {
            "samarth_version": __import__("samarth").__version__,
            "profile": profile,
            "logical_name": logical,
            "python_min": "3.11",
            "python_max_exclusive": "3.15",
            "integrity": "sha256",
            "execution_model": execution_model,
            "portable_vm_features": (["custom-ast-vm", "local-symbol-renaming", "literal-pool"]
                                      if execution_model == "portable-module-vm-v2" else []),
        }
        payload = pack_hermit_source(portable_body, metadata)
    elif profile == "portable-hardened":
        
        
        
        transformed, report = transform(source, cfg)
        
        
        
        
        hardened_tree = ast.parse(transformed)
        hardened_tree = _FlattenSimple().visit(hardened_tree)
        hardened_tree = split_native_literals(hardened_tree)
        ast.fix_missing_locations(hardened_tree)
        transformed = ast.unparse(hardened_tree)
        metadata = {
            "samarth_version": __import__("samarth").__version__,
            "profile": profile,
            "logical_name": logical,
            "python_min": "3.11",
            "python_max_exclusive": "3.15",
            "integrity": "sha256",
            "execution_model": "portable-hardened-source-v3",
            "portable_hardened_features": [
                "GF256-polynomial-permutation", "SHAKE256-Feistel-diffusion",
                "Lehmer-derived-fragment-order", "Cauchy-GF256-erasure-coding",
                "bit-plane-distribution", "checksum-identified-chaff",
                "binary-fragment-container", "conservative-function-state-dispatch",
                "split-residual-string-and-bytes-literals",
            ],
        }
        payload = pack_hardened_source(transformed, metadata, **(hardened_options or {}))
    elif profile == "standard":
        transformed, report = transform(source, cfg)
        code = compile(transformed, "<samarth>", "exec", optimize=cfg.optimize)
        metadata = {
            "format": "samarth-code-v9-standard",
            "compiled_by": [sys.version_info.major, sys.version_info.minor, sys.version_info.micro],
            "execution_model": "cpython-code",
            "protection": "metadata-hardened-bytecode",
        }
        payload = pack_code(code, metadata)
    else:
        
        
        vm_cfg = ASTConfig(rename_identifiers=False, transform_strings=False,
                           optimize=cfg.optimize, rename_import_bindings=False)
        transformed, report = transform(source, vm_cfg)
        tree = ast.parse(transformed)
        if profile == "maximum":
            tree = _FlattenSimple().visit(tree)
            ast.fix_missing_locations(tree)
        tree = split_native_literals(tree)
        if _module_vm_safe(tree):
            vm_blob = pack_module_capsule_v2(tree)
            bootstrap = compile("__samarth_module_vm_marker = None", "<samarth>", "exec")
            from .bytecode_engine import MODULE_VM_MARKER
            marker=(MODULE_VM_MARKER,bytes(vm_blob))
            bootstrap=bootstrap.replace(co_consts=tuple(marker if x is None else x for x in bootstrap.co_consts))
            metadata = {
                "format": "samarth-code-v9",
                "compiled_by": [sys.version_info.major, sys.version_info.minor, sys.version_info.micro],
                "execution_model": "module-vm-v2",
                "protection": "segmented-module-vm",
                "profile": profile,
                "logical_name": logical,
            }
            payload = pack_code(bootstrap, metadata)
        else:
            tree, vm_count, total_funcs, selected_ids = virtualize_functions_v2(tree, profile)
            original_tree = ast.parse(source)
            original_funcs = [n for n in ast.walk(original_tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
            selected = [(fid, original_funcs[fid]) for fid in selected_ids]
            vm_blob = pack_function_capsule_v2(selected, profile=profile)
            code = compile(tree, "<samarth>", "exec", optimize=cfg.optimize)
            metadata = {
                "format": "samarth-code-v9",
                "compiled_by": [sys.version_info.major, sys.version_info.minor, sys.version_info.micro],
                "execution_model": "function-vm-v2",
                "protection": "segmented-function-vm",
                "profile": profile,
                "vm_virtualized_functions": vm_count,
                "vm_total_functions": total_funcs,
                "logical_name": logical,
            }
            payload = pack_function_vm_code(code, vm_blob, metadata)

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(payload)
    return report, payload


def _portable_vm_tree(source: str) -> ast.Module:
    """Return a module AST only when the custom VM can preserve its semantics."""
    tree = ast.parse(source)
    docstring = ast.get_docstring(tree, clean=False)
    allowed = {
        "Module", "FunctionDef", "ClassDef", "Return", "Assign", "AugAssign",
        "For", "While", "If", "With", "Raise", "Try", "Assert", "Import",
        "ImportFrom", "Expr", "Pass", "Break", "Continue", "BoolOp", "BinOp",
        "UnaryOp", "Lambda", "IfExp", "Dict", "Set", "ListComp", "SetComp",
        "DictComp", "GeneratorExp", "Compare", "Call", "FormattedValue",
        "JoinedStr", "Constant", "Attribute", "Subscript", "Starred", "Name",
        "List", "Tuple", "Slice", "comprehension", "ExceptHandler", "arguments",
        "arg", "keyword", "alias", "withitem", "Load", "Store", "Del", "And",
        "Or", "Add", "Sub", "Mult", "Div", "FloorDiv", "Mod", "Pow", "LShift",
        "RShift", "BitOr", "BitXor", "BitAnd", "MatMult", "UAdd", "USub",
        "Invert", "Not", "Eq", "NotEq", "Lt", "LtE", "Gt", "GtE", "Is",
        "IsNot", "In", "NotIn", "TypeIgnore",
    }
    for node in ast.walk(tree):
        if type(node).__name__ not in allowed:
            raise ValueError(f"portable VM does not support {type(node).__name__}")
        if isinstance(node, ast.ImportFrom) and any(alias.name == "*" for alias in node.names):
            raise ValueError("portable VM does not support star imports")
        if isinstance(node, ast.Raise) and node.cause is not None:
            raise ValueError("portable VM does not support explicit raise causes")
        if isinstance(node, ast.ExceptHandler) and node.name is not None:
            raise ValueError("portable VM does not support exception target bindings")
        if isinstance(node, ast.FormattedValue) and node.conversion != -1:
            raise ValueError("portable VM does not support f-string conversions")
        if isinstance(node, ast.FunctionDef):
            if node.returns is not None or any(a.annotation is not None for a in node.args.posonlyargs + node.args.args + node.args.kwonlyargs):
                raise ValueError("portable VM does not support function annotations")
            if getattr(node, "type_params", ()):
                raise ValueError("portable VM does not support generic function type parameters")
        if isinstance(node, ast.ClassDef):
            if node.keywords or getattr(node, "type_params", ()):
                raise ValueError("portable VM does not support class keywords or generic type parameters")
            for statement in node.body:
                if not isinstance(statement, (ast.FunctionDef, ast.Assign, ast.Expr, ast.Pass)):
                    raise ValueError("portable VM supports only simple class-body statements")
                if isinstance(statement, ast.Assign) and any(not isinstance(t, ast.Name) for t in statement.targets):
                    raise ValueError("portable VM class assignments must bind simple names")
        if isinstance(node, ast.comprehension) and node.is_async:
            raise ValueError("portable VM does not support asynchronous comprehensions")
    
    
    tree.body = [n for n in tree.body if not (isinstance(n, ast.ImportFrom) and n.module == "__future__")]
    ast.fix_missing_locations(tree)
    if docstring is not None:
        tree._samarth_module_docstring = docstring
    return tree


def _module_vm_safe(tree: ast.AST) -> bool:
    
    
    unsupported=(ast.Match, ast.AsyncWith)
    if any(isinstance(n,unsupported) for n in ast.walk(tree)): return False
    return True


def _manifest_hashes(out: Path, files: list[str]) -> dict[str, str]:
    return {name: payload_sha256((out / name).read_bytes()) for name in files}


def protect_project(src: Path, out: Path, profile="advanced", *, hardened_options: dict | None = None):
    profile = profile.lower()
    if profile not in PROFILES:
        raise ValueError(f"Unknown profile: {profile}")
    if profile in {"native", "hybrid"}:
        raise BackendError(f"Profile {profile.upper()} is backend-only. Use 'samarth protect' with the corresponding backend.")
    out.mkdir(parents=True, exist_ok=True)
    reports = {}
    entries: list[str] = []
    if src.is_file():
        target = out / (src.stem + ".sme")
        report, _ = protect_file(src, target, profile, hardened_options=hardened_options)
        entries.append(target.name)
        reports[target.name] = report.__dict__
    else:
        pyfiles = sorted(src.rglob("*.py"))
        if not pyfiles:
            raise ValueError("Project contains no Python files.")
        for p in pyfiles:
            rel = p.relative_to(src).with_suffix(".sme")
            target = out / rel
            report, _ = protect_file(p, target, profile, source_root=src, hardened_options=hardened_options)
            entries.append(rel.as_posix())
            reports[rel.as_posix()] = report.__dict__

    manifest = {
        "format": "samarth-bundle-v2",
        "profile": profile,
        "source": src.name,
        "python_versions": [f"{sys.version_info.major}.{sys.version_info.minor}"],
        "files": entries,
        "sha256": _manifest_hashes(out, entries),
        "transform_reports": reports,
        "runtime_architecture": "version-specific-compiled-code-runtime",
        "protection_features": ["segmented-function-vm", "numeric-capsule-tags", "filename-normalization", "sha256-integrity"],
        "payload_format": "SAMENC68",
        "confidentiality": "none",
        "offline": True,
        "key_required": False,
    }
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    return manifest
