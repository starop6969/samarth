from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import secrets
import struct
import subprocess
import tempfile
import zipfile

MAX_NATIVE_SIZE = 256 * 1024 * 1024
MAX_NATIVE_META = 256 * 1024
MAX_NATIVE_FILES = 4096
MAX_NATIVE_MEMBER = 128 * 1024 * 1024
from pathlib import Path

MAGIC = b"SAMNAT63"
VERSION = 1


def pack_native(binary: bytes, metadata: dict) -> bytes:
    if not isinstance(binary, (bytes, bytearray)):
        raise TypeError("Native payload must be bytes")
    if not isinstance(metadata, dict):
        raise TypeError("Native metadata must be a dictionary")
    meta = json.dumps(metadata, sort_keys=True, separators=(",", ":")).encode()
    if len(meta) > MAX_NATIVE_META:
        raise ValueError("SAMARTH native metadata exceeds size limit")
    if len(binary) + 13 + len(meta) + 32 > MAX_NATIVE_SIZE:
        raise ValueError("SAMARTH native payload exceeds size limit")
    body = MAGIC + bytes([VERSION]) + struct.pack(">I", len(meta)) + meta + bytes(binary)
    return body + hashlib.sha256(body).digest()


def unpack_native(blob: bytes) -> tuple[bytes, dict]:
    if len(blob) > MAX_NATIVE_SIZE:
        raise ValueError("SAMARTH native payload exceeds size limit")
    if len(blob) < 13 + 32 or not blob.startswith(MAGIC):
        raise ValueError("Invalid SAMARTH native payload")
    body, digest = blob[:-32], blob[-32:]
    if not secrets.compare_digest(hashlib.sha256(body).digest(), digest):
        raise ValueError("SAMARTH native payload integrity verification failed")
    if body[8] != VERSION:
        raise ValueError("Unsupported SAMARTH native payload version")
    n = struct.unpack(">I", body[9:13])[0]
    end = 13 + n
    if n > MAX_NATIVE_META or end > len(body):
        raise ValueError("SAMARTH native metadata exceeds size limit or is truncated")
    try:
        metadata = json.loads(body[13:end].decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("Invalid SAMARTH native metadata") from exc
    if not isinstance(metadata, dict) or metadata.get("format") not in {"samarth-native-v1", "samarth-pyarmor-v1"}:
        raise ValueError("Unsupported SAMARTH native metadata format")
    return body[end:], metadata


def _safe_extract_zip(zf: zipfile.ZipFile, destination: Path) -> None:
    infos = zf.infolist()
    if len(infos) > MAX_NATIVE_FILES:
        raise ValueError("Native archive contains too many files")
    destination = destination.resolve()
    total = 0
    for info in infos:
        name = info.filename
        if not name or name.startswith("/") or "\\" in name:
            raise ValueError("Unsafe archive member path")
        target = (destination / name).resolve()
        try:
            target.relative_to(destination)
        except ValueError as exc:
            raise ValueError("Archive path traversal detected") from exc
        if info.file_size > MAX_NATIVE_MEMBER or info.compress_size > MAX_NATIVE_MEMBER:
            raise ValueError("Archive member exceeds size limit")
        total += info.file_size
        if total > MAX_NATIVE_SIZE:
            raise ValueError("Archive expands beyond size limit")
    destination.mkdir(parents=True, exist_ok=True)
    for info in infos:
        target = (destination / info.filename).resolve()
        if info.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        with zf.open(info, "r") as src, target.open("wb") as dst:
            remaining = info.file_size
            while remaining:
                chunk = src.read(min(1024 * 1024, remaining))
                if not chunk:
                    raise ValueError("Truncated archive member")
                dst.write(chunk)
                remaining -= len(chunk)



def _safe_leaf(value, label: str) -> str:
    if (not isinstance(value, str) or not value or value in {".", ".."}
            or Path(value).name != value or "/" in value or "\\" in value):
        raise ValueError(f"Invalid {label} in SAMARTH native metadata")
    return value


def _safe_relative_entry(value) -> Path:
    if not isinstance(value, str) or not value or "\\" in value:
        raise ValueError("Invalid PyArmor entry path in SAMARTH metadata")
    rel = Path(value)
    if rel.is_absolute() or any(part in {"", ".", ".."} for part in rel.parts):
        raise ValueError("Unsafe PyArmor entry path in SAMARTH metadata")
    return rel


def _validate_native_target(meta: dict) -> None:
    import platform
    import sys
    import sysconfig

    backend = meta.get("backend")
    kind = meta.get("native_kind")
    if backend not in {"nuitka", "cython", "pyarmor"}:
        raise RuntimeError(f"Unsupported native backend metadata: {backend!r}")
    if backend == "nuitka" and kind != "executable":
        raise RuntimeError("Invalid Nuitka artifact kind in SAMARTH metadata")
    if backend == "cython" and kind not in {"executable", "executable-bundle", "extension"}:
        raise RuntimeError("Invalid Cython artifact kind in SAMARTH metadata")
    if backend == "pyarmor" and meta.get("format") != "samarth-pyarmor-v1":
        raise RuntimeError("Invalid PyArmor artifact metadata")
    expected_os = meta.get("os")
    expected_arch = meta.get("arch")
    if expected_os is not None and not isinstance(expected_os, str):
        raise RuntimeError("Invalid target OS in SAMARTH metadata")
    if expected_arch is not None and not isinstance(expected_arch, str):
        raise RuntimeError("Invalid target architecture in SAMARTH metadata")
    if expected_os and expected_os != platform.system():
        raise RuntimeError(f"Native artifact targets {expected_os}, current OS is {platform.system()}.")
    if expected_arch and expected_arch.lower() != platform.machine().lower():
        raise RuntimeError(f"Native artifact targets {expected_arch}, current architecture is {platform.machine()}.")
    expected_env = meta.get("environment")
    if expected_env:
        from .environment import detect_environment, _environment_name
        env = detect_environment()
        current_env = _environment_name(env)
        if expected_env != current_env:
            raise RuntimeError(f"Native artifact was built for {expected_env}, current environment is {current_env}.")
    
    if backend in {"cython", "pyarmor"} and kind in {"executable", "executable-bundle", "extension", None}:
        expected_python = meta.get("python")
        current_python = f"{sys.version_info.major}.{sys.version_info.minor}"
        if expected_python and expected_python != current_python:
            raise RuntimeError(f"Native artifact targets Python {expected_python}, current Python is {current_python}.")
    if kind == "extension":
        expected_abi = meta.get("soabi")
        current_abi = sysconfig.get_config_var("SOABI")
        if expected_abi and current_abi and expected_abi != current_abi:
            raise RuntimeError(f"Native extension ABI mismatch: artifact={expected_abi}, current={current_abi}.")

def run_native(blob: bytes, args: list[str] | None = None) -> dict:
    payload, meta = unpack_native(blob)
    _validate_native_target(meta)
    args = args or []
    with tempfile.TemporaryDirectory(prefix="samarth-external-") as td:
        root = Path(td)
        if meta.get("backend") == "nuitka":
            suffix = ".exe" if os.name == "nt" else ""
            executable_name = _safe_leaf(meta.get("executable_name", "samarth_app"), "executable filename")
            exe = root / (executable_name + suffix)
            exe.write_bytes(payload)
            if os.name != "nt":
                exe.chmod(0o700)
            proc = subprocess.run([str(exe), *args])
        elif meta.get("backend") == "cython":
            if meta.get("native_kind") == "executable-bundle":
                archive = root / "hybrid.zip"
                archive.write_bytes(payload)
                with zipfile.ZipFile(archive) as zf:
                    _safe_extract_zip(zf, root / "app")
                executable_name = _safe_leaf(meta.get("executable_name", "samarth_app"), "executable filename")
                exe = root / "app" / executable_name
                if not exe.is_file():
                    raise RuntimeError("Cython hybrid executable is missing from the packaged runtime")
                env = os.environ.copy()
                env["PYTHONPATH"] = str(root / "app") + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
                if os.name != "nt":
                    exe.chmod(0o700)
                proc = subprocess.run([str(exe), *args], env=env)
            elif meta.get("native_kind") == "extension":
                archive = root / "cython-extension.zip"
                archive.write_bytes(payload)
                app = root / "app"
                with zipfile.ZipFile(archive) as zf:
                    _safe_extract_zip(zf, app)
                ext_name = _safe_leaf(meta.get("extension"), "native extension filename")
                ext = app / ext_name
                if not ext.is_file():
                    raise RuntimeError("Packaged Cython extension is missing")
                module_name = meta.get("module_name", "_samarth_entry")
                if not isinstance(module_name, str) or not module_name.isidentifier():
                    raise RuntimeError("Invalid native extension module name")
                spec = importlib.util.spec_from_file_location(module_name, ext)
                if spec is None or spec.loader is None:
                    raise RuntimeError("Current Python cannot load this native extension")
                import sys
                old_argv = sys.argv[:]
                old_path = sys.path[:]
                missing = object()
                old_module = sys.modules.get(module_name, missing)
                try:
                    sys.argv = [meta.get("entry", ext_name), *args]
                    sys.path.insert(0, str(app))
                    module = importlib.util.module_from_spec(spec)
                    sys.modules[module_name] = module
                    spec.loader.exec_module(module)
                finally:
                    sys.argv = old_argv
                    sys.path[:] = old_path
                    if old_module is missing:
                        sys.modules.pop(module_name, None)
                    else:
                        sys.modules[module_name] = old_module
                proc = subprocess.CompletedProcess(args=[], returncode=0)
            else:
                executable_name = _safe_leaf(meta.get("executable_name", "samarth_app"), "executable filename")
                exe = root / (executable_name + (".exe" if os.name == "nt" else ""))
                exe.write_bytes(payload)
                if os.name != "nt":
                    exe.chmod(0o700)
                proc = subprocess.run([str(exe), *args])
        elif meta.get("backend") == "pyarmor":
            archive = root / "runtime.zip"
            archive.write_bytes(payload)
            with zipfile.ZipFile(archive) as zf:
                _safe_extract_zip(zf, root / "app")
            entry = root / "app" / _safe_relative_entry(meta.get("entry"))
            if not entry.is_file():
                raise RuntimeError("PyArmor entry file is missing from the packaged runtime")
            proc = subprocess.run([os.environ.get("PYTHON", os.sys.executable), str(entry), *args])
        else:
            raise RuntimeError(f"Unsupported external backend: {meta.get('backend')}")
    if proc.returncode:
        raise RuntimeError(f"External SAMARTH payload exited with code {proc.returncode}")
    return meta
