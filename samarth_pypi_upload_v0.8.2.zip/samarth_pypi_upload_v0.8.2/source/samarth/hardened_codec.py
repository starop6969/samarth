"""Keyless, reversible obfuscation primitives for SAMARTH PORTABLE-HARDENED.

These transforms are packaging/analysis-cost measures, not cryptography.
All parameters and inverse logic ship with the artifact.
"""
from __future__ import annotations
import hashlib
import itertools
import json
import math
import secrets
import struct
import zlib


def gf_mul(a: int, b: int) -> int:
    out = 0
    while b:
        if b & 1: out ^= a
        b >>= 1
        a <<= 1
        if a & 0x100: a ^= 0x11d
    return out & 0xff

def gf_pow(a: int, n: int) -> int:
    out = 1
    while n:
        if n & 1: out = gf_mul(out, a)
        a = gf_mul(a, a); n >>= 1
    return out

def gf_inv(a: int) -> int:
    if not a: raise ZeroDivisionError("zero has no GF(256) inverse")
    return gf_pow(a, 254)

def _poly_params(salt: bytes, layer: int):
    d = hashlib.sha256(b"SAMARTH-GF-POLY-v1" + salt + bytes([layer])).digest()
    return (d[0] or 1), d[1]

def polynomial_permute(data: bytes, salt: bytes, layers: int = 2) -> bytes:
    if not 1 <= layers <= 3: raise ValueError("layers must be 1..3")
    out = bytearray(data)
    
    for layer in range(layers):
        a, b = _poly_params(salt, layer)
        out = bytearray(gf_mul(a, gf_pow(x, 7)) ^ b for x in out)
    return bytes(out)

def polynomial_unpermute(data: bytes, salt: bytes, layers: int = 2) -> bytes:
    if not 1 <= layers <= 3: raise ValueError("layers must be 1..3")
    out = bytearray(data)
    for layer in reversed(range(layers)):
        a, b = _poly_params(salt, layer)
        inv_a = gf_inv(a)
        out = bytearray(gf_pow(gf_mul(inv_a, x ^ b), 73) for x in out)
    return bytes(out)

def feistel_diffuse(data: bytes, salt: bytes, rounds: int = 4) -> bytes:
    if not 3 <= rounds <= 4: raise ValueError("rounds must be 3 or 4")
    
    raw = struct.pack(">I", len(data)) + data
    if len(raw) & 1: raw += b"\0"
    half = len(raw) // 2
    left, right = raw[:half], raw[half:]
    for r in range(rounds):
        f = hashlib.shake_256(b"SAMARTH-FEISTEL-v1" + salt + bytes([r]) + right).digest(half)
        left, right = right, bytes(a ^ b for a, b in zip(left, f))
    return left + right

def feistel_undiffuse(data: bytes, salt: bytes, rounds: int = 4) -> bytes:
    if not 3 <= rounds <= 4: raise ValueError("rounds must be 3 or 4")
    if len(data) < 4 or len(data) & 1: raise ValueError("invalid Feistel block")
    half = len(data)//2
    left, right = data[:half], data[half:]
    for r in reversed(range(rounds)):
        old_right = left
        f = hashlib.shake_256(b"SAMARTH-FEISTEL-v1" + salt + bytes([r]) + old_right).digest(half)
        old_left = bytes(a ^ b for a,b in zip(right, f))
        left, right = old_left, old_right
    raw = left + right
    n = struct.unpack_from(">I", raw)[0]
    if n > len(raw)-4: raise ValueError("invalid Feistel length")
    return raw[4:4+n]

def lehmer_rank(permutation):
    p = list(permutation); n=len(p)
    if sorted(p) != list(range(n)): raise ValueError("not a permutation")
    rank=0
    for i,x in enumerate(p): rank += sum(y<x for y in p[i+1:]) * math.factorial(n-i-1)
    return rank

def lehmer_unrank(rank: int, n: int):
    if n < 0 or rank < 0 or rank >= math.factorial(n): raise ValueError("invalid Lehmer rank")
    pool=list(range(n)); out=[]
    for i in range(n):
        f=math.factorial(n-i-1); q,rank=divmod(rank,f); out.append(pool.pop(q))
    return out

def _permutation_from_digest(digest: bytes, n: int):
    
    rank = int.from_bytes(digest, "big") % math.factorial(n)
    return lehmer_unrank(rank,n), rank


def _matrix_inverse(mat):
    n=len(mat); a=[list(row)+[1 if i==j else 0 for j in range(n)] for i,row in enumerate(mat)]
    for col in range(n):
        pivot=next((r for r in range(col,n) if a[r][col]),None)
        if pivot is None: raise ValueError("singular erasure matrix")
        a[col],a[pivot]=a[pivot],a[col]
        scale=gf_inv(a[col][col]); a[col]=[gf_mul(x,scale) for x in a[col]]
        for r in range(n):
            if r==col: continue
            factor=a[r][col]
            if factor: a[r]=[x ^ gf_mul(factor,y) for x,y in zip(a[r],a[col])]
    return [row[n:] for row in a]

def _cauchy(k,m):
    
    xs=list(range(1,k+1)); ys=list(range(32,32+m))
    return [[gf_inv(x ^ y) for x in xs] for y in ys]

def rs_encode(data: bytes, k: int = 4, m: int = 3):
    if not (1 <= k <= 16 and 1 <= m <= 8 and k+m <= 24): raise ValueError("unsupported shard counts")
    size=(len(data)+k-1)//k
    padded=data+b"\0"*(size*k-len(data))
    ds=[padded[i*size:(i+1)*size] for i in range(k)]
    matrix=_cauchy(k,m); parity=[]
    for row in matrix:
        shard=bytearray(size)
        for coeff,src in zip(row,ds):
            for i,b in enumerate(src): shard[i] ^= gf_mul(coeff,b)
        parity.append(bytes(shard))
    return ds+parity, len(data)

def rs_decode(shards, k: int, m: int, original_length: int):
    if not (1 <= k <= 16 and 1 <= m <= 8 and k + m <= 24):
        raise ValueError("unsupported shard counts")
    if not isinstance(shards, dict) or len(shards) < k:
        raise ValueError("not enough shards")
    if not isinstance(original_length, int) or isinstance(original_length, bool) or original_length < 0:
        raise ValueError("invalid original length")
    chosen=list(shards.items())[:k]
    indices=[idx for idx,_ in chosen]
    if any(not isinstance(idx,int) or isinstance(idx,bool) or not 0 <= idx < k+m for idx in indices):
        raise ValueError("invalid shard index")
    if len(set(indices)) != len(indices):
        raise ValueError("duplicate shard index")
    if any(not isinstance(v,(bytes,bytearray)) for _,v in chosen):
        raise ValueError("invalid shard data")
    size=len(chosen[0][1])
    if any(len(v)!=size for _,v in chosen): raise ValueError("inconsistent shard sizes")
    if original_length > size * k:
        raise ValueError("original length exceeds shard capacity")
    rows=[]
    parity=_cauchy(k,m)
    for idx,_ in chosen:
        if idx < k: rows.append([1 if i==idx else 0 for i in range(k)])
        else: rows.append(parity[idx-k])
    inv=_matrix_inverse(rows)
    recovered=[bytearray(size) for _ in range(k)]
    for out_i,row in enumerate(inv):
        for coeff,(_,src) in zip(row,chosen):
            for j,b in enumerate(src): recovered[out_i][j] ^= gf_mul(coeff,b)
    return b"".join(map(bytes,recovered))[:original_length]

def bitplane_encode(data: bytes) -> bytes:
    
    out=bytearray()
    for start in range(0,len(data),8):
        block=data[start:start+8].ljust(8,b"\0")
        for bit in range(7,-1,-1):
            out.append(sum(((v>>bit)&1) << (7-i) for i,v in enumerate(block)))
    return bytes(out)

def bitplane_decode(data: bytes, original_length: int) -> bytes:
    if len(data)%8: raise ValueError("invalid bit-plane stream")
    out=bytearray()
    for start in range(0,len(data),8):
        planes=data[start:start+8]; block=bytearray(8)
        for bit,plane in zip(range(7,-1,-1),planes):
            for i in range(8): block[i] |= ((plane>>(7-i))&1)<<bit
        out.extend(block)
    return bytes(out[:original_length])

def add_chaff(real_shards, count: int, salt: bytes):
    if not 0 <= count <= 8: raise ValueError("chaff count must be 0..8")
    out=[(i,bytes(s)) for i,s in enumerate(real_shards)]
    for i in range(count):
        n=len(real_shards[0]) if real_shards else 0
        fake=hashlib.shake_256(b"SAMARTH-CHAFF-v1"+salt+bytes([i])).digest(n)
        out.append((-1-i, fake))
    return out

def select_real_shards(items, checksums):
    out={}
    for index, shard in items:
        if index >= 0 and hashlib.sha256(shard).digest() == checksums.get(index): out[index]=shard
    return out

__all__=["gf_mul","gf_pow","gf_inv","polynomial_permute","polynomial_unpermute",
         "feistel_diffuse","feistel_undiffuse","lehmer_rank","lehmer_unrank",
         "rs_encode","rs_decode","bitplane_encode","bitplane_decode","add_chaff","select_real_shards"]

HARD_MAGIC=b"SAMHER03"
HARD_HEADER=struct.Struct(">8sBI")
MAX_HARD=64*1024*1024

def pack_hardened_source(source: str, metadata=None, *, chaff_count=2, bitplane=True, poly_layers=2, feistel_rounds=4, rs_k=4, rs_m=3):
    """Pack source with reversible keyless transforms and erasure-coded shards."""
    from bz2 import compress
    if not isinstance(source,str): raise TypeError("source must be text")
    raw=source.encode("utf-8")
    if len(raw)>48*1024*1024: raise ValueError("SAMARTH source exceeds size limit")
    salt=secrets.token_bytes(32)
    stage=compress(raw,compresslevel=9)
    bp_len=len(stage)
    if bitplane: stage=bitplane_encode(stage)
    stage=feistel_diffuse(stage,salt,feistel_rounds)
    stage=polynomial_permute(stage,salt,poly_layers)
    digest=hashlib.sha256(stage).digest()
    shards, original_len=rs_encode(stage,rs_k,rs_m)
    order,rank=_permutation_from_digest(digest, len(shards))
    chaff=add_chaff(shards,chaff_count,salt)
    
    records=[(i,shards[i]) for i in order]
    records.extend(chaff[len(shards):])
    checksums=[hashlib.sha256(s).hexdigest() for s in shards]
    meta=dict(metadata or {})
    meta.update({"format":"samarth-hermit-v3","codec":"bz2+bitplane+feistel-shake256+gf256-polynomial+rs-cauchy+binary-shards",
                 "protection_note":"reversible_keyless_obfuscation_not_encryption","salt":salt.hex(),
                 "bitplane":bool(bitplane),"bitplane_input_length":bp_len,"poly_layers":poly_layers,
                 "feistel_rounds":feistel_rounds,"rs_k":rs_k,"rs_m":rs_m,"stage_length":len(stage),
                 "source_length":len(raw),"shard_original_length":original_len,"shard_size":len(shards[0]),
                 "order_rank":rank,"stage_sha256":digest.hex(),"shard_checksums":checksums,
                 "chaff_count":chaff_count,"fragment_count":len(records)})
    meta_raw=json.dumps(meta,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")
    if len(meta_raw)>256*1024: raise ValueError("SAMARTH metadata exceeds size limit")
    body=bytearray(HARD_HEADER.pack(HARD_MAGIC,3,len(meta_raw))); body.extend(meta_raw); body.append(len(records))
    for _,shard in records:
        body.extend(struct.pack(">I",len(shard))); body.extend(hashlib.sha256(shard).digest()); body.extend(shard)
    if len(body)+32>MAX_HARD: raise ValueError("SAMARTH payload exceeds size limit")
    return bytes(body)+hashlib.sha256(body).digest()

def _meta_int(meta, name, minimum=0, maximum=MAX_HARD):
    value = meta.get(name)
    if not isinstance(value, int) or isinstance(value, bool) or not minimum <= value <= maximum:
        raise ValueError(f"invalid hardened metadata field: {name}")
    return value


def _bounded_bz2_decompress(data: bytes, expected_length: int) -> bytes:
    """Decompress one BZ2 stream without allowing unbounded expansion."""
    from bz2 import BZ2Decompressor
    if not 0 <= expected_length <= 48 * 1024 * 1024:
        raise ValueError("invalid hardened source length")
    dec = BZ2Decompressor()
    
    out = dec.decompress(data, max_length=expected_length + 1)
    if len(out) > expected_length:
        raise ValueError("hardened source exceeds declared size limit")
    if not dec.eof:
        
        if not dec.needs_input:
            extra = dec.decompress(b"", max_length=1)
            if extra or not dec.eof:
                raise ValueError("hardened source exceeds declared size limit")
        if not dec.eof:
            raise ValueError("incomplete or oversized BZ2 stream")
    if dec.unused_data:
        raise ValueError("unexpected trailing data after BZ2 stream")
    if len(out) != expected_length:
        raise ValueError("hardened source length mismatch")
    return out


def unpack_hardened_source(payload: bytes):
    if not isinstance(payload,(bytes,bytearray)): raise TypeError("payload must be bytes")
    blob=bytes(payload)
    if len(blob)>MAX_HARD or len(blob)<HARD_HEADER.size+1+32: raise ValueError("invalid hardened payload size")
    body,outer=blob[:-32],blob[-32:]
    outer_ok=secrets.compare_digest(hashlib.sha256(body).digest(),outer)
    
    
    magic,version,mlen=HARD_HEADER.unpack_from(body)
    if magic!=HARD_MAGIC or version!=3: raise ValueError("unsupported hardened payload")
    pos=HARD_HEADER.size
    if mlen>256*1024 or pos+mlen+1>len(body): raise ValueError("invalid hardened metadata")
    try:
        meta=json.loads(body[pos:pos+mlen].decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("invalid hardened metadata JSON") from exc
    if not isinstance(meta,dict) or meta.get("format")!="samarth-hermit-v3":
        raise ValueError("invalid hardened metadata format")
    pos+=mlen
    declared_count=body[pos]; pos+=1
    k=_meta_int(meta,"rs_k",1,16); m=_meta_int(meta,"rs_m",1,8)
    if k+m>24: raise ValueError("invalid erasure-code dimensions")
    chaff_count=_meta_int(meta,"chaff_count",0,8)
    expected_count=k+m+chaff_count
    if declared_count!=expected_count or declared_count!=meta.get("fragment_count"):
        raise ValueError("invalid hardened fragment count")
    source_length=_meta_int(meta,"source_length",0,48*1024*1024)
    stage_length=_meta_int(meta,"stage_length",1,MAX_HARD)
    shard_original_length=_meta_int(meta,"shard_original_length",1,MAX_HARD)
    shard_size=_meta_int(meta,"shard_size",1,MAX_HARD)
    if shard_original_length!=stage_length or shard_size!=(stage_length+k-1)//k:
        raise ValueError("inconsistent hardened shard dimensions")
    poly_layers=_meta_int(meta,"poly_layers",1,3)
    feistel_rounds=_meta_int(meta,"feistel_rounds",3,4)
    bitplane=meta.get("bitplane")
    if not isinstance(bitplane,bool): raise ValueError("invalid bit-plane setting")
    bitplane_input_length=_meta_int(meta,"bitplane_input_length",0,MAX_HARD)
    salt_hex=meta.get("salt")
    if not isinstance(salt_hex,str) or len(salt_hex)!=64:
        raise ValueError("invalid hardened salt")
    try: salt=bytes.fromhex(salt_hex)
    except ValueError as exc: raise ValueError("invalid hardened salt") from exc
    digest_hex=meta.get("stage_sha256")
    if not isinstance(digest_hex,str) or len(digest_hex)!=64:
        raise ValueError("invalid hardened stage digest")
    try: digest=bytes.fromhex(digest_hex)
    except ValueError as exc: raise ValueError("invalid hardened stage digest") from exc
    checks_raw=meta.get("shard_checksums")
    if not isinstance(checks_raw,list) or len(checks_raw)!=k+m:
        raise ValueError("invalid hardened shard checksum list")
    try:
        checks=[bytes.fromhex(x) for x in checks_raw if isinstance(x,str) and len(x)==64]
    except ValueError as exc: raise ValueError("invalid hardened shard checksum") from exc
    if len(checks)!=k+m or any(len(x)!=32 for x in checks) or len(set(checks))!=len(checks):
        raise ValueError("invalid hardened shard checksum list")
    pos_rank=_meta_int(meta,"order_rank",0,math.factorial(k+m)-1)
    expected_order,expected_rank=_permutation_from_digest(digest,k+m)
    if pos_rank!=expected_rank: raise ValueError("hardened fragment order validation failed")

    records=[]
    seen_checksums=set()
    
    
    while pos < len(body):
        if len(body)-pos < 36:
            break
        n=struct.unpack_from(">I",body,pos)[0]; pos+=4
        checksum=body[pos:pos+32]; pos+=32
        if n!=shard_size:
            raise ValueError("invalid hardened shard length")
        if n>len(body)-pos:
            break
        shard=body[pos:pos+n]; pos+=n
        if checksum in seen_checksums:
            raise ValueError("duplicate hardened fragment")
        seen_checksums.add(checksum)
        if secrets.compare_digest(hashlib.sha256(shard).digest(),checksum):
            records.append((checksum,shard))
    if pos != len(body) and len(body)-pos >= 36:
        raise ValueError("malformed hardened fragment records")
    if outer_ok and len(records)!=declared_count:
        raise ValueError("SAMARTH integrity check failed")

    lookup={h:i for i,h in enumerate(checks)}
    found={}; physical_real=[]
    for checksum,shard in records:
        idx=lookup.get(checksum)
        if idx is not None:
            if idx in found: raise ValueError("duplicate real hardened fragment")
            found[idx]=shard; physical_real.append(idx)
    cursor=0
    for idx in physical_real:
        try: cursor=expected_order.index(idx,cursor)+1
        except ValueError as exc: raise ValueError("hardened fragment order validation failed") from exc
    if len(found)<k: raise ValueError("not enough valid shards after chaff filtering")
    stage=rs_decode(found,k,m,stage_length)
    if not secrets.compare_digest(hashlib.sha256(stage).digest(),digest):
        raise ValueError("hardened stage digest mismatch")
    stage=polynomial_unpermute(stage,salt,poly_layers)
    stage=feistel_undiffuse(stage,salt,feistel_rounds)
    if bitplane:
        if bitplane_input_length > MAX_HARD:
            raise ValueError("invalid bit-plane input length")
        expected_plane_length=((bitplane_input_length+7)//8)*8
        if len(stage)!=expected_plane_length:
            raise ValueError("inconsistent bit-plane dimensions")
        stage=bitplane_decode(stage,bitplane_input_length)
    elif bitplane_input_length != len(stage):
        raise ValueError("inconsistent bit-plane metadata")
    raw=_bounded_bz2_decompress(stage,source_length)
    try: source=raw.decode("utf-8")
    except UnicodeDecodeError as exc: raise ValueError("hardened source is not valid UTF-8") from exc
    return source,meta

