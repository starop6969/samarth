# Pydroid 3 installation and local native build

SAMARTH does not cross-compile a Pydroid binary on a desktop. Build and run the artifact inside the same Pydroid installation so the Cython extension matches that interpreter's Android ABI.

1. In Pydroid, install/enable its compatible repository or compiler support if your installation requires it.
2. Install the SAMARTH build extras in Pydroid:

   ```bash
   pip install --upgrade "samarth[hybrid]"
   ```

3. Run the environment report:

   ```bash
   python -m samarth env
   ```

4. Confirm it identifies Pydroid/Android and reports Cython, setuptools, a compiler and `python_headers: true`. If any are missing, the native build is not available in that installation.
5. Build on the device:

   ```bash
   python -m samarth protect app.py -o dist-pydroid --profile native --backend cython
   ```

   For HYBRID:

   ```bash
   python -m samarth protect app.py -o dist-pydroid-hybrid --profile hybrid --backend cython
   ```

6. Run it in the same Pydroid interpreter:

   ```bash
   python -m samarth run dist-pydroid/app.sme
   ```

Android builds use an ABI-tagged Cython extension inside the `.sme`, not a standalone Linux/Windows executable. Do not copy an artifact between Pydroid and Termux, between Python versions, or between architectures. If Pydroid does not expose compatible Python headers/compiler support, SAMARTH must report the native build as unavailable rather than silently downgrade.

Physical Pydroid device execution was not available during preparation of v0.6.11; this document describes the intended on-device verification workflow, not a PASS claim.

## Compiler-free PORTABLE-HARDENED mode (v0.8.2)

For an interpreter-only install, no compiler or Cython extras are needed:

```bash
pip install --upgrade samarth
python -m samarth protect app.py -o dist --profile portable-hardened
python -m samarth run dist/app.sme
```

This profile uses Python standard-library modules only and is designed to avoid Android native ABI issues. Physical Pydroid execution is not yet physically validated; run the commands on the target device before relying on it.
