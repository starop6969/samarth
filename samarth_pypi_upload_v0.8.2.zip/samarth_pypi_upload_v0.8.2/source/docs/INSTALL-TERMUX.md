# Termux installation / native verification

1. Install Python and a compiler/toolchain using the Termux package manager.
2. Install SAMARTH into that Python.
3. Run `python -m samarth env`.
4. Confirm the detected Python version, architecture, compiler and development headers match the intended target.
5. Build NATIVE with `python -m samarth protect app.py -o dist-native --profile native --backend cython`.
6. Execute with `python -m samarth run dist-native/app.sme`.
7. Repeat for HYBRID.

Do not reuse native artifacts across different Python ABIs or Android architectures.

Android/Termux builds use the active Termux Python ABI and Cython extension path; do not transfer Pydroid artifacts into Termux. Physical Termux execution was not available during preparation of v0.6.12, so this is a verification workflow rather than a PASS claim.

## Compiler-free PORTABLE-HARDENED mode (v0.8.2)

For an interpreter-only installation, no compiler or Cython extras are needed:

```bash
python -m pip install --upgrade samarth
python -m samarth protect app.py -o dist --profile portable-hardened
python -m samarth run dist/app.sme
```

This profile uses Python standard-library modules only. Physical Termux execution is not yet physically validated for v0.8.2; run the commands on the target device before relying on it.
