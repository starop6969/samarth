# SAMARTH ENC v0.8.2

SAMARTH ENC is a completely **keyless, offline** Python source-protection and packaging toolkit. No password, environment key, online service or mandatory authentication is used by the internal backend.

## Profiles

- `standard` — compiled CPython payload with metadata/path hardening.
- `advanced` — segmented function virtualization with conservative safety analysis.
- `maximum` — virtualizes every eligible function supported safely by the internal VM.
- `portable` — the v0.7.0 compiler-free AST-VM/container path, retained for backward compatibility.
- `portable-hardened` — separate compiler-free, stdlib-only binary container with GF(256) polynomial permutations, SHAKE-256 Feistel diffusion, Lehmer-derived fragment order, Cauchy erasure coding, optional bit-plane distribution and checksum-identified chaff. It currently protects transformed Python source; it does not claim the requested new VM opcode format.
- `native` — genuine external Nuitka backend only.
- `hybrid` — genuine external backend workflow only.

NATIVE/HYBRID never silently fall back to the internal backend.

## Keyless offline protection

```bash
samarth protect app.py -o protected --profile standard --backend internal
samarth protect app.py -o protected --profile advanced --backend internal
samarth protect app.py -o protected --profile maximum --backend internal
samarth protect app.py -o protected-portable --profile portable --backend internal
samarth protect app.py -o protected-hardened --profile portable-hardened --backend internal
samarth protect app.py -o protected-hardened --profile portable-hardened --hardened-chaff 3 --hardened-poly-layers 3
```

There is deliberately no `--sealed`, password, `SAMARTH_KEY`, or encryption-key configuration. Both portable profiles are keyless reversible obfuscation, not cryptographic encryption: the salt and decoding logic are included in the artifact/runtime. SHA-256 detects accidental or deliberate payload changes but does not authenticate the publisher. An analyst who controls execution can recover runtime-visible program state.

## Existing workflows

```text
samarth protect INPUT -o OUTPUT --profile advanced
samarth protect INPUT -o OUTPUT --profile maximum
samarth protect INPUT -o OUTPUT --profile standard
samarth run-bundle OUTPUT --name main
samarth run OUTPUT/main.sme
samarth protect-multi INPUT -o OUTPUT --profile advanced
```

## Pydroid 3 / Termux portable mode

Install the wheel in the target app's own Python interpreter, then build and run a portable payload there:

```bash
python -m pip install --upgrade samarth
python -m samarth protect app.py -o dist --profile portable --backend internal
python -m samarth run dist/app.sme
```

`portable` uses only the Python standard library at build and run time. It does not need Cython, a C compiler, Python.h, a shared libpython, or a matching native ABI. v0.7.0 first attempts a custom AST-interpreter capsule for a conservative supported subset. That path adds local identifier renaming and a packed literal pool, then stores the VM capsule inside a container with four rounds of custom reversible byte mixing, a per-artifact salt, Base85 transport, seven shuffled fragments, BZ2 compression and SHA-256 integrity validation. If a source uses syntax outside the tested VM subset, metadata explicitly records `portable-source-v2` and the original source is executed through the same layered container; it is not silently presented as VM-protected. The mixer is not cryptographic encryption and does not provide a secret key: the runtime contains all material needed to reverse it. A determined decoder can recover the program. Destructive anti-debug/anti-site behavior is intentionally excluded. `standard`, `advanced` and `maximum` remain CPython-bytecode/VM formats and are tied to the Python major/minor version used to build them.

## PORTABLE-HARDENED settings

```bash
python -m samarth protect app.py -o dist --profile portable-hardened \
  --hardened-chaff 2 --hardened-poly-layers 2 --hardened-feistel-rounds 4 \
  --hardened-rs-k 4 --hardened-rs-m 3
python -m samarth run dist/app.sme
```

Use `--hardened-no-bitplane` to disable bit-plane distribution. Chaff accepts 0–8; polynomial layers accept 1–3; Feistel rounds accept 3 or 4. The default 4+3 erasure code can recover up to three missing complete shards. These settings change reversible packaging, not confidentiality.

The new hardened container uses only the Python standard library and requires no compiler. v0.8.2 adds bounded BZ2 decompression, strict metadata/shard validation, duplicate-fragment rejection, stronger erasure-code input checks, and safer AST handling for f-strings and control-flow flattening. It is designed for the same interpreter-based execution model used by Pydroid 3 and Termux, but physical-device tests have not yet been run for v0.8.2. Physical-device testing on Pydroid 3 and Termux has not yet been completed for this release.

## Compatibility

The current runtime reads v0.6.2 (`SAMENC62`), v0.6.3 (`SAMENC63`), v0.6.4 (`SAMENC64`), v0.6.5 (`SAMENC65`) and v0.6.6 (`SAMENC66`) internal payloads. New artifacts use `SAMENC67` / format version 8.

The universal `samarth/loader.py` is intentionally unchanged byte-for-byte.

## Architecture changes

Advanced and Maximum move eligible function bodies into a segmented v2 VM capsule. The capsule uses numeric node tags, per-artifact symbol permutation, metadata/path hardening and generic callable shells. VM eligibility is conservative: async/generator-sensitive bodies, nested definitions, context-manager-heavy constructs, annotations and other CPython frame-sensitive cases remain native when needed for correctness. Zero-argument `super()` is tested specifically so the previous class-cell failure does not recur.

This is obfuscation rather than encryption. The v2 capsule is intentionally not presented as cryptographic secrecy.

## Benchmark methodology

The benchmark utility and internal audit reports are maintained in the development repository and are not included in the PyPI distribution.

It compares original token streams against the transformed source returned by the artifact decoder. It reports multiset token recovery, ordered token similarity, and exact source matches. It does not measure semantic recovery, reverse-engineering time, or runtime extraction. The checked-in 18-file SAMARTH source corpus measured 80.66% weighted multiset token recovery and 69.31% weighted ordered token similarity. These figures are corpus-specific and should not be compared directly with historical v0.6.x semantic benchmark scores. The current release does not claim the 60–70% semantic-recovery target has been achieved.

## Testing boundaries

CPython 3.13.5/Linux is the actual execution environment used for this release test. Python 3.11/3.12/3.14, Windows, Termux and Pydroid 3 are reported as NOT TESTED when those environments are unavailable. NATIVE/HYBRID are also reported separately when their external backends are unavailable.

## Native backends and capability detection

`samarth env` prints the locally detected Python ABI, OS, architecture, compiler/linker, Python development headers and available native backends. NATIVE and HYBRID refuse unsupported environments instead of silently downgrading.

### NATIVE

- `--backend nuitka`: genuine Nuitka native executable when Nuitka is installed and succeeds.
- `--backend cython`: genuine Cython native executable when CPython development headers/libpython and a C compiler are available. If embedded-executable linking is unavailable but extension compilation is possible, the artifact is explicitly marked as a native extension rather than being mislabeled as an executable.

Example:

```bash
python -m samarth env
python -m samarth protect app.py -o dist-native --profile native --backend cython
python -m samarth run dist-native/app.sme
```

### HYBRID

HYBRID applies SAMARTH's internal symbol/literal hardening before native compilation. The selected native backend is recorded in the artifact metadata. HYBRID accepts only genuine native backends (Nuitka or Cython); PyArmor cannot be used to claim HYBRID. There is no ADVANCED/MAXIMUM fallback.

```bash
python -m samarth protect app.py -o dist-hybrid --profile hybrid --backend cython
python -m samarth run dist-hybrid/app.sme
```

### Android / Pydroid 3

Pydroid 3 advertises a built-in C/C++ compiler and Cython support, but SAMARTH does not treat that marketing capability as proof of a working native build. Run `python -m samarth env` inside the actual Pydroid interpreter. NATIVE/HYBRID are supported only if the detector finds Cython, setuptools, a compiler and usable `Python.h`; the final build must also succeed on that device. Pydroid 3 was **NOT TESTED on a physical Android device** for this release.

### Android / Termux

Termux is a separate build environment. Install Python and the compiler toolchain using Termux's package manager, then run `python -m samarth env`. Do not copy native artifacts between Termux/Pydroid or between CPU architectures. Termux was **NOT TESTED on a physical Android device** for this release.

### Python versions

Internal `.sme` payloads are interpreter-version specific. Native artifacts are also platform/architecture/ABI specific. Never reuse a native binary built for another Python ABI or Android architecture.

The available build environment for this release contained CPython 3.13.5 only. Python 3.11, 3.12 and 3.14 were **NOT TESTED** here.

### Keyless/offline boundary

There is no AES/sealed mode, password, `SAMARTH_KEY`, online authentication or cloud dependency. SHA-256 is used for integrity only; it is not publisher authentication. Because execution is keyless and offline, a sufficiently privileged process owner can inspect runtime-visible state.


## Multi-version native build package and matrix support

Install the Cython build extra into the exact interpreter/environment used to build:

```bash
python -m pip install ".[cython]"
```

For Nuitka:

```bash
python -m pip install ".[nuitka]"
```

Build one current-environment artifact:

```bash
python -m samarth env
python -m samarth protect app.py --profile native --backend cython -o dist-native
python -m samarth protect app.py --profile hybrid --backend cython -o dist-hybrid
```

Build Python 3.11–3.14 on the same build host (all four interpreters must be installed or bootstrappable). The resulting names are `app_py311.sme` through `app_py314.sme`, matching the unchanged universal loader. Each output directory is one OS/environment/architecture bundle; keep Pydroid, Termux and desktop bundles separate. The native container validates environment, architecture and ABI after Python-version selection:

```bash
python -m samarth protect-multi app.py --profile hybrid --backend cython --install-build-deps -o dist-matrix
```

NATIVE uses `--profile native`. A native multi-version matrix is built for one OS/architecture at a time. The GitHub Actions workflow `.github/workflows/native-matrix.yml` builds CPython 3.11–3.14 for Linux, Windows and macOS. Android/Pydroid and Termux must be built separately on the actual target environments; desktop CI does not prove Android compatibility.

Cython extension fallback is now packaged as an importable module inside `.sme`, and the native runner imports that module instead of trying to execute a `.so` as a process. Native artifacts record and validate OS, architecture, Python version, ABI (for extensions) and Pydroid/Termux environment identity. The final `.sme` remains one package file.


## v0.7.0 portable v2 notes

- New `SAMHER02` portable container; the `SAMHER01` reader remains for old artifacts.
- Conservative custom AST VM path with local identifier renaming and a packed literal pool; unsupported syntax is marked as `portable-source-v2` and kept on the compatible source path.
- Four custom reversible byte-mixing rounds, BZ2 compression, Base85 encoding, seven shuffled fragments and SHA-256 integrity validation.
- All operations use the Python standard library and avoid CPython bytecode/native ABI coupling.
- This adds decoding friction, not cryptographic confidentiality. It does not guarantee a 60–70% semantic-recovery ceiling; runtime-controlled source can still be recovered.
- No deliberate CPU/memory exhaustion, anti-debug process termination, security-tool interference or destructive file operations are used.

The v0.6.10–v0.6.11 native audit history is retained in the source repository.


## Android/Pydroid native build behavior (optional)

For Pydroid/Termux without a confirmed native toolchain, prefer the pure-Python `portable`, `advanced`, or `maximum` internal profiles. NATIVE/HYBRID Cython artifacts remain optional and must be built and tested inside the exact Android app/interpreter. The presence of Android alone does not prove usable Python headers or extension-loading support. Physical Pydroid and Termux execution are NOT TESTED for this package build. See the included `docs/INSTALL-PYDROID.md` and `docs/INSTALL-TERMUX.md`.
