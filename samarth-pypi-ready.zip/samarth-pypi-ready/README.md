# SAMARTH ENC v0.6.10

SAMARTH ENC is a completely **keyless, offline** Python source-protection and packaging toolkit. No password, environment key, online service or mandatory authentication is used by the internal backend.

## Profiles

- `standard` — compiled CPython payload with metadata/path hardening.
- `advanced` — segmented function virtualization with conservative safety analysis.
- `maximum` — virtualizes every eligible function supported safely by the internal VM.
- `native` — genuine external Nuitka backend only.
- `hybrid` — genuine external backend workflow only.

NATIVE/HYBRID never silently fall back to the internal backend.

## Keyless offline protection

```bash
samarth protect app.py -o protected --profile standard --backend internal
samarth protect app.py -o protected --profile advanced --backend internal
samarth protect app.py -o protected --profile maximum --backend internal
```

There is deliberately no `--sealed`, password, `SAMARTH_KEY`, or encryption-key configuration in v0.6.10. The internal protection is obfuscation/virtualization plus SHA-256 integrity, not cryptographic confidentiality. An attacker who fully controls the executing Python process can eventually inspect runtime-visible program state.

## Existing workflows

```text
samarth protect INPUT -o OUTPUT --profile advanced
samarth protect INPUT -o OUTPUT --profile maximum
samarth protect INPUT -o OUTPUT --profile standard
samarth run-bundle OUTPUT --name main
samarth run OUTPUT/main.sme
samarth protect-multi INPUT -o OUTPUT --profile advanced
```

## Compatibility

The current runtime reads v0.6.2 (`SAMENC62`), v0.6.3 (`SAMENC63`), v0.6.4 (`SAMENC64`), v0.6.5 (`SAMENC65`) and v0.6.6 (`SAMENC66`) internal payloads. New artifacts use `SAMENC67` / format version 8.

The universal `samarth/loader.py` is intentionally unchanged byte-for-byte.

## Architecture changes

Advanced and Maximum move eligible function bodies into a segmented v2 VM capsule. The capsule uses numeric node tags, per-artifact symbol permutation, metadata/path hardening and generic callable shells. VM eligibility is conservative: async/generator-sensitive bodies, nested definitions, context-manager-heavy constructs, annotations and other CPython frame-sensitive cases remain native when needed for correctness. Zero-argument `super()` is tested specifically so the previous class-cell failure does not recur.

This is obfuscation rather than encryption. The v2 capsule is intentionally not presented as cryptographic secrecy.

## Testing boundaries

CPython 3.13.5/Linux is the actual execution environment used for this release test. Python 3.11/3.12/3.14, Windows, Termux and Pydroid 3 are reported as NOT TESTED when those environments are unavailable. NATIVE/HYBRID are also reported separately when their external backends are unavailable.

## Native backends and capability detection

`samarth env` prints the locally detected Python ABI, OS, architecture, compiler/linker, Python development headers and available native backends. NATIVE and HYBRID refuse unsupported environments instead of silently downgrading.

### NATIVE

- `--backend nuitka`: genuine Nuitka native executable when Nuitka is installed and succeeds.
- `--backend cython`: genuine Cython native executable when CPython development headers/libpython and a C compiler are available. If embedded-executable linking is unavailable but extension compilation is possible, the artifact is explicitly marked as a native extension rather than being mislabeled as an executable.

Example:

```bash
python -m samarth env
python -m samarth protect app.py -o dist-native --profile native --backend cython
python -m samarth run dist-native/app.sme
```

### HYBRID

HYBRID applies SAMARTH's internal symbol/literal hardening before native compilation. The selected native backend is recorded in the artifact metadata. HYBRID accepts only genuine native backends (Nuitka or Cython); PyArmor cannot be used to claim HYBRID. There is no ADVANCED/MAXIMUM fallback.

```bash
python -m samarth protect app.py -o dist-hybrid --profile hybrid --backend cython
python -m samarth run dist-hybrid/app.sme
```

### Android / Pydroid 3

Pydroid 3 advertises a built-in C/C++ compiler and Cython support, but SAMARTH does not treat that marketing capability as proof of a working native build. Run `python -m samarth env` inside the actual Pydroid interpreter. NATIVE/HYBRID are supported only if the detector finds Cython, setuptools, a compiler and usable `Python.h`; the final build must also succeed on that device. Pydroid 3 was **NOT TESTED on a physical Android device** for this release.

### Android / Termux

Termux is a separate build environment. Install Python and the compiler toolchain using Termux's package manager, then run `python -m samarth env`. Do not copy native artifacts between Termux/Pydroid or between CPU architectures. Termux was **NOT TESTED on a physical Android device** for this release.

### Python versions

Internal `.sme` payloads are interpreter-version specific. Native artifacts are also platform/architecture/ABI specific. Never reuse a native binary built for another Python ABI or Android architecture.

The available build environment for this release contained CPython 3.13.5 only. Python 3.11, 3.12 and 3.14 were **NOT TESTED** here.

### Keyless/offline boundary

There is no AES/sealed mode, password, `SAMARTH_KEY`, online authentication or cloud dependency. SHA-256 is used for integrity only; it is not publisher authentication. Because execution is keyless and offline, a sufficiently privileged process owner can inspect runtime-visible state.


## Multi-version native build package and matrix support

Install the Cython build extra into the exact interpreter/environment used to build:

```bash
python -m pip install ".[cython]"
```

For Nuitka:

```bash
python -m pip install ".[nuitka]"
```

Build one current-environment artifact:

```bash
python -m samarth env
python -m samarth protect app.py --profile native --backend cython -o dist-native
python -m samarth protect app.py --profile hybrid --backend cython -o dist-hybrid
```

Build Python 3.11–3.14 on the same build host (all four interpreters must be installed or bootstrappable). The resulting names are `app_py311.sme` through `app_py314.sme`, matching the unchanged universal loader. Each output directory is one OS/environment/architecture bundle; keep Pydroid, Termux and desktop bundles separate. The native container validates environment, architecture and ABI after Python-version selection:

```bash
python -m samarth protect-multi app.py --profile hybrid --backend cython --install-build-deps -o dist-matrix
```

NATIVE uses `--profile native`. A native multi-version matrix is built for one OS/architecture at a time. The GitHub Actions workflow `.github/workflows/native-matrix.yml` builds CPython 3.11–3.14 for Linux, Windows and macOS. Android/Pydroid and Termux must be built separately on the actual target environments; desktop CI does not prove Android compatibility.

Cython extension fallback is now packaged as an importable module inside `.sme`, and the native runner imports that module instead of trying to execute a `.so` as a process. Native artifacts record and validate OS, architecture, Python version, ABI (for extensions) and Pydroid/Termux environment identity. The final `.sme` remains one package file.


## v0.6.10 audit notes

The final audit added the `python -m samarth` entry point, fixed HYBRID future-import and `.so` fallback execution, rejects PyArmor for NATIVE/HYBRID, and aligns multi-version filenames with the unchanged universal loader. The release test scope and untested environments are documented in the release notes. Do not assume untested platforms are supported.
