# Changelog

## 0.6.10 — final audit and reliability repair

### Correctness fixes found by re-auditing v0.6.9
- Added `samarth/__main__.py`; documented `python -m samarth ...` commands now work.
- Preserved module docstrings and `__future__` imports when inserting HYBRID literal-pool runtime initialization.
- Preserved `__future__` import feature names during identifier transformation.
- Fixed HYBRID Cython extension fallback so its packaged `.sme` includes `samarth.literal_engine` runtime support.
- Flattened only module-level `if __name__ == "__main__"` guards for extension fallback, and performed that step before string pooling so the guard remains detectable.
- Restored any pre-existing `sys.modules` entry after extension execution.
- Rejected PyArmor as a NATIVE/HYBRID backend; it is not a native compiler.
- Updated native artifact metadata to use the current package version instead of stale `0.6.8` metadata.
- Changed multi-version native artifact filenames to the unchanged loader's `{stem}_py311.sme` ... `{stem}_py314.sme` convention. Keep each OS/environment/architecture build in a separate bundle; native metadata validates the target after Python-version selection.
- Made multi-version builds stage artifacts and publish the manifest only after all requested builds succeed.
- Prevented STANDARD/ADVANCED/MAXIMUM multi-version builds from silently ignoring a non-internal backend argument.
- Added setuptools to Cython build extras and multi-interpreter dependency installation.
- Tightened native backend capability detection and native metadata size/format validation.
- Repaired GitHub workflow smoke paths and changed native matrix assets to platform-specific ZIPs containing loader-compatible inner `.sme` names.

### Validation on the available host
- CPython 3.13.5 / Linux x86_64.
- Full pytest suite: 46 passed.
- `python -m compileall`: PASS.
- `python -m samarth --version` and `python -m samarth env`: PASS.
- Cython NATIVE `.sme` build and execution: PASS.
- Cython HYBRID `.sme` build and execution: PASS.
- Forced HYBRID `.so` extension fallback, including literal runtime and entry-point execution: PASS.
- NATIVE/HYBRID multi-version artifact naming and loader selection: PASS for the available interpreter using a one-version test matrix.
- Wheel build, clean-target installation and `python -m samarth --version`: PASS.
- Source distribution build: PASS.
- Universal `samarth/loader.py` SHA-256 unchanged: `6ff9d442c21194275b80acf3e66f07877030a99e6100bfeb2dc69a607bb18b4e`.

### Not tested
- Physical Pydroid 3 and Termux.
- CPython 3.11, 3.12 and 3.14.
- Windows and macOS native execution.
- Nuitka backend.
- Hosted GitHub Actions workflows.

## 0.6.9

### Native build pipeline
- Added pip extras: `cython`, `native`, `hybrid`, `nuitka`, and `all-build`.
- Added multi-version NATIVE/HYBRID builds for CPython 3.11–3.14 when all target interpreters and their native toolchains are available on the same build host.
- Added platform-tagged output names and a v3 build manifest for native/hybrid matrices.
- Added a GitHub Actions matrix workflow for Linux, Windows and macOS across Python 3.11–3.14.
- Added Android/Pydroid and Termux local-build instructions; these remain unverified until built and run on actual devices.

### Cython extension fallback repair
- Fixed `.so` fallback execution: the loader now safely extracts and imports the ABI-tagged extension from the `.sme` container instead of attempting to execute a shared library as a process.
- Native extension fallback converts the script entry guard into import-time entry execution for the packaged script.
- Added target checks for OS, architecture, Python version, extension SOABI and Pydroid/Termux identity.
- Cython extension builds use the active interpreter and setuptools build_ext for platform-specific compiler handling.

### Validation
- CPython 3.13.5/Linux: 38 regression tests pass (including extension fallback execution).
- Cython NATIVE and HYBRID `.sme` build/execute smoke tests pass on the available Linux x86_64 host.
- Wheel build succeeds with `pip wheel --no-deps --no-build-isolation`.
- Pydroid, Termux, Python 3.11/3.12/3.14, Windows and macOS remain NOT TESTED in this environment.


## 0.6.8

### Keyless/offline
- Remains completely keyless and offline.
- No AES, AES-GCM, sealed mode, SAMARTH_KEY, password or online authentication.

### Runtime reliability
- Corrected positional-only, positional-or-keyword, keyword-only, `*args` and `**kwargs` binding.
- Function defaults are evaluated at definition time for VM functions.
- VM `assert` now preserves AssertionError messages.
- Dictionary `**` unpacking is supported.
- Context managers receive real exception type/value/traceback and can suppress exceptions.
- Zero-argument `super()` supports both instance methods and classmethods.
- Unsafe/default-heavy, generator, async, closure-sensitive and global/nonlocal cases remain on tested CPython execution paths instead of being blindly virtualized.
- Added regressions for all discovered v0.6.7 runtime issues.

### Security/hardening
- New internal payload format `SAMENC68` / format version 9.
- Legacy v0.6.7 format-8 payloads remain readable.
- Added decompression, metadata, capsule and native-container size limits.
- Native PyArmor archive extraction now rejects absolute paths, traversal and oversized archives.
- Manifest validation retains SHA-256 integrity checks; SHA-256 is not treated as publisher authentication.

### Compatibility
- Universal `samarth/loader.py` remains byte-for-byte unchanged.
- Multi-version builder refuses missing/interpreter-mismatched runtimes rather than fabricating artifacts.
- NATIVE/HYBRID remain deterministic external-backend paths with no silent internal fallback.

### Benchmark
- Added reproducible v0.6.8 benchmark scripts and reports.
- The strong capsule-aware benchmark did not reach the requested 50–70% range; actual measured results are retained.

## 0.6.7


### Keyless/offline architecture
- Removed the internal cryptographic/sealed mode completely.
- Removed the `--sealed` CLI option and key/environment-key handling.
- Removed the `cryptography` optional dependency.
- Internal STANDARD/ADVANCED/MAXIMUM operation is fully offline and keyless.

### Protection architecture
- New internal payload format `SAMENC67` / format version 8.
- Added segmented v2 function capsules with numeric AST tags and per-artifact symbol permutation.
- MAXIMUM virtualizes every eligible function supported safely by the internal VM; ADVANCED uses a lower deterministic selection.
- Generic virtualized callable shells avoid exposing original argument signatures in ordinary CPython CodeType metadata.
- Preserved safe fallback for async/generator-sensitive functions, nested definitions, context managers, annotations and other frame-sensitive constructs.
- Preserved special closure handling required by zero-argument `super()`.

### Compatibility/integrity
- New artifacts use `SAMENC67`; v0.6.2 through v0.6.6 internal payloads remain readable.
- SHA-256 payload and manifest integrity verification retained.
- Universal `samarth/loader.py` remains byte-for-byte unchanged.
- NATIVE/HYBRID remain external-backend-only with no silent internal fallback.

### Testing
- New v0.6.7 regression suite covers keyless execution, zero-argument `super()`, integrity, manifests, legacy v0.6.6 payload loading and loader immutability.
- Actual compatibility results are reported per environment; unavailable Python/OS environments are not marked PASS.

## 0.6.8-final engineering upgrade

- Added evidence-based environment/capability detection for CPython, Pydroid, Termux, compilers, Python headers, Cython, Nuitka and PyArmor.
- Added a genuine Cython native backend. It produces a real native executable when an embeddable CPython development environment is available, with a genuine extension build path when executable embedding is unavailable.
- HYBRID now combines the internal identifier/literal hardening stage with a genuine native Cython/Nuitka backend; it never silently falls back to the internal VM.
- NATIVE now accepts only genuine Nuitka or Cython native backends.
- Added native-container support for Cython executable bundles and safe runtime extraction.
- Added `samarth env` capability diagnostics.
- Strengthened MAXIMUM with a conservative straight-line control-flow flattening pass while preserving the existing VM safety gates.
- Repaired stale benchmark tooling that referenced removed sealed/key APIs.
- Removed the unused key parameter from the source-packing API.
- Added native/hybrid regression tests and native artifact integrity tests.
- Universal loader remains byte-for-byte unchanged.

### Validation boundary

This release was physically tested on CPython 3.13.5/Linux x86_64. Cython 3.2.4 and GCC/Clang-compatible system tooling were available, so Cython NATIVE and HYBRID were built and executed successfully. Nuitka and PyArmor were not installed. Physical Pydroid 3, Termux, Windows, CPython 3.11, 3.12 and 3.14 environments were not available in the build environment and are therefore marked NOT TESTED, not PASS.
