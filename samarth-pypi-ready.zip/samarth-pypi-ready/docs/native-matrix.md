# SAMARTH ENC 0.6.10 — native build package

## Install from source

```bash
python -m pip install --upgrade pip setuptools wheel
python -m pip install ".[cython]"
```

This installs the Python build dependency. It does **not** install an Android compiler, Python development headers, SDK/NDK, linker, or platform toolchain. Those must be available from the target environment.

For Nuitka builds:

```bash
python -m pip install ".[nuitka]"
```

## Build for the current interpreter/environment

```bash
python -m samarth env
python -m samarth protect app.py --profile native --backend cython -o dist-native
python -m samarth protect app.py --profile hybrid --backend cython -o dist-hybrid
```

The output is a `.sme` container. It may contain a native executable or a Python-ABI-specific native extension. The metadata records the target OS, architecture, Python version and ABI. The runtime rejects mismatches.

## Build Python 3.11, 3.12, 3.13 and 3.14 on one build host

All four interpreters must be installed, or `uv` must be available to bootstrap them:

```bash
python -m samarth protect-multi app.py --profile hybrid --backend cython --install-build-deps -o dist-matrix
```

For NATIVE:

```bash
python -m samarth protect-multi app.py --profile native --backend cython --install-build-deps -o dist-matrix
```

This creates four loader-compatible `.sme` filenames (`app_py311.sme` through `app_py314.sme`) for the **same OS/environment/architecture build environment**. The unchanged loader selects by Python version; the native payload then validates OS, environment, architecture and ABI. Keep each platform's four-file matrix in a separate distribution bundle. Do not mix Pydroid, Termux, Windows, macOS or Linux variants into one flat folder because the unchanged loader intentionally selects only by Python-version filename. This command does not cross-compile platforms.

## Pydroid 3 and Termux

Build inside the exact Pydroid or Termux interpreter that will be the target:

```bash
python -m pip install --upgrade setuptools wheel
python -m pip install ".[cython]"
python -m samarth env
python -m samarth protect app.py --profile hybrid --backend cython -o dist-hybrid
```

Use `--profile native` for NATIVE. A successful pip install is not proof of compiler or ABI compatibility. The command fails if Cython, a compiler, headers, or a usable native build toolchain are missing.

Pydroid and Termux artifacts are treated as separate targets. Do not share Android `.so` artifacts between them unless ABI and runtime tests prove compatibility.

## Desktop CI matrix

`.github/workflows/native-matrix.yml` builds for CPython 3.11–3.14 on Linux, Windows and macOS. It does not claim Pydroid or Termux coverage; those must be built and tested on the actual Android environments.

## Important limits

- A `.so` is a native extension, not a standalone executable.
- Native extensions are tied to an OS, CPU architecture, Python ABI and often a specific Android runtime/toolchain.
- A single pip package cannot magically make one native binary portable across all those targets.
- The unchanged loader selects by Python-version filename. The native payload validates OS/environment, architecture and ABI after selection. Therefore, distribute separate platform-specific bundles when keeping the universal loader byte-for-byte unchanged.
- Build dependencies are needed at build time; ordinary users should only need the final `.sme` and the compatible universal loader.
