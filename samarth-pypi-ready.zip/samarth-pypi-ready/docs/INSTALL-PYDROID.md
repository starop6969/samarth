# Pydroid 3 installation / native verification

1. Install SAMARTH from the supplied wheel or source distribution in the Pydroid Python environment.
2. Run `python -m samarth env`.
3. Confirm the output reports the actual Pydroid environment, compiler, Cython and `python_headers: true`.
4. Build NATIVE with `python -m samarth protect app.py -o dist-native --profile native --backend cython`.
5. Execute with `python -m samarth run dist-native/app.sme`.
6. Repeat for HYBRID.

If the detector reports missing development headers/compiler/Cython, the build must fail rather than silently downgrade.

This release was not physically tested on Pydroid, so these are verification instructions rather than a PASS claim.
