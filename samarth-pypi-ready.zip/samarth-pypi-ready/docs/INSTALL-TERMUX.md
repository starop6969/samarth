# Termux installation / native verification

1. Install Python and a compiler/toolchain using the Termux package manager.
2. Install SAMARTH into that Python.
3. Run `python -m samarth env`.
4. Confirm the detected Python version, architecture, compiler and development headers match the intended target.
5. Build NATIVE with `python -m samarth protect app.py -o dist-native --profile native --backend cython`.
6. Execute with `python -m samarth run dist-native/app.sme`.
7. Repeat for HYBRID.

Do not reuse native artifacts across different Python ABIs or Android architectures.

This release was not physically tested on Termux, so these are verification instructions rather than a PASS claim.
