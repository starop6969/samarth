from __future__ import annotations

import hashlib
import secrets
import sys
from pathlib import Path

from .bytecode_engine import (
    MAGIC as SOURCE_MAGIC, LEGACY_MAGIC, LEGACY_MAGIC_V66, LEGACY_MAGIC_V64,
    LEGACY_MAGIC_V63, LEGACY_MAGIC_V62, LEGACY_MAGIC_V67, unpack_code, extract_vm_blob,
)
from .native_container import MAGIC as NATIVE_MAGIC, run_native
from .vm_engine import unpack_function_capsule, unpack_function_capsule_v2, unpack_module_capsule_v2, install_function_capsule, VMRuntime


def verify_payload(payload: bytes) -> None:
    if payload.startswith((SOURCE_MAGIC, LEGACY_MAGIC, LEGACY_MAGIC_V66, LEGACY_MAGIC_V64, LEGACY_MAGIC_V63, LEGACY_MAGIC_V62)):
        body, digest = payload[:-32], payload[-32:]
        if not secrets.compare_digest(hashlib.sha256(body).digest(), digest):
            raise ValueError("SAMARTH integrity check failed")
        unpack_code(payload)
        return
    if payload.startswith(NATIVE_MAGIC):
        from .native_container import unpack_native
        body, digest = payload[:-32], payload[-32:]
        if not secrets.compare_digest(hashlib.sha256(body).digest(), digest):
            raise ValueError("SAMARTH integrity check failed")
        unpack_native(payload)
        return
    raise ValueError("Invalid SAMARTH payload")


def execute_payload(payload: bytes, globals_dict=None, filename="<samarth>"):
    verify_payload(payload)
    if payload.startswith(NATIVE_MAGIC):
        return run_native(payload)
    code, meta = unpack_code(payload)
    if meta.get("format") not in {
        "samarth-code-v3","samarth-code-v4","samarth-code-v5","samarth-code-v6",
        "samarth-code-v6-standard","samarth-code-v7","samarth-code-v7-standard",
        "samarth-code-v8","samarth-code-v8-standard","samarth-code-v9","samarth-code-v9-standard",
    }:
        raise ValueError("Unsupported SAMARTH payload metadata format")
    current=[sys.version_info.major,sys.version_info.minor]
    compiled=meta.get("compiled_by") or meta.get("python")
    if isinstance(compiled,str): compiled=[int(x) for x in compiled.split(".")[:2]]
    if compiled and current != list(compiled[:2]):
        raise RuntimeError(f"Payload was compiled for CPython {compiled[0]}.{compiled[1]}; current is {current[0]}.{current[1]}")
    ns=globals_dict if globals_dict is not None else {"__name__":"__main__","__file__":filename}
    ns.setdefault("__file__",filename)
    model=meta.get("execution_model")
    if model == "module-vm-v2":
        blob=extract_vm_blob(code)
        if blob is None: raise ValueError("SAMARTH module VM payload capsule is missing")
        tree=unpack_module_capsule_v2(blob)
        VMRuntime(tree,ns).run()
    elif model in {"function-vm-v1","function-vm-v2"}:
        blob=extract_vm_blob(code)
        if blob is None: raise ValueError("SAMARTH function VM payload capsule is missing")
        capsule = unpack_function_capsule_v2(blob) if meta.get("format") in {"samarth-code-v8","samarth-code-v9"} else unpack_function_capsule(blob)
        dispatch, dispatch_async, dispatch_gen=install_function_capsule(capsule,ns)
        ns["_samarth_vm_dispatch"]=dispatch
        ns["_samarth_vm_dispatch_async"]=dispatch_async
        ns["_samarth_vm_dispatch_gen"]=dispatch_gen
        exec(code,ns,ns)
    else:
        exec(code,ns,ns)
    return meta


def verify_manifest(bundle: Path, manifest: dict) -> None:
    if not isinstance(manifest, dict) or manifest.get("format") not in {
        "samarth-bundle-v2", "samarth-multiversion-v2", "samarth-multiversion-v3"
    }:
        raise ValueError("Unsupported SAMARTH manifest format")
    hashes = manifest.get("sha256", {})
    sizes = manifest.get("sizes", {})
    if not isinstance(hashes, dict) or not isinstance(sizes, dict):
        raise ValueError("Invalid SAMARTH manifest integrity section")
    root = bundle.resolve()
    for name, expected in hashes.items():
        if (not isinstance(name, str) or not name or "\\" in name
                or Path(name).is_absolute() or any(part in {"", ".", ".."} for part in Path(name).parts)):
            raise ValueError("Unsafe payload path in SAMARTH manifest")
        if not isinstance(expected, str) or len(expected) != 64:
            raise ValueError(f"Invalid manifest SHA-256 value: {name}")
        path = (root / name).resolve()
        try:
            path.relative_to(root)
        except ValueError as exc:
            raise ValueError("Manifest payload path escapes bundle directory") from exc
        if not path.is_file():
            raise ValueError(f"Manifest payload missing: {name}")
        data = path.read_bytes()
        actual = hashlib.sha256(data).hexdigest()
        if actual != expected:
            raise ValueError(f"Manifest integrity check failed: {name}")
        if name in sizes:
            try:
                expected_size = int(sizes[name])
            except (TypeError, ValueError) as exc:
                raise ValueError(f"Invalid manifest size value: {name}") from exc
            if expected_size < 0 or expected_size != len(data):
                raise ValueError(f"Manifest size check failed: {name}")
