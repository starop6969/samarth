from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .backends import BackendError, available, protect_external, strongest_available
from .loader import run_bundle, run_single
from .multiversion import TARGETS, protect_multi
from .project import PROFILES, protect_project


def main(argv=None):
    p=argparse.ArgumentParser(prog="samarth",description="SAMARTH ENC Python source protection toolkit")
    p.add_argument("--version",action="version",version=f"%(prog)s {__version__}")
    sub=p.add_subparsers(dest="cmd")
    pr=sub.add_parser("protect",help="protect a Python file or project")
    pr.add_argument("input"); pr.add_argument("-o","--output",default="samarth_dist")
    pr.add_argument("--profile",choices=sorted(PROFILES),default="advanced")
    pr.add_argument("--backend",choices=["internal","pyarmor","nuitka","cython","hybrid"],default="internal")
    mv=sub.add_parser("protect-multi",help="create CPython 3.11-3.14 payloads")
    mv.add_argument("input"); mv.add_argument("-o","--output",default="samarth_multi")
    mv.add_argument("--profile",choices=sorted(PROFILES),default="advanced")
    for ver in TARGETS: mv.add_argument(f"--python{ver.replace('.','')}",help=f"CPython {ver} executable/command")
    mv.add_argument("--backend",choices=["internal","cython","nuitka","pyarmor"],default="internal")
    mv.add_argument("--install-build-deps",action="store_true",help="install Cython/Nuitka into each selected target interpreter before building")
    mv.add_argument("--no-bootstrap",action="store_true")
    rb=sub.add_parser("run-bundle",help="run the payload matching the current Python version")
    rb.add_argument("bundle"); rb.add_argument("--name")
    rs=sub.add_parser("run",help="run one .sme payload")
    rs.add_argument("payload")
    envp=sub.add_parser("env",help="show detected build/runtime capabilities")
    ins=sub.add_parser("inspect",help="inspect Python source syntax/imports")
    ins.add_argument("input")
    ns=p.parse_args(argv)
    if ns.cmd=="env":
        from .environment import detect_environment, native_capability, hybrid_capability
        print(json.dumps({"environment": detect_environment().as_dict(), "native": native_capability(), "hybrid": hybrid_capability()}, indent=2))
        return 0
    if ns.cmd=="inspect":
        path=Path(ns.input)
        try:
            import ast
            tree=ast.parse(path.read_text(encoding="utf-8"))
            imports=sorted({a.name.split(".")[0] for a in ast.walk(tree) if isinstance(a,ast.Import)} | {a.module.split(".")[0] for a in ast.walk(tree) if isinstance(a,ast.ImportFrom) and a.module})
            print(json.dumps({"file":path.name,"syntax":"valid","imports":imports},indent=2)); return 0
        except Exception as e: print(f"samarth: inspect failed: {e}",file=sys.stderr); return 2
    if ns.cmd=="protect":
        src=Path(ns.input); out=Path(ns.output)
        if not src.exists(): print(f"samarth: input not found: {src}",file=sys.stderr); return 2
        try:
            if ns.profile in {"native","hybrid"}:
                if src.is_dir():
                    raise BackendError("NATIVE/HYBRID currently require a single Python entry file.")
                chosen = ("nuitka" if ns.backend == "nuitka" else "cython") if ns.profile == "native" else ("hybrid" if ns.backend == "hybrid" else ns.backend)
                if ns.backend == "internal":
                    raise BackendError(f"Profile {ns.profile.upper()} requires an external backend; internal source packing is not a silent fallback.")
                if ns.profile == "native" and ns.backend not in {"nuitka", "cython"}:
                    raise BackendError("NATIVE requires --backend nuitka or --backend cython.")
                meta = protect_external(src, out / (src.stem + ".sme"), ns.profile, chosen)
                print(f"SAMARTH ENC {__version__}: {ns.profile.upper()} backend={meta['backend']} -> {out / (src.stem + '.sme')}")
            elif ns.backend=="internal":
                m=protect_project(src,out,ns.profile)
                print(f"SAMARTH ENC {__version__}: protected {len(m['files'])} file(s) -> {out}")
            else:
                if ns.profile in {"standard","advanced","maximum"} and ns.backend in {"nuitka","pyarmor","cython"}:
                    meta=protect_external(src,out / (src.stem + ".sme"),ns.profile,ns.backend); print(f"SAMARTH ENC {__version__}: backend {meta['backend']} completed -> {out / (src.stem + ".sme")}")
                else: raise BackendError("Selected profile/backend combination is unsupported.")
            return 0
        except Exception as e: print(f"samarth: protection failed: {e}",file=sys.stderr); return 1
    if ns.cmd=="protect-multi":
        src=Path(ns.input); out=Path(ns.output)
        if not src.exists(): print(f"samarth: input not found: {src}",file=sys.stderr); return 2
        interpreters={ver:getattr(ns,f"python{ver.replace('.','')}") for ver in TARGETS}; interpreters={k:v for k,v in interpreters.items() if v}
        try:
            m=protect_multi(src,out,ns.profile,interpreters,bootstrap=not ns.no_bootstrap,backend=ns.backend,install_build_deps=ns.install_build_deps)
            print(f"SAMARTH ENC {__version__}: created {len(m['files'])} version-specific payloads -> {out}")
            for f in m["files"]: print(f"  {f}")
            return 0
        except Exception as e: print(f"samarth: multi-version protection failed: {e}",file=sys.stderr); return 1
    if ns.cmd=="run-bundle":
        try:
            if ns.name and (Path(ns.name).name != ns.name or "/" in ns.name or "\\" in ns.name or ns.name in {".", ".."}):
                raise ValueError("--name must be a simple source filename stem")
            result=run_bundle(Path(ns.bundle),ns.name); print(f"SAMARTH loader: {result['payload']}"); return 0
        except Exception as e: print(f"samarth: loader failed: {e}",file=sys.stderr); return 1
    if ns.cmd=="run":
        try: result=run_single(Path(ns.payload)); print(f"SAMARTH loader: {result['payload']}"); return 0
        except Exception as e: print(f"samarth: loader failed: {e}",file=sys.stderr); return 1
    p.print_help(); return 0

if __name__=="__main__": raise SystemExit(main())
