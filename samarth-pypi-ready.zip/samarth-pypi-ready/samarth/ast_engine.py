from __future__ import annotations

import ast
import builtins
import keyword
import random
import string
import secrets
from dataclasses import dataclass, field


@dataclass
class ASTConfig:
    rename_identifiers: bool = True
    transform_strings: bool = True
    optimize: int = 0
    seed: int | None = None
    rename_import_bindings: bool = False


@dataclass
class TransformReport:
    renamed: int = 0
    strings_transformed: int = 0
    constants_transformed: int = 0
    skipped: list[str] = field(default_factory=list)


class _Transformer(ast.NodeTransformer):
    """Conservative lexical-scope renamer.

    v0.5 used one global map, which caused shadowing/closure collisions and
    keyword-call failures. v0.6 renames only function-local bindings and
    resolves references through the active lexical scope stack. Module APIs,
    imports, class bodies, attributes, keyword names and special names remain
    stable for compatibility.
    """

    def __init__(self, cfg: ASTConfig, report: TransformReport):
        self.cfg = cfg
        self.report = report
        self.rng = random.Random(cfg.seed)
        self.reserved = set(keyword.kwlist) | set(dir(builtins))
        self.reserved |= {
            "self", "cls", "__name__", "__file__", "__package__", "__spec__",
            "__loader__", "__builtins__", "__annotations__", "_samarth_literal_runtime",
        }
        self.scopes: list[dict[str, str]] = [{}]
        self.scope_kind: list[str] = ["module"]
        self.in_class = 0
        self.literal_salt = secrets.token_bytes(16)
        self._skip_literal_depth = 0
        self.literal_runtime_name = "_samarth_literal_runtime"
        self.literal_pool: dict[object, int] = {}
        self.public_names: set[str] = set()

    def _eligible(self, name: str) -> bool:
        return (
            self.cfg.rename_identifiers and name.isidentifier()
            and not name.startswith("__") and name not in self.reserved
        )

    def _new_name(self, old: str, scope: dict[str, str]) -> str:
        if old in scope:
            return scope[old]
        used = set().union(*(set(s.values()) for s in self.scopes))
        while True:
            n = "_s_" + "".join(self.rng.choice(string.ascii_letters) for _ in range(10))
            if n not in self.reserved and n not in used:
                scope[old] = n
                self.report.renamed += 1
                return n

    def _resolve(self, name: str) -> str | None:
        for scope, kind in zip(reversed(self.scopes), reversed(self.scope_kind)):
            if name in scope:
                return scope[name]
            if kind == "class":
                # Class bodies are deliberately not renamed.
                continue
        return None

    def _collect_function_bindings(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> set[str]:
        bindings: set[str] = set()
        class Binder(ast.NodeVisitor):
            def visit_Name(self, n):
                if isinstance(n.ctx, (ast.Store, ast.Del)):
                    bindings.add(n.id)
            def visit_Import(self, n):
                for a in n.names:
                    bindings.add(a.asname or a.name.split(".")[0])
            def visit_ImportFrom(self, n):
                for a in n.names:
                    if a.name != "*": bindings.add(a.asname or a.name)
            def visit_FunctionDef(self, n):
                bindings.add(n.name)
            def visit_AsyncFunctionDef(self, n):
                bindings.add(n.name)
            def visit_ClassDef(self, n):
                bindings.add(n.name)
            def visit_Lambda(self, n):
                return
        Binder().visit(ast.Module(body=node.body, type_ignores=[]))
        return {n for n in bindings if self._eligible(n)}

    def _rename_args(self, node, scope):
        # Parameter names are part of a callable API and may be referenced by
        # keyword calls, decorators, introspection, or external callers. Keep
        # them stable; local variables are still renamed lexically.
        return

    def _rename_import_binding(self, original: str, alias_node, scope: dict[str, str]):
        if not self.cfg.rename_import_bindings or not self._eligible(original):
            return None
        return self._new_name(original, scope)

    def visit_Import(self, node):
        # Keep the imported module name in the import statement, but hide the
        # local binding used by the protected implementation. This preserves
        # import semantics while reducing recoverable local identifiers.
        scope = self.scopes[-1]
        for a in node.names:
            bound = a.asname or a.name.split(".")[0]
            if self.scope_kind[-1] == "module" and self._eligible(bound) and bound not in self.public_names:
                new = self._rename_import_binding(bound, a, scope)
                if new:
                    a.asname = new
            elif self.scope_kind[-1] == "function" and self._eligible(bound):
                mapped = self._resolve(bound)
                if mapped:
                    a.asname = mapped
        return node

    def visit_ImportFrom(self, node):
        # __future__ imports are compiler directives: preserve their position
        # and imported feature names exactly.
        if node.module == "__future__":
            return node
        scope = self.scopes[-1]
        for a in node.names:
            if a.name == "*":
                continue
            bound = a.asname or a.name
            if self._eligible(bound):
                if self.scope_kind[-1] == "module" and bound not in self.public_names:
                    new = self._rename_import_binding(bound, a, scope)
                    if new:
                        a.asname = new
                else:
                    mapped = self._resolve(bound)
                    if mapped:
                        a.asname = mapped
        return node

    def visit_Module(self, node):
        # Pre-scan module exports/imports so functions defined before an import
        # still resolve the renamed module binding correctly.
        for stmt in node.body:
            if isinstance(stmt, ast.Assign):
                for target in stmt.targets:
                    if isinstance(target, ast.Name) and target.id == "__all__" and isinstance(stmt.value, (ast.List, ast.Tuple)):
                        self.public_names.update(
                            elt.value for elt in stmt.value.elts
                            if isinstance(elt, ast.Constant) and isinstance(elt.value, str)
                        )
        if self.cfg.rename_import_bindings and self.scope_kind[-1] == "module":
            scope = self.scopes[-1]
            for stmt in node.body:
                if isinstance(stmt, ast.Import):
                    for a in stmt.names:
                        bound = a.asname or a.name.split(".")[0]
                        if self._eligible(bound) and bound not in self.public_names:
                            self._rename_import_binding(bound, a, scope)
                elif isinstance(stmt, ast.ImportFrom):
                    for a in stmt.names:
                        if a.name == "*":
                            continue
                        bound = a.asname or a.name
                        if self._eligible(bound) and bound not in self.public_names:
                            self._rename_import_binding(bound, a, scope)
        return self._visit_docstring_safe(node)

    def visit_ClassDef(self, node):
        self.in_class += 1
        self.scopes.append({})
        self.scope_kind.append("class")
        node.body = [self.visit(x) for x in node.body]
        self.scope_kind.pop(); self.scopes.pop()
        self.in_class -= 1
        return node

    def _visit_function(self, node):
        # A nested function name is a binding in the enclosing function scope.
        # Module-level and class-level API names remain stable.
        if self.scope_kind[-1] == "function" and not self.in_class and self._eligible(node.name):
            node.name = self._new_name(node.name, self.scopes[-1])
        # Defaults/decorators/annotations execute in the enclosing scope.
        node.decorator_list = [self.visit(x) for x in node.decorator_list]
        node.args.defaults = [self.visit(x) for x in node.args.defaults]
        node.args.kw_defaults = [self.visit(x) if x else None for x in node.args.kw_defaults]
        node.returns = self.visit(node.returns) if node.returns else None
        if node.type_comment:
            pass

        local: dict[str, str] = {}
        if self.in_class:
            # Method signatures remain untouched; local implementation bindings
            # are still renamed. Attributes and public method names remain stable.
            for name in self._collect_function_bindings(node):
                if name not in {a.arg for a in node.args.posonlyargs + node.args.args + node.args.kwonlyargs}:
                    self._new_name(name, local)
            self.scopes.append(local); self.scope_kind.append("function")
            node = self._visit_docstring_safe(node)
            self.scope_kind.pop(); self.scopes.pop()
            return node

        for name in self._collect_function_bindings(node):
            if name not in {a.arg for a in node.args.kwonlyargs}:
                self._new_name(name, local)
        self._rename_args(node, local)
        self.scopes.append(local); self.scope_kind.append("function")
        node = self._visit_docstring_safe(node)
        self.scope_kind.pop(); self.scopes.pop()
        return node

    visit_FunctionDef = _visit_function
    visit_AsyncFunctionDef = _visit_function

    def visit_Lambda(self, node):
        # Lambdas are treated conservatively: rename positional parameters and
        # their body using a dedicated local scope.
        local: dict[str, str] = {}
        for a in (*node.args.posonlyargs, *node.args.args):
            if self._eligible(a.arg): a.arg = self._new_name(a.arg, local)
        self.scopes.append(local); self.scope_kind.append("function")
        node.body = self.visit(node.body)
        self.scope_kind.pop(); self.scopes.pop()
        return node

    def visit_Name(self, node):
        if not self._eligible(node.id):
            return node
        mapped = self._resolve(node.id)
        if mapped:
            node.id = mapped
        return node

    def visit_Attribute(self, node):
        # Attribute names are API surface and must not be renamed.
        node.value = self.visit(node.value)
        return node

    def _literal_call(self, value):
        idx = self.literal_pool.setdefault(value, len(self.literal_pool))
        expr = ast.Subscript(
            value=ast.Name(id="_samarth_literal_pool", ctx=ast.Load()),
            slice=ast.Constant(value=idx),
            ctx=ast.Load(),
        )
        return ast.copy_location(expr, ast.Constant(value=value))

    def visit_Constant(self, node):
        if self._skip_literal_depth:
            return node
        if self.cfg.transform_strings and isinstance(node.value, (str, bytes, int, float, complex)) and not isinstance(node.value, bool):
            self.report.constants_transformed += 1
            if isinstance(node.value, (str, bytes, bytearray)):
                self.report.strings_transformed += 1
            return self._literal_call(node.value)
        return node

    def visit_JoinedStr(self, node):
        # f-string syntax cannot contain arbitrary Call nodes in its literal
        # segments. Preserve literal segments for correctness, but still apply
        # identifier transformation to formatted expressions/specifiers.
        for value in node.values:
            if isinstance(value, ast.FormattedValue):
                value.value = self.visit(value.value)
                if value.format_spec:
                    value.format_spec = self.visit(value.format_spec)
        return node

    def _visit_docstring_safe(self, node):
        # Python only treats a literal Constant as a docstring. Replacing it
        # with a call would silently change __doc__, so it is deliberately
        # excluded from literal packing.
        body = list(node.body)
        if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str):
            first, rest = body[0], body[1:]
            self._skip_literal_depth += 1
            first = self.visit(first)
            self._skip_literal_depth -= 1
            node.body = [first] + [self.visit(x) for x in rest]
            return node
        node.body = [self.visit(x) for x in body]
        return node


def transform(source: str, cfg: ASTConfig | None = None) -> tuple[str, TransformReport]:
    cfg = cfg or ASTConfig()
    tree = ast.parse(source)
    report = TransformReport()
    transformer = _Transformer(cfg, report)
    tree = transformer.visit(tree)
    if cfg.transform_strings and report.constants_transformed:
        from .literal_engine import pack_pool
        runtime_import = ast.parse(
            "import samarth.literal_engine as _samarth_literal_runtime"
        ).body[0]
        payload = pack_pool(tuple(transformer.literal_pool.keys()), transformer.literal_salt)
        pool_expr = ast.parse(
            "_samarth_literal_runtime.unpack_pool(__PAYLOAD__, __SALT__)"
        ).body[0].value
        pool_expr.args[0] = ast.Constant(value=payload)
        pool_expr.args[1] = ast.Constant(value=transformer.literal_salt)
        pool_assign = ast.Assign(
            targets=[ast.Name(id="_samarth_literal_pool", ctx=ast.Store())],
            value=pool_expr,
        )
        # Module docstrings and __future__ imports must remain at the beginning
        # of a module. Insert the runtime support immediately after them.
        insert_at = 0
        if (tree.body and isinstance(tree.body[0], ast.Expr)
                and isinstance(tree.body[0].value, ast.Constant)
                and isinstance(tree.body[0].value.value, str)):
            insert_at = 1
        while (insert_at < len(tree.body)
               and isinstance(tree.body[insert_at], ast.ImportFrom)
               and tree.body[insert_at].module == "__future__"):
            insert_at += 1
        tree.body[insert_at:insert_at] = [runtime_import, pool_assign]
    ast.fix_missing_locations(tree)
    return ast.unparse(tree), report


class _FlattenSimple(ast.NodeTransformer):
    """Flatten simple statement sequences into a dispatcher loop.

    This is intentionally conservative: only basic straight-line function
    bodies are transformed. Loops, try/except, with, generators, async code,
    comprehensions and nested definitions are left untouched because preserving
    Python semantics is more important than aggressive obfuscation.
    """
    def visit_FunctionDef(self, node):
        self.generic_visit(node)
        if len(node.body) < 3: return node
        if any(isinstance(x,(ast.For,ast.While,ast.Try,ast.With,ast.AsyncWith,ast.Match,ast.Return,ast.Yield,ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) for x in node.body[:-1]):
            return node
        if not isinstance(node.body[-1],ast.Return): return node
        # A tiny state machine using a private integer state. It preserves
        # expression order while making the high-level sequence less obvious
        # in disassembly. The body is executed once through the states.
        state=ast.Name(id="_samarth_state",ctx=ast.Store())
        init=ast.Assign(targets=[state],value=ast.Constant(0))
        cases=[]
        for i,stmt in enumerate(node.body):
            nxt=ast.Assign(targets=[ast.Name(id="_samarth_state",ctx=ast.Store())],value=ast.Constant(i+1))
            body=[stmt]
            if i < len(node.body)-1:
                body.append(nxt)
            cases.append(ast.If(test=ast.Compare(left=ast.Name(id="_samarth_state",ctx=ast.Load()),ops=[ast.Eq()],comparators=[ast.Constant(i)]),body=body,orelse=[]))
        loop=ast.While(test=ast.Compare(left=ast.Name(id="_samarth_state",ctx=ast.Load()),ops=[ast.Lt()],comparators=[ast.Constant(len(node.body))]),body=cases,orelse=[])
        node.body=[init,loop]
        return node

class _LiteralSplit(ast.NodeTransformer):
    """Split ordinary literals in native code while preserving docstrings."""
    def __init__(self):
        self._docstrings=set()
    def mark(self, tree):
        for n in ast.walk(tree):
            if isinstance(n,(ast.Module,ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.body:
                first=n.body[0]
                if isinstance(first,ast.Expr) and isinstance(first.value,ast.Constant) and isinstance(first.value.value,str):
                    self._docstrings.add(id(first.value))
    def visit_Constant(self,node):
        if id(node) in self._docstrings: return node
        if isinstance(node.value,str) and node.value and len(node.value)>=4:
            v=node.value; cut=max(1,len(v)//3); parts=[v[i:i+cut] for i in range(0,len(v),cut)]
            call=ast.Call(func=ast.Attribute(value=ast.Constant(value=""),attr="join",ctx=ast.Load()),args=[ast.List(elts=[ast.Constant(value=x) for x in parts],ctx=ast.Load())],keywords=[])
            return ast.copy_location(call,node)
        if isinstance(node.value,bytes) and len(node.value)>=4:
            v=node.value; cut=max(1,len(v)//3); parts=[v[i:i+cut] for i in range(0,len(v),cut)]
            call=ast.Call(func=ast.Attribute(value=ast.Constant(value=b""),attr="join",ctx=ast.Load()),args=[ast.List(elts=[ast.Constant(value=x) for x in parts],ctx=ast.Load())],keywords=[])
            return ast.copy_location(call,node)
        return node

def split_native_literals(tree):
    t=_LiteralSplit(); t.mark(tree); tree=t.visit(tree); ast.fix_missing_locations(tree); return tree
