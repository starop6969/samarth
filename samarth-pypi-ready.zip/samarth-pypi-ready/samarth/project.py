from __future__ import annotations

import ast
import hashlib
import json
import sys
from pathlib import Path

from .ast_engine import ASTConfig, TransformReport, transform, split_native_literals, _FlattenSimple
from .vm_engine import pack_function_capsule_v2, virtualize_functions_v2, pack_module_capsule_v2
from .backends import BackendError
from .bytecode_engine import pack_code, pack_function_vm_code, payload_sha256

PROFILES = {
    "standard": dict(rename_identifiers=False, transform_strings=False, optimize=0, rename_import_bindings=False),
    "advanced": dict(rename_identifiers=True, transform_strings=True, optimize=0, rename_import_bindings=True),
    "maximum": dict(rename_identifiers=True, transform_strings=True, optimize=0, rename_import_bindings=True),
    "native": dict(rename_identifiers=True, transform_strings=True, optimize=0, rename_import_bindings=True),
    "hybrid": dict(rename_identifiers=True, transform_strings=True, optimize=0, rename_import_bindings=True),
}


def detect_imports(source: str) -> list[str]:
    tree = ast.parse(source)
    return sorted({n.names[0].name.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.Import)} |
                  {n.module.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) and n.module})


def _logical_name(src: Path) -> str:
    return src.name


def protect_file(src: Path, out: Path, profile="advanced", *, source_root: Path | None = None):
    profile = profile.lower()
    if profile not in PROFILES:
        raise ValueError(f"Unknown profile: {profile}")
    if profile in {"native", "hybrid"}:
        raise BackendError(f"Profile {profile.upper()} requires a genuine external backend; use the CLI backend selection.")

    cfg = ASTConfig(**PROFILES[profile])
    source = src.read_text(encoding="utf-8")
    logical = src.relative_to(source_root).as_posix() if source_root else _logical_name(src)

    if profile == "standard":
        transformed, report = transform(source, cfg)
        code = compile(transformed, "<samarth>", "exec", optimize=cfg.optimize)
        metadata = {
            "format": "samarth-code-v9-standard",
            "compiled_by": [sys.version_info.major, sys.version_info.minor, sys.version_info.micro],
            "execution_model": "cpython-code",
            "protection": "metadata-hardened-bytecode",
        }
        payload = pack_code(code, metadata)
    else:
        # Use the AST transformer only for safe lexical hardening. The actual
        # implementation bodies are moved into the v2 function VM capsule.
        vm_cfg = ASTConfig(rename_identifiers=False, transform_strings=False,
                           optimize=cfg.optimize, rename_import_bindings=False)
        transformed, report = transform(source, vm_cfg)
        tree = ast.parse(transformed)
        if profile == "maximum":
            tree = _FlattenSimple().visit(tree)
            ast.fix_missing_locations(tree)
        tree = split_native_literals(tree)
        if _module_vm_safe(tree):
            vm_blob = pack_module_capsule_v2(tree)
            bootstrap = compile("__samarth_module_vm_marker = None", "<samarth>", "exec")
            from .bytecode_engine import MODULE_VM_MARKER
            marker=(MODULE_VM_MARKER,bytes(vm_blob))
            bootstrap=bootstrap.replace(co_consts=tuple(marker if x is None else x for x in bootstrap.co_consts))
            metadata = {
                "format": "samarth-code-v9",
                "compiled_by": [sys.version_info.major, sys.version_info.minor, sys.version_info.micro],
                "execution_model": "module-vm-v2",
                "protection": "segmented-module-vm",
                "profile": profile,
                "logical_name": logical,
            }
            payload = pack_code(bootstrap, metadata)
        else:
            tree, vm_count, total_funcs, selected_ids = virtualize_functions_v2(tree, profile)
            original_tree = ast.parse(source)
            original_funcs = [n for n in ast.walk(original_tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
            selected = [(fid, original_funcs[fid]) for fid in selected_ids]
            vm_blob = pack_function_capsule_v2(selected, profile=profile)
            code = compile(tree, "<samarth>", "exec", optimize=cfg.optimize)
            metadata = {
                "format": "samarth-code-v9",
                "compiled_by": [sys.version_info.major, sys.version_info.minor, sys.version_info.micro],
                "execution_model": "function-vm-v2",
                "protection": "segmented-function-vm",
                "profile": profile,
                "vm_virtualized_functions": vm_count,
                "vm_total_functions": total_funcs,
                "logical_name": logical,
            }
            payload = pack_function_vm_code(code, vm_blob, metadata)

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(payload)
    return report, payload


def _module_vm_safe(tree: ast.AST) -> bool:
    # The existing VM has explicit implementations for the feature set below.
    # Unsupported syntax is left on the CPython path instead of risking a bad artifact.
    unsupported=(ast.Match, ast.AsyncWith)
    if any(isinstance(n,unsupported) for n in ast.walk(tree)): return False
    return True


def _manifest_hashes(out: Path, files: list[str]) -> dict[str, str]:
    return {name: payload_sha256((out / name).read_bytes()) for name in files}


def protect_project(src: Path, out: Path, profile="advanced"):
    profile = profile.lower()
    if profile not in PROFILES:
        raise ValueError(f"Unknown profile: {profile}")
    if profile in {"native", "hybrid"}:
        raise BackendError(f"Profile {profile.upper()} is backend-only. Use 'samarth protect' with the corresponding backend.")
    out.mkdir(parents=True, exist_ok=True)
    reports = {}
    entries: list[str] = []
    if src.is_file():
        target = out / (src.stem + ".sme")
        report, _ = protect_file(src, target, profile)
        entries.append(target.name)
        reports[target.name] = report.__dict__
    else:
        pyfiles = sorted(src.rglob("*.py"))
        if not pyfiles:
            raise ValueError("Project contains no Python files.")
        for p in pyfiles:
            rel = p.relative_to(src).with_suffix(".sme")
            target = out / rel
            report, _ = protect_file(p, target, profile, source_root=src)
            entries.append(rel.as_posix())
            reports[rel.as_posix()] = report.__dict__

    manifest = {
        "format": "samarth-bundle-v2",
        "profile": profile,
        "source": src.name,
        "python_versions": [f"{sys.version_info.major}.{sys.version_info.minor}"],
        "files": entries,
        "sha256": _manifest_hashes(out, entries),
        "transform_reports": reports,
        "runtime_architecture": "version-specific-compiled-code-runtime",
        "protection_features": ["segmented-function-vm", "numeric-capsule-tags", "filename-normalization", "sha256-integrity"],
        "payload_format": "SAMENC68",
        "confidentiality": "none",
        "offline": True,
        "key_required": False,
    }
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    return manifest
