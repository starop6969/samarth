__version__ = "0.6.10"
"""SAMARTH ENC: keyless offline Python source protection toolkit."""
