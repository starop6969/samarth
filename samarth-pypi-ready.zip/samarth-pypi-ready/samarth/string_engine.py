from __future__ import annotations
import base64, hashlib, secrets

def encode_constant(value: str, key: bytes | None = None) -> tuple[str, str]:
    key = key or secrets.token_bytes(16)
    raw = value.encode()
    out = bytes(b ^ key[i % len(key)] for i,b in enumerate(raw))
    return base64.b85encode(out).decode(), key.hex()

def decode_constant(payload: str, key_hex: str) -> str:
    key = bytes.fromhex(key_hex)
    raw = base64.b85decode(payload.encode())
    return bytes(b ^ key[i % len(key)] for i,b in enumerate(raw)).decode()

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
