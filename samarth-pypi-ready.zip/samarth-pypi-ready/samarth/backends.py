from __future__ import annotations

import importlib.util
import os
import platform
import shutil
import subprocess
import sys
import sysconfig
import tempfile
import zipfile
from pathlib import Path

from .ast_engine import ASTConfig, transform
from . import __version__
from .environment import detect_environment, hybrid_capability, native_capability
from .native_container import pack_native


class BackendError(RuntimeError):
    pass


def available(name: str) -> bool:
    name = name.lower()
    if name == "pyarmor":
        return importlib.util.find_spec("pyarmor") is not None or shutil.which("pyarmor") is not None
    if name == "nuitka":
        env = detect_environment()
        return bool(env.nuitka and env.compiler)
    if name == "cython":
        env = detect_environment()
        return bool(env.cython and env.compiler and env.python_headers
                    and importlib.util.find_spec("setuptools") is not None)
    if name == "internal":
        return True
    if name == "hybrid":
        return hybrid_capability()[0]
    return False


def strongest_available() -> str:
    """Select only a genuine native compiler backend (never PyArmor)."""
    if available("nuitka"):
        return "nuitka"
    if available("cython"):
        return "cython"
    raise BackendError("No genuine native backend is available; install Nuitka or Cython, setuptools, a working compiler and Python development headers.")


def _run_nuitka(source: Path, work: Path, executable_name: str) -> Path:
    out = work / "nuitka-out"
    out.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable, "-m", "nuitka", "--onefile", "--remove-output",
        f"--output-dir={out}", f"--output-filename={executable_name}", str(source)
    ]
    p = subprocess.run(cmd, text=True, capture_output=True)
    if p.returncode:
        raise BackendError((p.stderr or p.stdout).strip() or "Nuitka compilation failed")
    candidate = out / (executable_name + (".exe" if os.name == "nt" else ""))
    if not candidate.is_file():
        matches = list(out.glob(executable_name + "*"))
        if len(matches) != 1:
            raise BackendError("Nuitka reported success but no onefile executable was produced")
        candidate = matches[0]
    return candidate


def _run_cython_executable(source: Path, work: Path, executable_name: str) -> Path:
    """Compile a Python source file to a real Cython-generated native executable."""
    if importlib.util.find_spec("Cython") is None:
        raise BackendError("Cython is unavailable in this Python interpreter")
    include = sysconfig.get_config_var("INCLUDEPY")
    libdir = sysconfig.get_config_var("LIBDIR")
    ldlib = sysconfig.get_config_var("LDLIBRARY")
    compiler = shutil.which("cc") or shutil.which("gcc") or shutil.which("clang")
    if not (include and Path(include, "Python.h").is_file() and libdir and ldlib and compiler):
        raise BackendError("Cython native executable requires Python.h, libpython and a working C compiler")
    library_name = ldlib[3:] if ldlib.startswith("lib") else ldlib
    if library_name.endswith(".dylib"):
        library_name = library_name[:-6]
    elif ".so" in library_name:
        library_name = library_name.split(".so", 1)[0]
    elif library_name.endswith(".a"):
        library_name = library_name[:-2]
    c_file = work / f"{source.stem}_cython.c"
    p = subprocess.run([sys.executable, "-m", "cython", "--embed", "-3", str(source), "-o", str(c_file)], text=True, capture_output=True)
    if p.returncode:
        raise BackendError((p.stderr or p.stdout).strip() or "Cython C generation failed")
    output = work / executable_name
    cmd = [compiler, str(c_file), f"-I{include}", "-o", str(output), f"-L{libdir}", f"-l{library_name}"]
    # Cython's generated code uses the C runtime, pthreads and dl on Unix.
    if os.name != "nt":
        cmd += ["-lpthread", "-ldl", "-lm"]
        # Keep the target interpreter's shared libpython discoverable when it
        # lives outside the system linker cache (common in virtual environments).
        if libdir:
            cmd += [f"-Wl,-rpath,{libdir}"]
    p = subprocess.run(cmd, text=True, capture_output=True)
    if p.returncode:
        raise BackendError((p.stderr or p.stdout).strip() or "Cython native compilation failed")
    if not output.is_file():
        raise BackendError("Cython compiler reported success but no native executable was produced")
    return output


def _main_guard_to_top_level(source_text: str) -> str:
    """Move only module-level __main__ guards to extension module scope.

    Nested guards must retain their original semantics; flattening them inside
    functions/classes would execute code that normal Python import skips.
    """
    import ast

    def is_main_guard(node: ast.stmt) -> bool:
        if not isinstance(node, ast.If):
            return False
        test = node.test
        return (
            isinstance(test, ast.Compare)
            and isinstance(test.left, ast.Name)
            and test.left.id == "__name__"
            and len(test.ops) == 1
            and isinstance(test.ops[0], ast.Eq)
            and len(test.comparators) == 1
            and isinstance(test.comparators[0], ast.Constant)
            and test.comparators[0].value == "__main__"
        )

    tree = ast.parse(source_text)
    body: list[ast.stmt] = []
    for statement in tree.body:
        if is_main_guard(statement):
            body.extend(statement.body)
        else:
            body.append(statement)
    tree.body = body
    ast.fix_missing_locations(tree)
    return ast.unparse(tree) + "\n"


def _run_cython_extension(source: Path, work: Path) -> Path:
    """Build an importable Cython extension using the active Python's ABI/toolchain."""
    if importlib.util.find_spec("Cython") is None:
        raise BackendError("Cython is not installed in this Python interpreter")
    if importlib.util.find_spec("setuptools") is None:
        raise BackendError("setuptools is required to build a platform-correct extension")
    module_name = "_samarth_entry"
    module_source = work / f"{module_name}.py"
    module_source.write_text(_main_guard_to_top_level(source.read_text(encoding="utf-8")), encoding="utf-8")
    build_lib = work / "extension-build"
    build_temp = work / "extension-temp"
    setup_script = work / "build_extension.py"
    setup_script.write_text(
        "from setuptools import setup, Extension\n"
        "from Cython.Build import cythonize\n"
        f"ext = Extension({module_name!r}, [{str(module_source)!r}])\n"
        "setup(name='samarth-native-entry', ext_modules=cythonize([ext], compiler_directives={'language_level': 3}), "
        f"script_args=['build_ext', '--build-lib', {str(build_lib)!r}, '--build-temp', {str(build_temp)!r}])\n",
        encoding="utf-8",
    )
    p = subprocess.run([sys.executable, str(setup_script)], cwd=str(work), text=True, capture_output=True)
    if p.returncode:
        raise BackendError((p.stderr or p.stdout).strip() or "Cython native extension build failed")
    suffix = sysconfig.get_config_var("EXT_SUFFIX") or ".so"
    output = build_lib / f"{module_name}{suffix}"
    if not output.is_file():
        matches = list(build_lib.glob(module_name + ".*"))
        if len(matches) != 1:
            raise BackendError("Cython build reported success but no ABI-tagged extension was produced")
        output = matches[0]
    return output


def _run_pyarmor(source: Path, work: Path) -> tuple[bytes, str]:
    out = work / "pyarmor-out"
    out.mkdir(parents=True, exist_ok=True)
    exe = shutil.which("pyarmor")
    cmd = ([exe] if exe else [sys.executable, "-m", "pyarmor"]) + ["gen", "-O", str(out), str(source)]
    p = subprocess.run(cmd, text=True, capture_output=True)
    if p.returncode:
        raise BackendError((p.stderr or p.stdout).strip() or "PyArmor protection failed")
    entry = out / source.name
    if not entry.is_file():
        raise BackendError("PyArmor reported success but protected entry script was not produced")
    archive = work / "pyarmor-runtime.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in out.rglob("*"):
            if path.is_file():
                zf.write(path, path.relative_to(out).as_posix())
    return archive.read_bytes(), source.name


def _prepare_source(source: Path, profile: str, work: Path, *, flatten_main_guard: bool = False) -> tuple[Path, dict]:
    # HYBRID gets the internal literal/symbol hardening before native compilation.
    # NATIVE keeps the source transform deliberately conservative because the
    # compiled executable itself is the primary native protection boundary.
    cfg = ASTConfig(
        rename_identifiers=True,
        transform_strings=(profile == "hybrid"),
        optimize=0,
        rename_import_bindings=(profile == "hybrid"),
    )
    original = source.read_text(encoding="utf-8")
    # Extension modules are imported under a module name other than __main__.
    # Flatten the top-level entry guard before literal transformation so the
    # guard remains executable even after the '__main__' string is pooled.
    if flatten_main_guard:
        original = _main_guard_to_top_level(original)
    transformed, report = transform(original, cfg)
    transformed_source = work / source.name
    transformed_source.write_text(transformed, encoding="utf-8")
    return transformed_source, report.__dict__


def protect_external(source: Path, output: Path, profile: str, backend: str) -> dict:
    """Build a real external artifact and store it in a .sme container."""
    backend = backend.lower()
    profile = profile.lower()
    if profile not in {"standard", "advanced", "maximum", "native", "hybrid"}:
        raise BackendError(f"Unsupported profile: {profile}")
    if profile == "native" and backend == "internal":
        raise BackendError("NATIVE requires a genuine native backend; internal VM packing is not accepted as NATIVE.")
    if profile == "hybrid" and backend == "internal":
        backend = strongest_available()
    if backend == "hybrid":
        backend = strongest_available()
    if backend not in {"nuitka", "pyarmor", "cython"}:
        raise BackendError(f"Unsupported external backend: {backend}")
    if not available(backend):
        raise BackendError(f"Required backend {backend.upper()} is unavailable; no silent fallback is used.")
    if backend == "pyarmor" and profile in {"native", "hybrid"}:
        raise BackendError("PyArmor is a Python protection backend, not a native compiler; NATIVE/HYBRID require Nuitka or Cython.")

    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="samarth-native-build-") as td:
        work = Path(td)
        transformed_source, report = _prepare_source(source, profile, work)
        if backend == "nuitka":
            executable_name = source.stem + "_samarth"
            binary = _run_nuitka(transformed_source, work, executable_name).read_bytes()
            meta = {
                "format": "samarth-native-v1", "samarth_version": __version__, "profile": profile,
                "backend": "nuitka", "native_kind": "executable", "native": True,
                "os": platform.system(), "arch": platform.machine(), "environment": ("pydroid" if detect_environment().pydroid else "termux" if detect_environment().termux else platform.system().lower()),
                "python": f"{sys.version_info.major}.{sys.version_info.minor}",
                "soabi": sysconfig.get_config_var("SOABI"),
                "executable_name": executable_name, "entry": source.name,
                "transform_report": report,
            }
        elif backend == "cython":
            # Prefer a real embedded executable so __name__ == '__main__' semantics
            # are preserved. If embedding/linking is unavailable, the code falls
            # back to an explicitly tagged ABI-specific extension module.
            executable_name = source.stem + "_samarth"
            try:
                native = _run_cython_executable(transformed_source, work, executable_name)
                if profile == "hybrid":
                    archive = work / "cython-hybrid.zip"
                    runtime_dir = work / "runtime" / "samarth"
                    runtime_dir.mkdir(parents=True, exist_ok=True)
                    (runtime_dir / "__init__.py").write_text(Path(__file__).with_name("__init__.py").read_text(encoding="utf-8"), encoding="utf-8")
                    (runtime_dir / "literal_engine.py").write_text(Path(__file__).with_name("literal_engine.py").read_text(encoding="utf-8"), encoding="utf-8")
                    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
                        zf.write(native, executable_name)
                        for rp in runtime_dir.rglob("*"):
                            if rp.is_file():
                                zf.write(rp, rp.relative_to(work / "runtime").as_posix())
                    binary = archive.read_bytes()
                    native_kind = "executable-bundle"
                else:
                    binary = native.read_bytes()
                    native_kind = "executable"
                meta = {
                    "format": "samarth-native-v1", "samarth_version": __version__, "profile": profile,
                    "backend": "cython", "native_kind": native_kind, "native": True,
                    "os": platform.system(), "arch": platform.machine(), "environment": ("pydroid" if detect_environment().pydroid else "termux" if detect_environment().termux else platform.system().lower()),
                    "python": f"{sys.version_info.major}.{sys.version_info.minor}",
                    "soabi": sysconfig.get_config_var("SOABI"),
                    "executable_name": executable_name, "entry": source.name,
                    "runtime_bundle": profile == "hybrid", "transform_report": report,
                }
            except BackendError:
                extension_source, extension_report = _prepare_source(
                    source, profile, work, flatten_main_guard=True
                )
                ext = _run_cython_extension(extension_source, work)
                report = extension_report
                archive = work / "cython-ext.zip"
                with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
                    zf.write(ext, ext.name)
                    if profile == "hybrid":
                        package_dir = work / "runtime" / "samarth"
                        package_dir.mkdir(parents=True, exist_ok=True)
                        for helper in ("__init__.py", "literal_engine.py"):
                            helper_path = Path(__file__).with_name(helper)
                            zf.write(helper_path, f"samarth/{helper}")
                binary = archive.read_bytes()
                meta = {
                    "format": "samarth-native-v1", "samarth_version": __version__, "profile": profile,
                    "backend": "cython", "native_kind": "extension", "native": True,
                    "os": platform.system(), "arch": platform.machine(), "environment": ("pydroid" if detect_environment().pydroid else "termux" if detect_environment().termux else platform.system().lower()),
                    "python": f"{sys.version_info.major}.{sys.version_info.minor}",
                    "soabi": sysconfig.get_config_var("SOABI"),
                    "extension": ext.name, "module_name": "_samarth_entry", "entry": source.name,
                    "transform_report": report,
                }
        else:
            archive_bytes, entry = _run_pyarmor(transformed_source, work)
            binary = archive_bytes
            meta = {
                "format": "samarth-pyarmor-v1", "samarth_version": __version__, "profile": profile,
                "backend": "pyarmor", "native": False,
                "os": platform.system(), "arch": platform.machine(), "environment": ("pydroid" if detect_environment().pydroid else "termux" if detect_environment().termux else platform.system().lower()),
                "python": f"{sys.version_info.major}.{sys.version_info.minor}",
                "soabi": sysconfig.get_config_var("SOABI"),
                "entry": entry, "transform_report": report,
            }
        output.write_bytes(pack_native(binary, meta))
    return meta


def run_backend(name: str, source: Path, output: Path, args: list[str] | None = None):
    del args
    return protect_external(source, output, "advanced", name)
