from __future__ import annotations

import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from .ast_engine import ASTConfig, transform
from .bytecode_engine import pack_code, payload_sha256
from .project import PROFILES

TARGETS = ("3.11", "3.12", "3.13", "3.14")

_WORKER = r'''from pathlib import Path
import sys
source_path=Path(sys.argv[1]); out_path=Path(sys.argv[2]); profile=sys.argv[3]; backend=sys.argv[4]
if profile in {"native","hybrid"}:
    from samarth.backends import protect_external
    protect_external(source_path, out_path, profile, backend)
else:
    from samarth.project import protect_file
    protect_file(source_path, out_path, profile)
'''



def _version_of(command: list[str]) -> str | None:
    try:
        r = subprocess.run(command + ["-c", "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"], capture_output=True, text=True, timeout=20)
    except (OSError, subprocess.SubprocessError): return None
    if r.returncode != 0: return None
    return r.stdout.strip().splitlines()[-1] if r.stdout.strip() else None


def _find_python(version: str) -> list[str] | None:
    major, minor = version.split(".")
    names = [f"python{version}", f"python{major}.{minor}", f"python{minor}"]
    candidates=[]
    for name in names:
        p=shutil.which(name)
        if p: candidates.append([p])
    if os.name == "nt":
        launcher=shutil.which("py")
        if launcher: candidates.append([launcher, f"-{version}"])
    for base in (Path("/usr/bin"), Path("/usr/local/bin"), Path.home()/".local"/"bin"):
        for name in names[:2]: candidates.append([str(base/name)])
    seen=set()
    for c in candidates:
        t=tuple(c)
        if t in seen: continue
        seen.add(t)
        if _version_of(c)==version: return c
    return None


def _find_uv() -> str | None: return shutil.which("uv")


def _uv_python(version: str) -> list[str] | None:
    uv=_find_uv()
    if not uv: return None
    try:
        subprocess.run([uv,"python","install",version],check=True,capture_output=True,text=True,timeout=600)
        r=subprocess.run([uv,"python","find",version],check=True,capture_output=True,text=True,timeout=30)
        p=r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ""
        return [p] if p and _version_of([p])==version else None
    except (OSError,subprocess.SubprocessError): return None


def resolve_interpreters(interpreters: dict[str,str]|None=None, bootstrap: bool=True):
    interpreters=interpreters or {}; resolved={}; missing=[]
    for version in TARGETS:
        explicit=interpreters.get(version)
        if explicit:
            command=shlex.split(explicit,posix=(os.name!="nt"))
            if _version_of(command)!=version: raise RuntimeError(f"Configured interpreter for Python {version} is invalid or reports a different version.")
            resolved[version]=command; continue
        command=_find_python(version)
        if command is None and bootstrap: command=_uv_python(version)
        if command is None: missing.append(version)
        else: resolved[version]=command
    return resolved, missing


def protect_multi(src: Path, out: Path, profile="advanced", interpreters=None, bootstrap=True, backend="internal", install_build_deps=False):
    profile=profile.lower()
    if profile not in PROFILES: raise ValueError(f"Unknown profile: {profile}")
    backend = (backend or "internal").lower()
    if profile in {"native", "hybrid"} and backend not in {"cython", "nuitka"}:
        raise RuntimeError(f"{profile.upper()} multi-version builds require --backend cython or --backend nuitka.")
    if profile not in {"native", "hybrid"} and backend != "internal":
        raise RuntimeError("STANDARD/ADVANCED/MAXIMUM multi-version builds use --backend internal; external native backends are reserved for NATIVE/HYBRID.")
    if not src.is_file() or src.suffix.lower()!=".py": raise ValueError("Multi-version protection currently accepts one .py file.")
    source=src.read_text(encoding="utf-8")
    report_data={"source_bytes":len(source.encode("utf-8"))}
    out.mkdir(parents=True,exist_ok=True)
    resolved,missing=resolve_interpreters(interpreters,bootstrap=bootstrap)
    if missing: raise RuntimeError("Missing CPython runtimes: "+", ".join(missing)+". Install them or provide --python311/--python312/--python313/--python314.")
    created=[]
    with tempfile.TemporaryDirectory(prefix="samarth-multi-") as td:
        staging = Path(td) / "artifacts"
        staging.mkdir()
        worker_path=Path(td)/"worker.py"; worker_path.write_text(_WORKER,encoding="utf-8")
        package_root = str(Path(__file__).resolve().parent.parent)
        from .environment import detect_environment
        for version in TARGETS:
            # Keep the loader's established filename contract. Each build output
            # directory is one OS/environment/architecture distribution; the
            # native payload metadata validates that target at execution time.
            target=staging/f"{src.stem}_py{version.replace('.', '')}.sme"
            env = os.environ.copy()
            env["PYTHONPATH"] = package_root + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
            if install_build_deps and backend in {"cython", "nuitka"}:
                deps = ["Cython>=3.0", "setuptools>=68"] if backend == "cython" else ["Nuitka>=2.0"]
                subprocess.run(resolved[version]+["-m","pip","install",*deps],check=True)
            subprocess.run(resolved[version]+[str(worker_path),str(src),str(target),profile,backend],check=True,env=env)
            created.append(target.name)
        env_info = detect_environment().as_dict()
        manifest={"format":"samarth-multiversion-v3","profile":profile,"backend":backend,"source":src.name,
                  "python_versions":TARGETS,"files":created,
                  "build_environment":{"os":env_info["os"],"machine":env_info["machine"],
                                       "pydroid":env_info["pydroid"],"termux":env_info["termux"]},
                  "sha256":{n:payload_sha256((staging/n).read_bytes()) for n in created},"transform_report":report_data}
        # Publish only after all four builds succeed; a failed matrix leaves no
        # misleading partial manifest or half-built version set in the output.
        for name in created:
            os.replace(staging/name, out/name)
        manifest_tmp = out / ".manifest.json.tmp"
        manifest_tmp.write_text(json.dumps(manifest,indent=2,sort_keys=True),encoding="utf-8")
        os.replace(manifest_tmp, out/"manifest.json")
    return manifest
